%%
function xi=fun_get_xi(safety_class)
switch safety_class
    case 'low'
        xi=0.9;
    case 'normal'
        xi=0.85;

    case 'high'
        xi=0.8;
    otherwise
        warning('***函数fun_get_xi未收到合法的Safety Class!');
end
end