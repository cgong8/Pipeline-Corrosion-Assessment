function x = u_x_transform(u, dist_para)

% Inverse normal transformation
% Generally follows the macro function developed by Low and Tang (2007): "Efficient Spreadsheet Algorithm for First-order Reliability Method" J. Eng. Mech. 133(12): 1378-1387
% dis_para(:,6) is a vector containing the following information:
% dis_para(:,1) = distribution type, dis_para(:,2) = para1, dis_para(:,3) = para2, dis_para(:,4) = empty, dis_para(:,5) = lower bound, dis_para(:,6) = upper bound
    % Distribution Type:
    % Deterministic = 0; Uniform = 1; Normal = 2; Lognormal = 3; Gamma = 4; Weibull = 5; Gumbel = 6; Beta = 7; Exponential = 8; Poisson = 9; Triangular = 10;
        % for Lognormal distribution, dist_para(:,5) = lower bound (shift)
        % for Beta distribution, dist_para(:,5)=lower bound, dist_para(:,6) = upper bound
        % for Exponential distribution, dist_para(:,5) = lower bound (shift)
        % for Triangular distribution, dist_para(:,5)=lower bound, dist_para(:,6) = upper bound
    x=zeros(length(u),1);


             dist_type = dist_para(:,1);
             
                a0=find(dist_type==0)';
             if ~isempty(a0)
            lamda = dist_para(a0,2)';
            zeta = (dist_para(a0,3)*0)';
           % LB = dist_para(a0,5)';
           % x(a0)= LB + exp(lamda + zeta.*u(a0));

             x(a0)= lamda;
             end 
                  
            a1=find(dist_type==1);
          if ~isempty(a1)
            ll = dist_para(a1,2);
            ul = dist_para(a1,3);
            x(a1) = ll + (ul - ll).*normcdf(u(a1),0,1);
          end
            

             a2=find(dist_type==2);
            if ~isempty(a2) 
            mean = dist_para(a2,2);
            stdev = dist_para(a2,3);
            x(a2) = mean + u(a2).*stdev;
            end 
            
                  a3=find(dist_type==3);
                if ~isempty(a3)      
            lamda = dist_para(a3,2);
            zeta = dist_para(a3,3);
            x(a3)=  exp(lamda + zeta.*u(a3));
                end
          %  LB = dist_para(a3,5)';
           % x(a3)= LB + exp(lamda + zeta.*u(a3));
        
            a4=find(dist_type==4);
            if ~isempty(a4)      
            k = dist_para(a4,2);  % Gamma distribution parameter k, corresponding to parameter a in Matlab function Gamrnd(a,b)
            v = dist_para(a4,3);                                       % Gamma distribution parameter v, corresponding to inverse of parameter b (1/b) in Matlab function Gamrnd(a,b)
            x(a4)=gaminv(normcdf(u(a4),0,1),k, 1./v);
            end
       
            a5=find(dist_type==5);
             if ~isempty(a5) 
            k = dist_para(a5,2);                                                                        % Weibull distribution parameter, k, corresponding to parameter b in Matlab function Weibrnd(a,b)
            v = dist_para(a5,3);                        % Weibull distribution parameter, v, parameter a in Matlab function Weibrnd(a,b) = (1/v)^k     
          %  x(a5) = weibinv(normcdf(u(a5),0,1),(1./v).^k,k);
            x(a5) = wblinv(normcdf(u(a5),0,1),v,k);
             end
            
            a6=find(dist_type==6);
              if ~isempty(a6) 
            alfa = dist_para(a6,2);       % Gumbel distribution parameter, alfa
            v = dist_para(a6,3);   % Gumbel distribution parameter, u
            x(a6)=v - log(-log(normcdf(u(a6),0,1)))./alfa;
              end
              
              
            a7=find(dist_type==7);
            if ~isempty(a7)
            r = dist_para(a7,2);
            q = dist_para(a7,3);
            LB = dist_para(a7,5);
            UB=dist_para(a7,6);
            x(a7) = LB + (UB - LB).*betainv(normcdf(u(a7),0,1),q, r);
            end
            
              a8=find(dist_type==8);
             if ~isempty(a8)
            
            mean = dist_para(a8,2);
           % LB = dist_para(a8,5)';
            %x(a8) = LB + expinv(normcdf(u(a8),0,1), mean);
            x(a8) = expinv(normcdf(u(a8),0,1), mean);
              end
            
             a9=find(dist_type==9);
                          if ~isempty(a9)
            mean = dist_para(a9,2);
            x(a9) = poissinv(normcdf(u(a9),0,1), mean);
                          end
                          
             a10=find(dist_type==10);
           if ~isempty(a10)
            mode = dist_para(a10,2);
            a = dist_para(a10,5);
            b = dist_para(a10,6);
            maba = (mode-a)./(b-a);
         dd=find( normcdf(u(a10),0,1)< maba)';
        
         x(a10(dd))= a + sqrt(normcdf(u(a10(dd)),0,1).*(mode(a10(dd))-a(a10(dd))).*(b(a10(dd))-a(a10(dd))));
         cdd=find( normcdf(u(a10),0,1)>= maba);
         x(a10(cdd)) = b - sqrt((1-normcdf(u(a10(cdd)),0,1)).*(b(a10(cdd))-a(a10(cdd))).*(b(a10(cdd))-mode(a10(cdd))));
           end
  