function [gburst, gl]= LSFm(x,denum,T_max)

% limit state function 
% random variables are included in the vector 'x'; deterministic parameters are included in the vector 'det_para'
%            x(1),x(2),x(3),x(4),x(5),x(6),x(7),x(8),x(9),x(10) indicate the random
%variables sigamu, wt,   D,   d0,  gd,  l0,  gl,  e2,   Pb, e3
global df;
global model_sel
      
                  
 
        switch model_sel
            case 1
                for time=0:T_max
              %%%%%%%%CSA Model%%%%%%%
        dav=(x(:,4+11*(denum-1))+x(:,5+11*(denum-1))*time).*x(:,10+11*(denum-1));
        wt=x(:,2+11*(denum-1));
        l=x(:,6+11*(denum-1))+x(:,7+11*(denum-1))*time;
        M=Folias2(x(:,3+11*(denum-1)),x(:,2+11*(denum-1)),l);%l,gl,D,t
        D=x(:,3+11*(denum-1));sigmau=zeros(length(x(:,1)),1);

        sigmau(find(x(:,1+11*(denum-1))>241))=0.9*x(find(x(:,1+11*(denum-1))>241),11+11*(denum-1));
        sigmau(find(x(:,1+11*(denum-1))<=241))=1.15*x(find(x(:,1+11*(denum-1))<=241),1+11*(denum-1));
 
        ra=2*(sigmau).*wt./D.*(1-dav./wt)./(1-dav./wt./M); 

        gburst(:,time+1)=x(:,8+11*(denum-1)).*ra-x(:,9+11*(denum-1));%x(:,10+10*(denum-1)).*ra-x(:,9+10*(denum-1));
        gl(:,time+1)=wt*df-(x(:,4+11*(denum-1))+x(:,5+11*(denum-1))*time);        
                end 
            case 2
              %%%%%%%%B31G-M Model%%%%%%%
               for time=0:T_max
        dmax=(x(:,4+11*(denum-1))+x(:,5+11*(denum-1))*time);
        wt=x(:,2+11*(denum-1));
        l=x(:,6+11*(denum-1))+x(:,7+11*(denum-1))*time;
        M=Folias2(x(:,3+11*(denum-1)),x(:,2+11*(denum-1)),l);%l,gl,D,t
        D=x(:,3+11*(denum-1));      
        
        gl(:,time+1)=wt*df-(x(:,4+11*(denum-1))+x(:,5+11*(denum-1))*time);   
        
        dmax(find(dmax./wt>0.8))=0.8*wt(find(dmax./wt>0.8));    
        sigmau=x(:,1+11*(denum-1));
        ra= 2*(sigmau+68.95).*wt./D.*(1-0.85*dmax./wt)./(1-0.85.*dmax./M./wt);
              
        gburst(:,time+1)=x(:,8+11*(denum-1)).*ra-x(:,9+11*(denum-1));%x(:,10+10*(denum-1)).*ra-x(:,9+10*(denum-1));
                
               end
            case 3
              %%%%%%%%PCORRC Model%%%%%%%
               for time=0:T_max
        dmax=(x(:,4+11*(denum-1))+x(:,5+11*(denum-1))*time);
        wt=x(:,2+11*(denum-1));
        l=x(:,6+11*(denum-1))+x(:,7+11*(denum-1))*time;
        sigmau=x(:,11+11*(denum-1));  D=x(:,3+11*(denum-1));  
        
                   gl(:,time+1)=wt*df-(x(:,4+10*(denum-1))+x(:,5+10*(denum-1))*time);   
                   
        l(find(l>2*D))=2*D(find(l>2*D));
        dmax(find(dmax./wt>0.8))=0.8*wt(find(dmax./wt>0.8)); 
    
              ra=2*(sigmau).*wt./D.*(1-dmax./wt.*(1-exp(-0.157*l./(D.*(1-dmax./wt)/2).^0.5)));       
            
              g=x(8)*ra-x(9);%x(10)*ra-x(9);
              g_eq=x(8)*ra-x(9);%x(10)*ra-x(9);
              
              
        gburst(:,time+1)=x(:,8+10*(denum-1)).*ra-x(:,9+10*(denum-1));%x(:,10+10*(denum-1)).*ra-x(:,9+10*(denum-1));
      
              end   
        end 
        
        

 
               
               %  aa=2*(sigmau+68.95).*wt;
               %  bb=aa./D.*(1-0.85.*dmax./wt);
               %  ra1=bb./(1-0.85*dmax./M./wt);
%                  ra1=2*(sigmau+68.95).*wt./D.*(1-0.85*dmax./wt)./(1-0.85.*dmax./M./wt);
% %                 ra(find(dmax./wt<=0.8))=ra1(find(dmax./wt<=0.8));
% %                 
% %                
% %                  co=(0.2.*wt-(dmax-0.8.*wt))./(0.2.*wt);            
% %                  dmax1=0.8.*wt;
% %                 rb=2*(sigmau+68.95).*wt./D.*(1-0.85*dmax1./wt)./(1-0.85.*dmax1./M./wt);
% %                   ra2=co.*rb;         
% %           
% %             
% %                         ra(find(dmax./wt>0.8))=ra2(find(dmax./wt>0.8));
%      % save error
%        gburst(:,time+1)=x(:,8+10*(denum-1)).*ra1-x(:,9+10*(denum-1));
%         gl(:,time+1)=wt*df-(x(:,4+10*(denum-1))+x(:,5+10*(denum-1))*time);%det_para);%x(3+10*(denum-1))245

         %  ra=2*(sigmau).*wt./D.*(1-dmax./wt)./(1-dmax./wt./M); 

           
           %   g=x(10).*ra-x(9);
       

        
        

gburst(find(gburst<=0))=0;
 gburst(find(gburst>0))=1;     
 gl(find(gl<=0))=0;
 gl(find(gl>0))=1;       
        

 
 