function [P]=combineburstc(T_max,c2,bet2,numcorrelation)

for t=1:T_max+1
  for i=1:numcorrelation
      for j=1:numcorrelation
       p22(i,j,t)=abs(c2{i}(:,t)'*c2{j}(:,t));
         
      end
  end
end


for t=1:T_max+1
po{t}=[p22(:,:,t)];%p12(:,:,t);p21(:,:,t) p22(:,:,t)]; %%correlation coefficients
end

for t=1:T_max+1
pbeta{t}=[bet2(:,t)];%;bet2(:,t)];            % reliability index
end


%for i=1:T_max+1
% a=-10^100*ones(length(pbeta{1}),1);
%b=pbeta{i};m=0*a;C=po{i};
%P(i)=mvncdf(b,m,C);
%end
%P=1-P;
%P=P';

for i=1:T_max+1
 a=-10^100*ones(length(pbeta{1}),1);
b=pbeta{i};m=0*a;C=po{i};
%[P(i),error(i)]=mvncdf(b,m,C);%,options);
if length(pbeta{1})==1
    [P(i)]=1-normcdf(b);
elseif length(pbeta{1})>=2 && length(pbeta{1})<=3
    [P(i)]=1-mvncdf(b,m,C);%,options);
else        
    [P(i)]=multi_normal_integral(b,C);
end
%[ P11(i), dp, ed ] = qsimvndv( 1e5, C, a, b, 1 );
%gredia{i}= -1 * mvnpdf(b, m, C) * (C \ (b));
end
%P11=1-P11;
%Pp=1-Pp;
%Pp=P;

