clear all;
clc;
 %  rmdir('burst_capacity_folder')
currentFolder = pwd;
ansys_path = '"D:\Program Files\ANSYS Inc\v192\ANSYS\bin\winx64\ANSYS192.exe"'
T=readtable('pipe_tally.xlsx');
E_value=2e5; 

cluster_ID_unique=unique(T{:,2});
cluster_ID=T{:,2};
feature_ID=T{:,1};
longitudinal_center=T{:,3};
cir_center=T{:,4};
wall_thickness=T{:,5};
defect_depth_all=T{:,6};
defect_length_all=T{:,7};
defect_width_all=T{:,8};
D_all=T{:,11};
YS_all=T{:,9};
UTS_all=T{:,10};
translation_element_layer=3;
axial_stress_all=T{:,12};
operating_pressure=T{:,13};
Psqr_ind=T{:,14};
FEM_indicator=T{:,15};
ELE_size=T{:,16};


c_c=[];
for iii=1:length(cluster_ID_unique)
    cd (currentFolder);                          
    ID_no=cluster_ID_unique(iii);
    index_no=find(cluster_ID==ID_no);
  
    if isnan(ELE_size(index_no(1)))
        element_size=2;
    else
        element_size=ELE_size(index_no(1));
    end
    
    t=wall_thickness(index_no(1));
    pipe_thickness=t;
    Operating_Pressure=operating_pressure(index_no(1));
    pipe_diameter=D_all(index_no(1));                             % this should also be included in the table
    YS_value=YS_all(index_no(1));                                     % must be positive (MPa)
    UTS_value=UTS_all(index_no(1));
   
    if isnan(axial_stress_all(index_no(1)))
       axial_stress=0;
    else
       axial_stress=axial_stress_all(index_no(1));
    end
    
    if isnan(Psqr_ind(index_no(1)))
        P2_indicator=0;
    else
        P2_indicator=Psqr_ind(index_no(1));
    end
    
    if isnan(FEM_indicator(index_no(1)))
        F_ind=0;
    else
        F_ind=FEM_indicator(index_no(1));
    end
    
    
    
   % element_size=2;  
    element_size_x=element_size; 
    element_size_y=element_size; 
    % element size in the corrosion area (mm)
    circumsurround=element_size_y*3^translation_element_layer;
    longsurround=element_size_x*3^translation_element_layer;
   % mesh_resolution=element_size;
    D=pipe_diameter;
    longitudinal_position = longitudinal_center(index_no,1)*1000; 
    circumferential_position_hh_mm1=cir_center(index_no,1);
    
    
    for j=1:length(index_no)
        store_string=circumferential_position_hh_mm1{j,:};
        circumferential_position_hh_mm(j,:)=str2num(store_string(isstrprop(store_string,'digit')));
    end
    
    % this should be converted to the mm
    circumferential_position=floor(circumferential_position_hh_mm/100)/12*D*pi+(circumferential_position_hh_mm-floor(circumferential_position_hh_mm/100)*100)/60*D*pi/12;  % in the unit of (mm)
    circumferential_position_hh_mm=[];
    
    
    defect_length=defect_length_all(index_no);                                           % for example, the 4rd column is the defect length (but convert it to the (mm)
    defect_width=defect_width_all(index_no);                                             % for example, the 5th column is the defect width (but convert it to the (mm)
    defect_depth=defect_depth_all(index_no)/100*t;                                       % for example, the 6th column is the defect depth in the unit of mm
   
    
    % here, determine the length/width of the corrosion cluster in the
    % FEA model
    
    
    cluster_long_start =  (longitudinal_position    -  defect_length/2);
    cluster_long_end   =  (longitudinal_position    +  defect_length/2);
    cluster_cir_start  =  (circumferential_position -  defect_width/2);
    cluster_cir_end    =  (circumferential_position +  defect_width/2);
    

    
    long_start =  min(cluster_long_start);
    long_end   =  max(cluster_long_end);
    cir_start  =  min(cluster_cir_start);
    cir_end    =  max(cluster_cir_end);
    
    cluster_length = long_end -  long_start +2 ;
    cluster_width  = cir_end  -  cir_start  +2 ;
    
    cluster_long_index=(cluster_long_start-long_start)/element_size+1;
    cluster_cir_index=(cluster_cir_start- cir_start)/element_size+1;
    corrosion_length = cluster_long_end -  cluster_long_start ;
    corrosion_width  = cluster_cir_end  -  cluster_cir_start  ;
    
    corrosion_cluster_num_long=round(cluster_length/element_size);
    corrosion_cluster_num_cir=round(cluster_width/element_size);
    
    
     
    Cluster_corrosion_profile=zeros(corrosion_cluster_num_cir,corrosion_cluster_num_long);
    
    for j=1:length(index_no)
        Cluster_corrosion_profile(cluster_cir_index(j):cluster_cir_index(j)+corrosion_width(j)/element_size,cluster_long_index(j):cluster_long_index(j)+corrosion_length(j)/element_size)=(Cluster_corrosion_profile(cluster_cir_index(j):cluster_cir_index(j)+corrosion_width(j)/element_size,cluster_long_index(j):cluster_long_index(j)+corrosion_length(j)/element_size)+1)*defect_depth(j);
    end
    
    aa=sum(Cluster_corrosion_profile,1);
    for i=1:length(aa)
        if sum(aa(1:i))==0
           cc=i;
           Cluster_corrosion_profile(:,1:cc)=[];
        end
        if sum(aa(length(aa)-i+1:length(aa)))==0
           cc_e=i; 
           Cluster_corrosion_profile(:,end-cc_e+1:end)=[];
        end
    end
    
    
    cc=[];cc_e=[];aa=[];
    
    bb=sum(Cluster_corrosion_profile,2);
    for i=1:length(bb)
        if sum(bb(1:i))==0
           cc=i;
        end
        if sum(bb(length(bb)-i+1:length(bb)))==0
           cc_e=i; 
        end
    end
    Cluster_corrosion_profile(1:cc,:)=[];
    Cluster_corrosion_profile(end-cc_e+1:end,:)=[];
    cc=[];cc_e=[];bb=[];
    
    Cluster_corrosion_profile2=Cluster_corrosion_profile;
    
    Cluster_corrosion_profile1=zeros(length(Cluster_corrosion_profile(:,1)),length(Cluster_corrosion_profile(1,:)));
    
    Cluster_corrosion_profile1(1:end,1:end)=Cluster_corrosion_profile2;
    
    Cluster_corrosion_profile=[];
    Cluster_corrosion_profile2=[];
    
    pipethickness=wall_thickness(index_no(1));
    AOD=D_all(index_no(1));                             % this should also be included in the table
    SMYS=YS_all(index_no(1));                                     % must be positive (MPa)
    SMTS=UTS_all(index_no(1));
    
    [Pb_simple(iii,:)]=model_selection_quick(Cluster_corrosion_profile1,SMYS,SMTS,AOD,pipethickness,element_size);
    if P2_indicator==1 && length(Cluster_corrosion_profile1(1,:))>=3
    [Pb_sqrt(iii)]=Psqr(Cluster_corrosion_profile1,SMYS,AOD,pipethickness,element_size);
    else
    Pb_sqrt(iii)=0;    
    end
    
    if F_ind==1 
    close all;
    [status, message, messageid] = rmdir('burst_capacity_folder','s');
    [result]=APDL_model_generation_revised(ansys_path,T,E_value,iii,iii);
    inter_tr=cell2mat(result(iii,2));
    Pb_FEM(iii)=inter_tr;
    else
    Pb_FEM(iii)=0;    
     end
        
   c_c=[c_c;[ID_no AOD SMYS SMTS pipethickness Operating_Pressure max(max(Cluster_corrosion_profile1))/pipethickness*100 element_size*(length(Cluster_corrosion_profile1(1,:))-1) 0 0 Pb_simple(iii,:) Pb_sqrt(iii) Pb_FEM(iii)]];

end

filename=['PipReliaby_interface.xlsm'];
xlswrite(filename,c_c,['A13:Q',num2str(length(cluster_ID_unique)+12)])

fclose('all')

