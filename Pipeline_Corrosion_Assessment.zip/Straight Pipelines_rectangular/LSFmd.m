function [g, g_eq]= LSFmd(u)

% limit state function 
% random variables are included in the vector 'x'; deterministic parameters are included in the vector 'det_para'
%            x(1),x(2),x(3),x(4),x(5),x(6),x(7),x(8),x(9),x(10) indicate the random
%variables sigamu, wt,   D,   d0,  gd,  l0,  gl,  e2,   Pb, e3

global t_parachange  t_inter; 
global denum;
global indicator;
global df model_sel;


dist_para=t_parachange;
det_para=t_inter;

%u=u';
switch indicator
                %     1  2   3   4   5  6   7   8   9    10   11
                %SMYS, wt, D, d0, gd, l0, gl, er, pb Ttrans   SMTS
   %   xin(:,1)=[     3   2  1   2   3   2   0   3   0     7    3];
    %                
    case 1 %burst
      %  x=ones(length(u),1)';      save error
             x((1:11)) = u_x_transform(u(1:11), dist_para(1+11*(denum-1):11+11*(denum-1),:));             
      %ra=-100000;
      
      switch model_sel
          case 1
              %%%%%%%%CSA Model%%%%%%%
              M=Folias(x(6),x(7),x(3),x(2),det_para);%l,gl,D,t
              dav=(x(4)+x(5)*det_para)*x(10);wt=x(2);D=x(3);
              l=x(6)+det_para*x(7);
              if x(1)>241
              sigmau=0.9*x(11);
              else
              sigmau=1.15*x(1);    
              end 
              ra=2*(sigmau)*wt/D*(1-dav/wt)/(1-dav/wt/M); 
              g=x(8)*ra-x(9);%x(10)*ra-x(9);
              g_eq=x(8)*ra-x(9);%x(10)*ra-x(9);
           case 2
              %%%%%%%%B31G-M Model%%%%%%%
              M=Folias(x(6),x(7),x(3),x(2),det_para);%l,gl,D,t
              dmax=(x(4)+x(5)*det_para);wt=x(2);D=x(3);
              l=x(6)+det_para*x(7);sigmau=x(1);
           
              if dmax<=wt*0.8
              ra=2*(sigmau+68.95)*wt/D*(1-0.85*dmax/wt)/(1-0.85*dmax/M/wt);       
              else
              dmax=wt*0.8;  
              ra=2*(sigmau+68.95)*wt/D*(1-0.85*dmax/wt)/(1-0.85*dmax/M/wt);
              end  
              g=x(8)*ra-x(9);%x(10)*ra-x(9);
              g_eq=x(8)*ra-x(9);%x(10)*ra-x(9);
          case 3
              %%%%%%%%PCORRC Model%%%%%%%
              dmax=(x(4)+x(5)*det_para);wt=x(2);D=x(3);
              l=x(6)+det_para*x(7);sigmau=x(11);
           
              if l>2*D
                 l=2*D;
              end
              if dmax>wt*0.8
                 dmax=wt*0.8;
              end
                  
              ra=2*(sigmau)*wt/D*(1-dmax/wt*(1-exp(-0.157*l/(D*(1-dmax/wt)/2)^0.5)));       
            
              g=x(8)*ra-x(9);%x(10)*ra-x(9);
              g_eq=x(8)*ra-x(9);%x(10)*ra-x(9);
      end   
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%% This is B31 modified burst capacity model %%%%%%
         
         
         
%                  ra=2*(sigmau+68.95)*wt/D*(1-0.85*dmax/wt)/(1-0.85*dmax/M/wt);       
% 
%            g=x(8)*ra-x(9);
%            g_eq=x(8)*ra-x(9);
       %%%%%%%%%%% This is B31 modified burst capacity model %%%%   
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
       

       
    case 2 %small leak
             x(2) = u_x_transform(u(2), dist_para(2+11*(denum-1),:));
             x(4) = u_x_transform(u(4), dist_para(4+11*(denum-1),:));
             x(5) = u_x_transform(u(5), dist_para(5+11*(denum-1),:));
%              if  ~isempty(find(x==Inf))
%            
%           warning('Infinite point are found at "%d".',find(x==Inf));
%              end
          
        g=x(2)*df-(x(4)+x(5)*det_para);%det_para);%x(3+10*(denum-1))245
        g_eq =x(2)*df-(x(4)+x(5)*det_para);%*det_para);%x(3+10*(denum-1))
end
        
        