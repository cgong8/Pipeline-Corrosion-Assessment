function [ra]=Procc(Cluster5,SMTS,AOD,pipethickness,resolution_length)
    
    river_bottom=max(Cluster5);
    profile_selected=river_bottom(1:end);
    profile_selected_length=resolution_length*(length(profile_selected)-1);

    det_para=0;x(6)=profile_selected_length;x(7)=0;x(3)=AOD;x(2)=pipethickness;
    M=Folias(x(6),x(7),x(3),x(2),det_para);%l,gl,D,t
    wt=x(2);D=x(3);
    
    dmax=(max(river_bottom));
    sigmau=SMTS;

              l=x(6);
           
              if l>2*D
                 l=2*D;
              end
              if dmax>wt*0.8
                 dmax=wt*0.8;
              end
                  
              ra=2*(sigmau)*wt/D*(1-dmax/wt*(1-exp(-0.157*l/(D*(wt-dmax)/2)^0.5)));       
                       