%This is a function to calaulate the folias factor
function m=Folias2(D,t,tao)
a=((tao).^2)./(D.*t);
m=zeros(length(a(:,1)),length(a(1,:)));
[cc,dd]=find(a<=50);
%if ~isempty(cc)
    m1=sqrt(1+0.6275.*a-0.003375.*(a).^2);
%end



    m2=0.032.*a+3.293;

    
    


      m(find(a<=50))=m1(find(a<=50));

    

        m(find(a>50))=m2(find(a>50));
