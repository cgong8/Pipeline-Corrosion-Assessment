

for iiii=1:1
    
    [M,N]=size(corrosion_profile);
    defect_length=2*(N-1);
    cluster_length(iiii,1)=defect_length;
    cluster_width(iiii,1)=2*(M-1);

   % CPS model
   n=0.239*(sigmau/sigmay-1)^0.565;
   C=1/2+1/sqrt(3);
   P_plain=(C/2)^(n+1)*4*pipethickness/AOD*sigmau;

   Pb_cps1=WDD(corrosion_profile,pipethickness,AOD,2,P_plain,n,sigmau);
   Pb_cps(iiii,1)=Pb_cps1;
     
end