function [aaaBurst,aaaLeak]=group_program(T_max,MODEL_S,NUM_S,xin,FORM_in)

ac=1;
numcorrelation=1; %number of correlated defects
%T_max=41;       % total year
initialcre=0;  %initla plus 1

%abc=[    3   2  2   2   3   2   2   3   6    7     3  ];

global df;
global gcor;
global denum;
global indicator;
global numsimulation;
global gcor1 model_sel;
numsimulation=NUM_S;
gcor=0;
df=0.8;
gcor1=0;
model_sel=MODEL_S;
% % for i=1:numcorrelation
% %     [xin((1+11*(i-1)):(11+11*(i-1)),1:6)]=tiquxin(i+n,ac,abc,abc_mean,);
% % end
if FORM_in==0
    
    [anburst,anleak,cburst,cleak]=diaoqusim3(xin,initialcre,T_max,numcorrelation,numsimulation);
    
    aaaBurst_update=anburst(2:end)-anburst(1:end-1);
    aaaBurst_=[anburst(1) aaaBurst_update];
    
    anleak_update=anleak(2:end)-anleak(1:end-1);
    anleak_=[anleak(1) anleak_update];
    
    Pb_I=NaN*ones(1,length(aaaBurst_));
    Pl_I=NaN*ones(1,length(aaaBurst_));
    
    aaaBurst = [Pb_I'  aaaBurst_'];
    aaaLeak = [Pl_I'  anleak_'];
    aaaBurst(find(aaaBurst<1e-11))=0;
    aaaLeak(find(aaaLeak<1e-11))=0;
else
    for i=1:numcorrelation
        denum=i;        % No. of defect
        for   indicator=1:2
            [t,alfa,beta,x]=diaoqu(xin,T_max,numcorrelation) ;
            if indicator==1
                c1{denum}=alfa;
                bet1(denum,:)=beta;
            elseif indicator==2
                c2{denum}=alfa;
                bet2(denum,:)=beta;
            end
        end
    end
    
    cccb=c1;ccel=c2;betaab=bet1;betaal=bet2;
    [P0]=combineburstc(T_max,[cccb ccel],[bet1;bet2],numcorrelation*2);
    cRE_leak=[bet1(:,1:T_max);bet2(:,2:T_max+1)];
    cRE_burst=[bet1(:,2:T_max+1);bet2(:,1:T_max)];
    for i=1:numcorrelation
        ccb0{i}(:,1:T_max) = cccb{i}(:,2:T_max+1);
        ccel0{i}(:,1:T_max) = ccel{i}(:,1:T_max);
        
        ccb1{i}(:,1:T_max) = cccb{i}(:,1:T_max);
        ccel1{i}(:,1:T_max) = ccel{i}(:,2:T_max+1);
    end
    [P0_b]=combineburstc(T_max,cccb,bet1,numcorrelation);
    [P0_l]=combineburstc(T_max,ccel,bet2,numcorrelation);
    [Pb_Delt_leak]=combineburstc(T_max-1,[ccb1 ccel1],cRE_leak,numcorrelation*2);
    [Pb_Delt_burst]=combineburstc(T_max-1,[ccb0 ccel0],cRE_burst,numcorrelation*2);
    Pb_inc=abs(Pb_Delt_burst-P0(1:T_max));
    Pl_inc=abs(Pb_Delt_leak-P0(1:T_max));
    Pb_inc_new=Pb_inc;
    for i=1:length(Pb_inc)-1
        gra_b(i)=Pb_inc(i+1)-Pb_inc(i);
        gra_l(i)=Pl_inc(i+1)-Pl_inc(i);
    end
    t_in=zeros(1,length(Pb_inc)-2);
    for i=1:length(Pb_inc)-3
        if i>1
            if gra_b(i)*gra_b(i+1)<0 && gra_b(i+2)>0
                Pb_inc(i+1)=Pb_inc(i+2)*0.5+Pb_inc(i)*0.5;
                Pl_inc(i+1)=Pl_inc(i+2)*0.5+Pl_inc(i)*0.5;
            end
        end
        if i>1
            if gra_b(i-1)<0 && gra_b(i)*gra_b(i+1)<0
                Pb_inc(i+2)=Pb_inc(i+3)*0.5+Pb_inc(i+1)*0.5;
                Pl_inc(i+2)=Pl_inc(i+3)*0.5+Pl_inc(i+1)*0.5;
            end
        end
    end
    
    for t=1:T_max+1
        if t==1
            Pb_I(t)=P0_b(1);
            Pl_I(t)=P0_l(1);
        else
            Pb_I(t)= (Pb_inc(t-1))/(1-P0_b(1));
            Pl_I(t)= (Pl_inc(t-1))/(1-P0_l(1));
        end
    end
    
    [anburst,anleak,cburst,cleak]=diaoqusim3(xin,initialcre,T_max,numcorrelation,numsimulation);
    
    
    
    aaaBurst_update=anburst(2:end)-anburst(1:end-1);
    aaaBurst_=[anburst(1) aaaBurst_update];
    
    anleak_update=anleak(2:end)-anleak(1:end-1);
    anleak_=[anleak(1) anleak_update];
    
    aaaBurst = [Pb_I'  aaaBurst_'];
    aaaLeak = [Pl_I'  anleak_'];
    
    aaaBurst(find(aaaBurst<1e-11))=0;
    aaaLeak(find(aaaLeak<1e-11))=0;
    
end



% % plot(1:T_max+1,aaaBurst)
% % figure
% % plot(1:T_max+1,anleak)
