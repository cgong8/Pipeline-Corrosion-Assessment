clear all;
clc;
%currentFolder = pwd;
T=readtable('PipReliaby_interface.xlsm');
T_max=str2num(cell2mat(T{1,6}));numsimulation=str2num(cell2mat(T{1,2}));
model_sel=str2num(cell2mat(T{1,4}));
FORM_in=str2num(cell2mat(T{1,8}));

B=[];L=[];
for i=1:length(T{12:end,1})
     [xin]=tiquxin(T,i);
     i
     [aaaBurst{i},aaaLeak{i}]=group_program_copy(T_max,model_sel,numsimulation,xin,FORM_in);    
     B(:,i)=[aaaBurst{i}']; 
     L(:,i)=[aaaLeak{i}'];
end
plot(1:11,log(B))