function Std_d_t=fun_StD_d_t(measurement, acc,conf,t)
% fun_StD_d_t_MFL,
% input: acc_recl (-+ 0.2 of t, -+ 0.3 of t)
%        conf (0.8 0.9)
% fun_StD_d_t_MFL=    @(acc_rel,conf)round(acc_rel./(norminv(0.5+conf/2)),2);
% fun_StD_d_t_UT,
% input: acc_abs (-+ 0.5 mm)
%        conf (0.8 0.9)
% fun_StD_d_t_UT=     @(acc_abs,conf)round(sqrt(2).*acc_abs./(norminv(0.5+conf/2)),2);
switch measurement
    case 'MFL'
        Std_d_t=   round(acc./(norminv(0.5+conf/2)),2);
    case 'UT'
        Std_d_t=   round(sqrt(2).*acc./(t.*norminv(0.5+conf/2)),4);
    otherwise
        warning('***函数fun_get_xi未收到合法的measurement!');
end
end