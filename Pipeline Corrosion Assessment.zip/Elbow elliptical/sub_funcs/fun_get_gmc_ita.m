function [gamma_mc,ita]=fun_get_gmc_ita(safety_class)
switch safety_class
    case 'low'
        gamma_mc=0.85; ita=1;
    case 'normal'
        gamma_mc=0.8; ita=0.9;

    case 'high'
        gamma_mc=0.75; ita=0.8;
    otherwise
        warning('***函数fun_get_gmc_ita未收到合法的Safety Class!');
end
end