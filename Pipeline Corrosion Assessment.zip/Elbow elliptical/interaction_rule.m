clear all
clc;
defectmtrixl=xlsread ('cluster-1.xlsx');
defectmatrix_unfinishedl='defectmtrix1';
defectmatrix_unfinishedl(:,1)=0;
defectmtrix=defectmatrix_unfinishedl(end:-1:1,:);
defectmtrix=abs(defectmtrix);


final_matrix=zeros(length(defectmtrix(1))+1,length(defectmtrix(1,:))+2);
final_matrix(2:(length(defectmtrix(:,1))+1),3:end)=defectmtrix;

AOD=408.2;
pipethickness=6.2; 

scan_long_start=1000;
scan_start_angle=200;
scan_end_angle=347;

longitudinal_lim=25.4;
circumferential_lim=6*pipethickness;


for i=1:length(final_matrix(1,:))
final_matrix(1,i)=scan_long_start-4+2*(i-1);
end

for j=1:length(final_matrix(2:end,1))
final_matrix(j+1,2)=0+1*(j-1);
end

incremental=round((scan_end_angle-scan_start_angle)/(length(final_matrix(2:end,1))-1),4);
for j=1:length(final_matrix(2:end,1))
final_matrix(j+1,1)=scan_start_angle+incremental*(j-1);
end

plot_final_matrix=final_matrix;

%here,remove the corrosion_depth < 10% of the wall thickness
depth_correction_matrix=final_matrix(2:end,3:end);
depth_correction_matrix(depth_correction_matrix<=(0.1*pipethickness))=0;
final_matrix(2:end,3:end)=depth_correction_matrix;


%
connect_component=bwlabel(depth_correction_matrix);
defect_amount=max(max(connect_component));

%Here,I want to generate a new matrix,the row is the defect number (from 1 to defect amount)
%the 4 columns are the_coordiates of four borders

border_matrix=zeros(defect_amount,4);
border_matrix_coor=zeros(defect_amount,5);

for i=1:defect_amount
[row_index,column_index]=find(connect_component==i);
border_matrix(i,1)=min(row_index)+1;
border_matrix(i,2)=max(row_index)+1;
border_matrix(i,3)=min(column_index)+2;
border_matrix(i,4)=max(column_index)+2;
border_matrix(i,5)=max(depth_correction_matrix(connect_component==i));
end

%Here,the border matrix contains the index of the position in the matrix,
%The position should be expressed as the coordinate of the scanning

circumferential_coordinates=final_matrix(:,2);
longitudinal_coordinates=final_matrix(1,:);


%grouping all the points together
%by using 1 inch * 6wt

border_matrix_coor(:,1)=1:defect_amount;
border_matrix_coor(:,2)=circumferential_coordinates(border_matrix(:,1))-1;      %2nd_column_of_border_matrix_is_the_upper_bound_in_circumferential_direction
border_matrix_coor(:,3)=circumferential_coordinates(border_matrix(:,2));        %3rd_column_of_border_matrix_is_the_lower_bound_in_circumferential_direction
border_matrix_coor(:,4)=(longitudinal_coordinates(border_matrix(:,3))-2)*6*pipethickness/25.4;%4th_column_of_border_matrix_is_the_lower_bound_in_longitudinal_direction
border_matrix_coor(:,5)=(longitudinal_coordinates(border_matrix(:,4)))*6*pipethickness/25.4;%5th_column_of_border_matrix_is_the_upper_bound_in_longitudinal_directionfirst_point=Iborder_matrix_coor(:4),border_matrix_coor(:2)]:


first_point=[border_matrix_coor(:,4),border_matrix_coor(:,2)];
second_point=[border_matrix_coor(:,4),border_matrix_coor(:,3)];
third_point=[border_matrix_coor(:,5),border_matrix_coor(:,3)];
forth_point=[border_matrix_coor(:,5),border_matrix_coor(:,2)];


length_defect=border_matrix_coor(:,5)-border_matrix_coor(:,4);
width_defect=border_matrix_coor(:,3)-border_matrix_coor(:,2);


all_points=[];
for i=1:defect_amount
defect_position(i)=length(all_points)+1;
defect_length=border_matrix_coor(i,5)-border_matrix_coor(i,4);
defect_width=border_matrix_coor(i,3)-border_matrix_coor(i,2);
if defect_length<6*pipethickness & defect_width<6*pipethickness
all_points=[all_points;first_point(i,:);second_point(i,:);third_point(i,:);forth_point(i,:)];

elseif defect_length <= 6*pipethickness & defect_width>6*pipethickness

    
pieces_width=ceil(defect_width/6/pipethickness);
interpolated_points_cir=setdiff(linspace(0,1,pieces_width+1),[0,1]);
%_this_is_for_the_left_border
upper_border=repmat(border_matrix_coor(i,2),pieces_width-1,1);
left_border_2nd_column=upper_border+repmat_(defect_width,pieces_width-1,1).*interpolated_points_cir';
left_border_1st_column=repmat(border_matrix_coor(i,4),(pieces_width-1),1);
%this_is_for_the_right_border
upper_border=repmat(border_matrix_coor(i,2),pieces_width-1,1);
right_border_2nd_colujnn=upper_border+repmat_(defect_width,pieces_width-1,1).*interpolated_points_cir';
right_border_1st_column=repmat_(border_matrix_coor(i,5),(pieces_width-1),1);
all_points=[all_points;first_point(i,:),second_point(i,:);third_point(i,:);forth_point(i,:);
    left_border_1st_column,left_border_2nd_column;...
    right_border_1st_column,right_border_2nd_column];

elseif defect_length>6*pipethickness & defect_width_<=6*pipethickness
    
pieces_length=ceil(defect_length/6/pipethickness);
interpolated_points_long=setdiff_(linspace_(0,1,pieces_length+1),[0,1]);
%this_is_for_the_upper_border
left_border=repmat_(border_matrix_coor(i,4),pieces_length-1,1);
upper_border_1st_column=left_border+repmat_(defect_length,pieces_length-1,1).*interpolated_points_long';
upper_border_2nd_column=repmat_(border_matrix_coor(i,2),(pieces_length-1),1);
%this_is_for_the_lower_border
left_border=repmat_(border_matrix_coor(i,4),pieces_length-1,1);
lower_border_1st_column=left_border+repmat(defect_length,pieces_length-1,1).*interpolated_points_long';
lower_border_2nd_column=repmat_(border_matrix_coor(i,3),(pieces_length-1),1);

all_points=[all_points;first_point(i,:),second_point(i,:);third_point(i,:);forth_point(i,:);
upper_border_1st_column,upper_border_2nd_column;...
lower_border_1st_column,lower_border_2nd_column];
else

pieces_length=ceil(defect_length/6/pipethickness);
pieces_width=ceil(defect_width/6/pipethickness);
interpolated_points_cir=setdiff_(linspace_(0,1,pieces_width+1),[0,1]);
interpolated_points_long=setdiff(linspace_(0,1,pieces_length+1),[0,1]);
%this is for the left border
upper_border=repmat_(border_matrix_coor(i,2),pieces_width-1,1);
left_border_2nd_column=upper_border+repmat_(defect_width,pieces_width-1,1).*interpolated_points_cir';
left_border_1st_column=repmat(border_matrix_coor(i,4),(pieces_width-1),1);
%this is for the right border
upper_border=repmat_(border_matrix_coor(i,2),pieces_width-1,1);
right_border_2nd_column=upper_border+repmat_(defect_width,pieces_width-1,1).*interpolated_points_cir';
right_border_1st_column=repmat(border_matrix_coor(i,5),(pieces_width-1),1);
%this is for the upper border
left_border=repmat_(border_matrix_coor_(i,4),pieces_length-1,1);
upper_border_1st_column=left_border+repmat_(defect_length,pieces_length-1,1).*interpolated_points_long';
upper_border_2nd_column=repmat(border_matrix_coor(i,2),(pieces_length-1),1);
%this is for the lower border
left_border=repmat_(border_matrix_coor_(i,4),pieces_length-1,1);
low_border_1st_column=left_border+repmat_(defect_length,pieces_length-1,1).*interpolated_points_long';
low_border_2nd_column=repmat(border_matrix_coor(i,3),(pieces_length-1),1);
 
all_points=[all_points;first_point(i,:),second_point(i,:);third_point(i,:);forth_point(i,:);
    left_boder_1st_column,left_boder_2nd_column;...
    right_border_1st_column,right_border_2nd_column;...
    upper_border_1st_column,upper_border_2nd_column;...
    lower_border_1st_column,lower_border_2nd_column];


end
end









%scatter(al1_points(:,1),al1_points(:,2))

x_dist=pdist(all_points,'chebychev');
X_coor_tree=linkage(x_dist,'single');
X_cluster=cluster(X_coor_tree,'Cutoff',6*pipethickness,'Criterion','distance');
cluster_each_point=X_cluster(defect_position(1:end));

for i=1:max(cluster_each_point)
    cluster_length(i,1)=[(max(border_matrix_coor(cluster_each_point==i,5))-min(border_matrix_coor(cluster_each_point==i,4)))*25.4/6/pipethickness]';
    cluster_width(i,1)=(max(border_matrix_coor(cluster_each_point==i,3))-min(border_matrix_coor(cluster_each_point==i,2)));
end
[cluster_length,cluster_width];



