clear all;
clc;

[status1, message1, messageid1] = rmdir('Finite_element_picture','s');
[status2, msg2, msgID2] = mkdir('Finite_element_picture');
[status, message, messageid] = rmdir('burst_capacity_folder','s');
[status4, msg4, msgID4] = mkdir('burst_capacity_folder');

currentFolder = pwd;
ansys_path = '"C:\Program Files\ANSYS Inc\v192\ansys\bin\winx64\ANSYS192.exe"' ;
% ansys_path = '"E:\ansys\ANSYS Inc\v192\ANSYS\bin\winx64\ANSYS192.exe"'; 
workname='straight_elliptical_corrosion.xlsx';
T=readtable(workname);
C = table2cell(T);
C(cellfun(@(x) isempty(x), C)) = {NaN};
C(cellfun(@(x) ischar(x), C)) = {NaN};
T = cell2table(C, 'VariableNames', T.Properties.VariableNames);

cluster_ID_unique=unique(T{:,2});
feature_ID=T{:,1};
cluster_ID=T{:,2};
longitudinal_center=T{:,3};
cir_center=T{:,4};
D_all=T{:,5};
wall_thickness=T{:,6};
corrosion_type_all=T{:,7};
defect_depth_all=T{:,8};
defect_length_all=T{:,9};
defect_width_all=T{:,10};
E_value_all=T{:,11};
YS_all=T{:,12};                         % yield strength
UTS_all=T{:,13};                       % UTS
Axial_Force_Pre_all=T{:,14};
axial_force_all=T{:,15};
operating_pressure=T{:,16};
ELE_size=T{:,17};
Substep_number_all=T{:,18};
DNV_COM_indicator=T{:,19};
Psqr_indicator=T{:,20};
FEM_indicator=T{:,21};

filename3=['jindu.txt'];
delete(filename3);
str = sprintf('jindu.txt');
fid=fopen(str,'wt');
fprintf(fid,'%d',length(cluster_ID_unique));


c_c=[];
for iii=1:length(cluster_ID_unique)
    cd (currentFolder);
    
    cluster_ID_temp=find(cluster_ID==cluster_ID_unique(iii));
    FEM_indicator_temp=FEM_indicator(cluster_ID_temp);
    lia=ismember(1, FEM_indicator_temp);
    if lia == 0
        fprintf(fid,'\n');
        fprintf(fid,'%d',iii);
    else
        fprintf(fid,'\n');
        fprintf(fid,'%d=%d',iii,cluster_ID_unique(iii));
    end
	
	
  try
        
    ID_no=cluster_ID_unique(iii);
    index_no=find(cluster_ID==ID_no);
    pipethickness=wall_thickness(index_no(1));
    t=wall_thickness(index_no(1));
    pipe_thickness=t;
    Operating_Pressure=operating_pressure(index_no(1));
    D=D_all(index_no(1));                             % this should also be included in the table
    E_value=E_value_all(index_no(1));
    SMYS=YS_all(index_no(1));                                     % must be positive (MPa)
    SMTS=UTS_all(index_no(1));
    Substep_number=Substep_number_all(index_no(1));
    AOD=D;
    
    if ismember(1, Psqr_indicator(index_no))==0
        P2_indicator=0;
    else
        P2_indicator=1;
    end
    
    if ismember(1, DNV_COM_indicator(index_no))==0
        DNV_COM_ind=0;
    else
        DNV_COM_ind=1;
    end
    
    if ismember(1, FEM_indicator(index_no))==0
        F_ind=0;
    else
        F_ind=1;
    end
    
    if isnan(ELE_size(index_no(1)))
        element_size=2;
    else
        element_size=ELE_size(index_no(1));
    end
    element_size_x=element_size;
    element_size_y=element_size;
    
    longitudinal_position = longitudinal_center(index_no,1)*1000;
    circumferential_position_hh_mm=cir_center(index_no,1);
    cir_clock_degree_radian=circumferential_position_hh_mm*4*pi;
    % this should be converted to the mm
    circumferential_position=circumferential_position_hh_mm*2*3.14*D;  % in the unit of (mm)
    circumferential_position_hh_mm=[];
        
    %%%%%%%%%%��ʴȱ�ݴ�С
    defect_length=defect_length_all(index_no);                                           % for example, the 4rd column is the defect length (but convert it to the (mm)
    defect_width=defect_width_all(index_no);                                             % for example, the 5th column is the defect width (but convert it to the (mm)
    defect_depth=defect_depth_all(index_no)/100*t;                                       % for example, the 6th column is the defect depth in the unit of mm


    %%%%ȫ����ʴ�ı߽�ߴ磬Ψһ
    long_start =  min(longitudinal_position   -  defect_length/2);
    long_end   =  max(longitudinal_position    +  defect_length/2);
    cir_start  =  min(circumferential_position -  defect_width/2);
    cir_end    =  max(circumferential_position +  defect_width/2);
    cir_move   =  (cir_start+cir_end)/2-pi*D/2;
    
    %%%%%�������ĺ���������
    cluster_cir_center=circumferential_position-cir_move;
    cluster_long_center =  longitudinal_position-min(longitudinal_position)+max(defect_length);
    %%%ÿ����ʴ�ĳ���
    cluster_length = long_end -  long_start ;
    cluster_width  = cir_end  -  cir_start  ;
    %%%ÿ����ʴ�ı߽�
    cluster_long_start = cluster_long_center - defect_length/2;
    cluster_long_end   =  cluster_long_center + defect_length/2;
    cluster_cir_start  =  round(circumferential_position-cir_move-defect_width/2);
    cluster_cir_end    =  round(cluster_cir_start  +  defect_width);
    
    %%%%%������ʴ�صı߽�
    long_start =  min(cluster_long_start);
    long_end   =  max(cluster_long_end);
    cir_start  =  min(cluster_cir_start);
    cir_end    =  max(cluster_cir_end);
    
    %%%%%��ʴ�ر�Ե����ʴ���߽�ľ���
    border_length=10*element_size;
    %%%%%��ʴ��������չ��ı߽�
    startlong_fine  = long_start -  border_length;
    endlong_fine    = long_end   +  border_length;
    startcircum_fine= cir_start  -  border_length;
    endcircum_fine  = cir_end    +  border_length;
    
    corrosion_cluster_num_long =  round(cluster_length/element_size)+1;
    corrosion_cluster_num_cir  =  round(cluster_width /element_size)+1;
    
    Cluster_corrosion_profile=zeros(corrosion_cluster_num_cir,corrosion_cluster_num_long);
    
    
    for j=1:length(index_no)
        x_coor = linspace(long_start,long_end,corrosion_cluster_num_long);
        y_coor = linspace(cir_start,cir_end,corrosion_cluster_num_cir);
        
        for i_x=1:length(x_coor)
            if  x_coor(i_x)<cluster_long_start(j) || x_coor(i_x)>cluster_long_end(j)
                x_coor(i_x) = 0;
            end
        end
        for i_y=1:length(y_coor)
            if  y_coor(i_y)<cluster_cir_start(j) || y_coor(i_y)>cluster_cir_end(j)
                y_coor(i_y) = 0;
            end
        end
        [X_coor,Y_coor]=meshgrid(x_coor,y_coor);
        z_squared=defect_depth(j)^2*(1-(X_coor-cluster_long_center(j)).^2/(defect_length(j)/2)^2-(Y_coor-cluster_cir_center(j)).^2/(defect_width(j)/2)^2);
        z_squared(z_squared<0)=0;
        Cluster_corrosion_profile_supplement=sqrt(z_squared);
        overlapped_elements=max(Cluster_corrosion_profile(Cluster_corrosion_profile_supplement>0),Cluster_corrosion_profile_supplement(Cluster_corrosion_profile_supplement>0));
        Cluster_corrosion_profile=Cluster_corrosion_profile+Cluster_corrosion_profile_supplement;
        Cluster_corrosion_profile(Cluster_corrosion_profile_supplement>0)=overlapped_elements;
    end

    
    if   defect_depth ~= 0
    cc_e=0;cc=0;
    aa=sum(Cluster_corrosion_profile,1);
    for i=1:length(aa)
        if sum(aa(1:i))==0
            cc=i;
        end
        if sum(aa(length(aa)-i+1:length(aa)))==0
            cc_e=i;
        end
    end
    if cc>0
        Cluster_corrosion_profile(:,1:cc)=[];
    end
    if cc_e>0
        Cluster_corrosion_profile(:,end-cc_e+1:end)=[];
    end
    cc=[];cc_e=[];aa=[];
    
    cc_e=0;cc=0;
    bb=sum(Cluster_corrosion_profile,2);
    for i=1:length(bb)
        if sum(bb(1:i))==0
            cc=i;
        end
        if sum(bb(length(bb)-i+1:length(bb)))==0
            cc_e=i;
        end
    end
    if cc>0
        Cluster_corrosion_profile(1:cc,:)=[];
    end
    if cc_e>0
        Cluster_corrosion_profile(end-cc_e+1:end,:)=[];
    end
    cc=[];cc_e=[];bb=[];
    end
    
    Cluster_corrosion_profile2=Cluster_corrosion_profile;
    
    Cluster_corrosion_profile1=zeros(length(Cluster_corrosion_profile(:,1))+2,length(Cluster_corrosion_profile(1,:))+2);
    
    Cluster_corrosion_profile1(2:end-1,2:end-1)=Cluster_corrosion_profile2;
    
    Cluster_corrosion_profile=[];
    Cluster_corrosion_profile2=[];
    
    
  
    
    [Pb_simple(iii,:)]=model_selection_quick(Cluster_corrosion_profile1,SMYS,SMTS,D,pipethickness,element_size);
    if P2_indicator==1 && length(Cluster_corrosion_profile1(1,:))>=3
        [Pb_sqrt(iii)]=Psqr(Cluster_corrosion_profile1,SMYS,D,pipethickness,element_size);
    else
        Pb_sqrt(iii)=0;
    end
    
    
    if DNV_COM_ind ==1 && length(Cluster_corrosion_profile1(1,:))>=3
        [DNV_com(iii)]=DNV_model_v3(Cluster_corrosion_profile1,element_size, AOD, pipethickness, SMTS);
    else
        DNV_com(iii)=0;
    end
    
    if F_ind==1
        folder = 'burst_capacity_folder';  % ָ���ļ���·��
        files = fullfile(folder, '*');  % ƥ���ļ����������ļ�
        delete(files);  % ɾ�������ļ�
        
        [result]=APDL_model_generation_ellipse(ansys_path,workname,E_value,iii,iii);
        inter_tr=cell2mat(result(iii,2));
        Pb_FEM(iii)=inter_tr;
    else
        Pb_FEM(iii)=0;
    end
    
    c_c1=[];
   c_c1=[ID_no D SMYS SMTS pipethickness Operating_Pressure max(max(Cluster_corrosion_profile1))/pipethickness*100 element_size*(length(Cluster_corrosion_profile1(1,:))-1)  Pb_simple(iii,:)  DNV_com(iii) Pb_sqrt(iii) Pb_FEM(iii)];
    
    
catch
         cd (currentFolder);
         c_c1=-ones(1,16)*100;
         c_c1(1,1)=ID_no;
 end
    
    c_c=[c_c;c_c1];

end

filename=['straight_elliptical_corrosion_burst_capacity.xlsx'];
TEMP=readtable(filename);
[hang,lie] = size(TEMP);
x=' ';
xlswrite(filename,x,['A3:P',num2str(hang+1)]);
xlswrite(filename,c_c,['A3:P',num2str(length(cluster_ID_unique)+2)]);
fclose('all')