function [result]=APDL_model_generation_ellipse(ansys_path,workname,E_value,start_cluster_ID,end_cluster_ID)

currentFolder = pwd;
T=readtable(workname);
C = table2cell(T);
C(cellfun(@(x) isempty(x), C)) = {NaN};
C(cellfun(@(x) ischar(x), C)) = {NaN};
T = cell2table(C, 'VariableNames', T.Properties.VariableNames);

cluster_ID_unique=unique(T{:,2});      % unique parent cluster ID
cluster_ID=T{:,2};                     % parent cluster ID
feature_ID=T{:,1};                     % child corrosion anomaly ID

if length(cluster_ID)~=length(feature_ID)
    disp ("Error! every child anomaly should belong to a cluster,simulation terminates")
    return
end

longitudinal_center=T{:,3};            % longitudinal coordinate of the corrosion anomaly
cir_center_all=T{:,4};                     % circumferential coordinate of the corrosion anomaly
D_all=T{:,5};
wall_thickness_all=T{:,6};
corrosion_type_all=T{:,7};
defect_depth_all=T{:,8};
defect_length_all=T{:,9};
defect_width_all=T{:,10};
E_value_all=T{:,11};
YS_all=T{:,12};                         % yield strength
UTS_all=T{:,13};                       % UTS
Axial_Force_Pre_all=T{:,14};
axial_force_all=T{:,15};
ELE_size=T{:,17};
Substep_number_all=T{:,18};

ans = dos('md burst_capacity_folder');       % generate the folder to save all the files

for iii=start_cluster_ID:end_cluster_ID
    % axial stress incompatible warning: a cluster must have the same axial stress
    cd (currentFolder);
    ID_no=cluster_ID_unique(iii);
    index_no=find(cluster_ID==ID_no);
    t=wall_thickness_all(index_no(1));
    D=D_all(index_no(1));
    E_value=E_value_all(index_no(1));
    corrosion_type=corrosion_type_all(index_no);
    Substep_number=Substep_number_all(index_no(1));
    %��ʴ��Ϣ
    defect_length=defect_length_all(index_no);                                           % for example, the 4rd column is the defect length (but convert it to the (mm)
    defect_width=defect_width_all(index_no);                                             % for example, the 5th column is the defect width (but convert it to the (mm)
    defect_depth=defect_depth_all(index_no)/100*t;                                       % for example, the 6th column is the defect depth in the unit of mm
    cluster_size_min=min(defect_length,defect_width);
    
    
    if length(unique(wall_thickness_all(index_no)))>1
        disp ("Error! wall thickness for a cluster shoould be consistent,simulation terminates")
    end
    
    if length(unique(YS_all(index_no)))>1
        disp ("Error! Yield strength for a cluster shoould be consistent,simulation terminates")
        return;
    end
    
    if length(unique(UTS_all(index_no)))>1
        disp ("Error! UTS for a cluster should be consistent,simulation terminates")
      return;
    end
    
    
    element_size= D * pi / 16;                                 % I assume at least 16 elements should be created along the circumference
    translation_element_layer=min(3,max(round(element_size/54),1));        % the layer amount of transitional element should be between 1 and 3, that is the element size for defect free part is between 2 and 54
    
    if defect_depth~=0
        if isnan(ELE_size(index_no(1)))
            element_size=2;
        else
            element_size=ELE_size(index_no(1));
        end
    else
        %��ȱ�����
        translation_element_layer=0;
        element_size=pi*D/40;
    end
    element_size_x=element_size;
    element_size_y=element_size;
    
    % element size in the corrosion free area (mm)
    circumsurround=element_size_y*3^translation_element_layer;
    longsurround=element_size_x*3^translation_element_layer;
    
    
    %%%Ĭ��Ϊ�ⸯʴ
    if isnan(corrosion_type)
        corrosion_type=1;
    end
    %%%���õ���ģ��Ĭ��ֵ
    if isnan(E_value)
        E_value=200000;
    end
    %%%���û������Ӳ���
    if isnan(Substep_number)
        Substep_number=400;
    end
    %�ж��Ƿ���ѹ����Ӧ������
    if isnan(Axial_Force_Pre_all(index_no))
        Axial_Force_Pre=0;
    else
        Axial_Force_Pre=Axial_Force_Pre_all(index_no(1));
    end
    %�ж��Ƿ�����������
    if isnan(axial_force_all(index_no))
        axial_force=0;
    else
        axial_force=axial_force_all(index_no(1));
    end
    
    
    
    % this should be converted to the mm
    longitudinal_position = longitudinal_center(index_no,1)*1000; 
    circumferential_position_hh_mm=cir_center_all(index_no,1);
    circumferential_position=circumferential_position_hh_mm*2*pi*D;  % in the unit of (mm)
    
    
    defect_length=defect_length_all(index_no);                                           % for example, the 4rd column is the defect length (but convert it to the (mm)
    defect_width=defect_width_all(index_no);                                             % for example, the 5th column is the defect width (but convert it to the (mm)
    defect_depth=defect_depth_all(index_no)/100*t;                                       % for example, the 6th column is the defect depth in the unit of mm
    % relative_circumferential=circumferential_position-min(circumferential_position);     % relative position of all the corrosion defects along the circumferential direction
    
    % here, determine the length/width of the corrosion cluster in the
    % FEA model
    %%%%ȫ����ʴ�ı߽�ߴ磬Ψһ
    long_start =  min(longitudinal_position   -  defect_length/2);
    long_end   =  max(longitudinal_position    +  defect_length/2);
    cir_start  =  min(circumferential_position -  defect_width/2);
    cir_end    =  max(circumferential_position +  defect_width/2);
    cir_move   =  (cir_start+cir_end)/2-pi*D/2;
    
    
    
    %%%%%�������ĺ���������
    cluster_cir_center=circumferential_position-cir_move;
    cluster_long_center =  longitudinal_position-min(longitudinal_position)+max(defect_length);
    %%%ÿ����ʴ�ĳ���
    cluster_length = long_end -  long_start ;
    cluster_width  = cir_end  -  cir_start  ;
    %%%ÿ����ʴ�ı߽�
    cluster_long_start = cluster_long_center - defect_length/2;
    cluster_long_end   =  cluster_long_center + defect_length/2;
    cluster_cir_start  =  round(circumferential_position-cir_move-defect_width/2);
    cluster_cir_end    =  round(cluster_cir_start  +  defect_width);
    
    %%%%%������ʴ�صı߽�
    long_start =  min(cluster_long_start);
    long_end   =  max(cluster_long_end);
    cir_start  =  min(cluster_cir_start);
    cir_end    =  max(cluster_cir_end);
    
    %%%%%��ʴ�ر�Ե����ʴ���߽�ľ���
    border_length=8;
    %%%%%��ʴ��������չ��ı߽�
    startlong_fine  = long_start -  border_length;
    endlong_fine    = long_end   +  border_length;
    startcircum_fine= cir_start  -  border_length;
    endcircum_fine  = cir_end    +  border_length;
    
    
    cir_center=(startcircum_fine+endcircum_fine)/2;
    % compare the cluster width to prevent the corrosion area to be too wide
    corrosion_cluster_width_limit = D * pi * 2 / 3;
    if cluster_width >= corrosion_cluster_width_limit
        disp ("Corrosion feature is too wide, simulation teminates")
        continue;
    end
    
    corrosion_cluster_num_long =  round(cluster_length/element_size)+1;
    corrosion_cluster_num_cir  =  round(cluster_width /element_size)+1;
    
    
    Cluster_corrosion_profile=zeros(corrosion_cluster_num_cir,corrosion_cluster_num_long);
    for j=1:length(index_no)
        x_coor = linspace(startlong_fine,endlong_fine,corrosion_cluster_num_long);
        y_coor = linspace(startcircum_fine,endcircum_fine,corrosion_cluster_num_cir);
        
        for i_x=1:length(x_coor)
            if  x_coor(i_x)<cluster_long_start(j) || x_coor(i_x)>cluster_long_end(j)
                x_coor(i_x) = 0;
            end
        end
        for i_y=1:length(y_coor)
            if  y_coor(i_y)<cluster_cir_start(j) || y_coor(i_y)>cluster_cir_end(j)
                y_coor(i_y) = 0;
            end
        end
        [X_coor,Y_coor]=meshgrid(x_coor,y_coor);
        z_squared=defect_depth(j)^2*(1-(X_coor-cluster_long_center(j)).^2/(defect_length(j)/2)^2-(Y_coor-cluster_cir_center(j)).^2/(defect_width(j)/2)^2);
        z_squared(z_squared<0)=0;
        Cluster_corrosion_profile_supplement=sqrt(z_squared);
        overlapped_elements=max(Cluster_corrosion_profile(Cluster_corrosion_profile_supplement>0),Cluster_corrosion_profile_supplement(Cluster_corrosion_profile_supplement>0));
        Cluster_corrosion_profile=Cluster_corrosion_profile+Cluster_corrosion_profile_supplement;
        Cluster_corrosion_profile(Cluster_corrosion_profile_supplement>0)=overlapped_elements;
    end
    Cluster=Cluster_corrosion_profile;
    
    
    % This part is the FEA generation part
    % firstly, I want to caculate the stress-strain curve
    % E_value=2e5;                                                          % Young's modulus: must be positive (MPa)
    YS_value=YS_all(index_no(1));                                         % Tield strength : must be positive (MPa)
    UTS_value=UTS_all(index_no(1));                                       % Ultimate tensile strength : must be positive (MPa)
    
    strain_exponential=0.224*(UTS_value/YS_value-1)^0.604;                % Sigma= K *epsilon^n;
    true_ultimate=UTS_value*exp(strain_exponential);
    K=true_ultimate/(strain_exponential^strain_exponential);
    plastic_stress_ansys=linspace(YS_value,true_ultimate+100,20);
    plastic_strain_ansys=(plastic_stress_ansys/K).^(1/strain_exponential);
    plastic_strain_ansys(1)=YS_value/E_value;
    pressure_applied=4*UTS_value*t/D;
    
    outputdata=cat(2,'tbpt,','defi');
    B = repmat(outputdata,[20,1]);
    for ii=1:20
        M{ii}=[B(ii,:),',',num2str(plastic_strain_ansys(ii)),',',num2str(plastic_stress_ansys(ii))];
    end
    
    
    % call ANSYS to generate the mesh on a plate
    fid = fopen('plane_remesh.txt');
    plane_mesh_data= textscan(fid,'%s','delimiter','\n');
    plane_mesh_data{1,1}(7)={['D=',num2str(D)]};
    plane_mesh_data{1,1}(8)={['startlong_fine=',num2str(startlong_fine)]};
    plane_mesh_data{1,1}(9)={['endlong_fine=',num2str(endlong_fine)]};
    plane_mesh_data{1,1}(10)={['startcircum_fine=',num2str(round(startcircum_fine))]};
    plane_mesh_data{1,1}(11)={['endcircum_fine=',num2str(round(endcircum_fine))]};
    plane_mesh_data{1,1}(12)={['circum_increment=',num2str(element_size)]};
    plane_mesh_data{1,1}(13)={['long_increment=',num2str(element_size)]};
    plane_mesh_data{1,1}(14)={['translation_element_layer=',num2str(translation_element_layer)]};
    str = sprintf('plane_element%d.txt',iii);
    fid=fopen(str,'wt');
    [A,B]=size(plane_mesh_data{1,1});
    for i=1:A
        every_row=char(plane_mesh_data{1,1}(i));
        fprintf(fid,'%s\n',every_row);
    end
    every_row=[];
    fclose(fid);
    
    % move the generated file to the newly created folder
    DST_PATH_t = './burst_capacity_folder/';
    movefile(str,DST_PATH_t);
    copyfile('plane_remesh.txt',DST_PATH_t);
    copyfile('node_element_FEA_generation.txt',DST_PATH_t);
    copyfile('cluster_1.txt',DST_PATH_t);
    copyfile('post_process_strain_stress_plot.txt',DST_PATH_t);
    copyfile('corner_element.txt',DST_PATH_t);
    copyfile('corner_nodes.txt',DST_PATH_t);
    copyfile('post_process_strain_stress_plot.txt',DST_PATH_t);
    cd (DST_PATH_t);
    
    
    % call ANSYS to generate the model
    jobname=['model_generation_cluster',num2str(cluster_ID_unique(iii))];
    skriptFileName=['plane_element',num2str(iii),'.txt'];
    outputFilename=['cluster_output.txt'];
    sys_char=strcat('SET KMP_STACKSIZE=4096k &',32,ansys_path,32,...
        '-b -p ansys -i',32,skriptFileName,32,'-j',32,jobname,32,'-o',32,outputFilename),
    ans1=system(sys_char);
    
    
    str = sprintf('node_file.txt');
    Extra_node_information=importdata(str);
    cd(currentFolder);
    num_node_one_layer=length(Extra_node_information);
    internal_radius=D/2-t;
    outer_radius=internal_radius+t;
    radius_1st_layer=internal_radius+(outer_radius-internal_radius)/4*3;
    radius_2nd_layer=internal_radius+(outer_radius-internal_radius)/2;
    radius_3rd_layer=internal_radius+(outer_radius-internal_radius)/4;
    
    % scatter(Extra_node_information(:,1),Extra_node_information(:,2))
    x_coor_node=Extra_node_information(:,1);
    y_coor_node=Extra_node_information(:,2);
    z_coor_node=outer_radius*ones(num_node_one_layer,1);
    
    % inside the corrosion cluster area
    x_index=intersect(find(x_coor_node>=startlong_fine),find(x_coor_node<=endlong_fine));
    y_index=intersect(find(y_coor_node>=startcircum_fine),find(y_coor_node<=endcircum_fine));
    corrosion_region_index=intersect(x_index,y_index);
    x_coor_Cluster= linspace( startlong_fine,endlong_fine,corrosion_cluster_num_long);
    y_coor_Cluster = linspace(startcircum_fine,endcircum_fine,corrosion_cluster_num_cir);
    [X_coor_Cluster,Y_coor_Cluster]=meshgrid(x_coor_Cluster,y_coor_Cluster);
    vq = griddata(X_coor_Cluster,Y_coor_Cluster,Cluster,x_coor_node(corrosion_region_index),y_coor_node(corrosion_region_index),'nearest');
    vq( vq<0)=0;
    long_index = intersect(find(x_coor_node>startlong_fine-(translation_element_layer+1)*longsurround),find(x_coor_node<endlong_fine+(translation_element_layer+1)*longsurround));
    cir_index  = intersect(find(y_coor_node>startcircum_fine-(translation_element_layer+1)*longsurround),find(y_coor_node<endcircum_fine+(translation_element_layer+1)*longsurround));
    node_selected_index_inside = intersect(long_index,cir_index);

    %%%%%%1��ʾ�ⸯʴ��0��ʾ�ڸ�ʴ
    if corrosion_type==1
        z_coor_node(corrosion_region_index)=outer_radius-vq;
        % now, generate all the node and elements
        x_coor_all_node_inside=repmat(x_coor_node(node_selected_index_inside),5,1);
        y_coor_all_node_inside=repmat(y_coor_node(node_selected_index_inside),5,1);
        z_coor_all_node_inside=[z_coor_node(node_selected_index_inside);3/4*z_coor_node(node_selected_index_inside)+1/4*internal_radius;2/4*z_coor_node(node_selected_index_inside)+2/4*internal_radius;1/4*z_coor_node(node_selected_index_inside)+3/4*internal_radius;0/4*z_coor_node(node_selected_index_inside)+4/4*internal_radius];
    else
        z_coor_node( node_selected_index_inside)=internal_radius;
        z_coor_node(corrosion_region_index)= internal_radius+vq;
        % now, generate all the node and elements
        x_coor_all_node_inside=repmat(x_coor_node(node_selected_index_inside),5,1);
        y_coor_all_node_inside=repmat(y_coor_node(node_selected_index_inside),5,1);
        z_coor_all_node_inside=[0*z_coor_node(node_selected_index_inside)+outer_radius;1/4*z_coor_node(node_selected_index_inside)+3/4*outer_radius;2/4*z_coor_node(node_selected_index_inside)+2/4*outer_radius;3/4*z_coor_node(node_selected_index_inside)+1/4*outer_radius; z_coor_node(node_selected_index_inside);];
    end
    node_coor_matrix_inside=[[node_selected_index_inside;node_selected_index_inside+num_node_one_layer;node_selected_index_inside+num_node_one_layer*2;node_selected_index_inside+num_node_one_layer*3;node_selected_index_inside+num_node_one_layer*4],x_coor_all_node_inside,y_coor_all_node_inside,z_coor_all_node_inside];
    pres_node_index_1=node_selected_index_inside+num_node_one_layer*4; 
    
    
    cd('./burst_capacity_folder/');
    str = sprintf('element_file.txt');
    Extra_element_information=importdata(str);
    cd(currentFolder);
    Lia=ismember(Extra_element_information,node_selected_index_inside);
    element_inside=find(sum(Lia,2)==4);
    num_extra_element=length(element_inside(:,1));
    Extra_element_information=[Extra_element_information(element_inside,:),Extra_element_information(element_inside,:)+num_node_one_layer
        Extra_element_information(element_inside,:)+num_node_one_layer,Extra_element_information(element_inside,:)+2*num_node_one_layer
        Extra_element_information(element_inside,:)+2*num_node_one_layer,Extra_element_information(element_inside,:)+3*num_node_one_layer
        Extra_element_information(element_inside,:)+3*num_node_one_layer,Extra_element_information(element_inside,:)+4*num_node_one_layer];
    Extra_element_first_10=repmat([1,1,1,1,0,0,0,0,8,0],num_extra_element*4,1);
    element_information_inside=[Extra_element_first_10,[1:num_extra_element*4]', Extra_element_information];
    
    % now, it is the outside area
    long_index = union(find(x_coor_node<=startlong_fine-(translation_element_layer+1)*longsurround),find(x_coor_node>=endlong_fine+(translation_element_layer+1)*longsurround));
    cir_index  = union(find(y_coor_node<=startcircum_fine-(translation_element_layer+1)*circumsurround),find(y_coor_node>=endcircum_fine+(translation_element_layer+1)*circumsurround));
    node_selected_index_outside = union(long_index,cir_index);
    x_coor_all_node_outside=repmat(x_coor_node(node_selected_index_outside),3,1);
    y_coor_all_node_outside=repmat(y_coor_node(node_selected_index_outside),3,1);
    z_coor_all_node_outside=[z_coor_node(node_selected_index_outside);2/4*z_coor_node(node_selected_index_outside)+2/4*internal_radius;0/4*z_coor_node(node_selected_index_outside)+4/4*internal_radius];
    node_coor_matrix_outside=[[node_selected_index_outside;node_selected_index_outside+num_node_one_layer;node_selected_index_outside+num_node_one_layer*2],x_coor_all_node_outside,y_coor_all_node_outside,z_coor_all_node_outside];
    pres_node_index_2=node_selected_index_outside+num_node_one_layer*2;
    
    cd('./burst_capacity_folder/');
    str = sprintf('element_file.txt');
    Extra_element_information=importdata(str);
    cd(currentFolder);
    Lia=ismember(Extra_element_information,node_selected_index_outside);
    element_outside=find(sum(Lia,2)==4);
    
    num_extra_element1=length(element_outside(:,1));
    Extra_element_information=[Extra_element_information(element_outside,:),Extra_element_information(element_outside,:)+num_node_one_layer
        Extra_element_information(element_outside,:)+num_node_one_layer,Extra_element_information(element_outside,:)+2*num_node_one_layer];
    
    Extra_element_first_10=repmat([1,1,1,1,0,0,0,0,8,0],num_extra_element1*2,1);
    element_information_outside=[Extra_element_first_10,[(num_extra_element*4+1):(num_extra_element*4+num_extra_element1*2)]', Extra_element_information];
    
    
    % now, generate the transitional element
    
    outside_node_x_west=max(x_coor_node(x_coor_node<startlong_fine-(translation_element_layer+1)*longsurround));
    outside_node_x_east=min(x_coor_node(x_coor_node>endlong_fine+(translation_element_layer+1)*longsurround));
    outside_node_y_north=max(y_coor_node(y_coor_node<startcircum_fine-(translation_element_layer+1)*circumsurround));
    outside_node_y_south=min(y_coor_node(y_coor_node>endcircum_fine+(translation_element_layer+1)*circumsurround));
    
    total_node_matrix=[node_coor_matrix_inside;node_coor_matrix_outside];
    total_element_matrix=[element_information_inside;element_information_outside];
    
    [total_node_matrix,total_element_matrix,force_node_matrix_west]=edge_west(node_coor_matrix_inside,total_element_matrix,t,outside_node_x_west,total_node_matrix);
    [total_node_matrix,total_element_matrix,force_node_matrix_east]=edge_east(node_coor_matrix_inside,total_element_matrix,t,outside_node_x_east,total_node_matrix);
    [total_node_matrix,total_element_matrix,force_node_matrix_north]=edge_north(node_coor_matrix_inside,total_element_matrix,t,outside_node_y_north,total_node_matrix);
    [total_node_matrix,total_element_matrix,force_node_matrix_south]=edge_south(node_coor_matrix_inside,total_element_matrix,t,outside_node_y_south,total_node_matrix);
    [total_node_matrix,total_element_matrix,force_node_matrix_conrner]=conrner_elements(node_coor_matrix_inside,total_element_matrix,t,outside_node_x_east,outside_node_x_west,outside_node_y_north,outside_node_y_south,total_node_matrix);
    total_node_matrix1=total_node_matrix;
    
    %�ҵ���ʴ���ĵ㣬ȷ���۽�λ��
    long_index1 = intersect(find(total_node_matrix(:,2)>=(endlong_fine+startlong_fine)/2-element_size/2),find(total_node_matrix(:,2)<=(endlong_fine+startlong_fine)/2+element_size/2));
    cir_index1  = intersect(find(total_node_matrix(:,3)>=(endcircum_fine+startcircum_fine)/2-element_size/2),find(total_node_matrix(:,3)<=(endcircum_fine+startcircum_fine)/2+element_size/2));
    mid_index= intersect(long_index1,cir_index1);
    
    %�����ڲ����ؽڵ�
    pres_node_index=[pres_node_index_1',pres_node_index_2',force_node_matrix_west,force_node_matrix_east,force_node_matrix_north,force_node_matrix_south,force_node_matrix_conrner]';
    internal_node_index_num=length(pres_node_index);
    %�����ѹ�ڵ���
    cd('./burst_capacity_folder/');
    str = sprintf('pres_node%d.txt',iii);
    fid=fopen(str,'wt');
    fprintf(fid,'%9.0f\n',pres_node_index');
    fclose(fid);
    
    %%%%%%%%ת���������Ϊֱ��
    orientation_arclength=cir_center;
    orientation_degree=((orientation_arclength*360/pi/D)-90)/360*2*pi;
    
    total_node_matrix(:,2)=total_node_matrix1(:,4).*cos(total_node_matrix1(:,3)/D/pi*2*pi-orientation_degree);
    total_node_matrix(:,3)=total_node_matrix1(:,4).*sin(total_node_matrix1(:,3)/D/pi*2*pi-orientation_degree);
    total_node_matrix(:,4)=total_node_matrix1(:,2);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Node information files
    str = sprintf('node_element_information_cluster%d.txt',iii);
    fid=fopen(str,'wt');
    fprintf(fid,'/batch');
    fprintf(fid,'\n');
    fprintf(fid,'/wb,file,start');
    fprintf(fid,'\n');
    fprintf(fid,'/prep7');
    fprintf(fid,'\n');
    fprintf(fid,'SHPP,OFF,,NOWARN');
    fprintf(fid,'\n');
    fprintf(fid,'/nolist');
    fprintf(fid,'\n');
    fprintf(fid,'/com,*********** Nodes for the whole assembly ***********');
    fprintf(fid,'\n');
    fprintf(fid,'csys,0');
    fprintf(fid,'\n');
    fprintf(fid,'nblock,3');
    fprintf(fid,'\n');
    fprintf(fid,'(1i16,3e16.6e2)');
    fprintf(fid,'\n');
    fprintf(fid,'%16.0f%16E%16E%16E\n',total_node_matrix');
    fprintf(fid,'/wb,elem,start');
    fprintf(fid,'\n');
    fprintf(fid,'/com,*********** Elements for Body 1 "Solid" ***********');
    fprintf(fid,'\n');
    fprintf(fid,'et,1,185');
    fprintf(fid,'\n');
    fprintf(fid,'eblock,19,solid,,41503');
    fprintf(fid,'\n');
    fprintf(fid,'(19i16)');
    fprintf(fid,'\n');
    fprintf(fid,'%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f\n', total_element_matrix');
    fclose(fid);
    
    
    mid=total_node_matrix(mid_index,:);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    fid = fopen('cluster_1.txt');
    APDL_data= textscan(fid,'%s','delimiter','\n');
    fclose(fid);
    APDL_data{1,1}(1)={['/input,node_element_information_cluster',num2str(iii),',txt']};
    
    
    if isnumeric(Axial_Force_Pre) | ~isnan(Axial_Force_Pre)
        if Axial_Force_Pre~=0 & ~isnan(Axial_Force_Pre)
            APDL_data{1,1}(9)={['flag_force_pre=1']};
            APDL_data{1,1}(136)={['f,new_nodemax,fz,',num2str(Axial_Force_Pre)]};
        end
    end
    
    if isnumeric(axial_force) | ~isnan(axial_force)
        if axial_force~=0 & ~isnan(axial_force)
            APDL_data{1,1}(10)={['flag_force=1']};
            APDL_data{1,1}(146)={['f,new_nodemax,fz,',num2str(axial_force)]};
        end
    end
    for i=37:56
        APDL_data{1,1}(i)=cellstr(M{i-36});
    end
    
    APDL_data{1,1}(14)={['pipediameter=',num2str(D)]};
    APDL_data{1,1}(15)={['wallthickness=',num2str(t)]};
    APDL_data{1,1}(16)={['Youngs=',num2str(E_value)]};
    APDL_data{1,1}(17)={['startlong_fine=',num2str(startlong_fine)]};
    APDL_data{1,1}(18)={['endlong_fine=',num2str(endlong_fine)]};
    APDL_data{1,1}(19)={['internal_surface_node_num=',num2str(internal_node_index_num)]};
    APDL_data{1,1}(23)={['*vread,internal_surface_node(1),pres_node',num2str(iii),',txt,,ijk,internal_surface_node_num,1']};
    APDL_data{1,1}(73)={['/FOC,1,',num2str(mid(1,2)),',',num2str(mid(1,3)),',',num2str(mid(1,4))]};
    APDL_data{1,1}(81)={['/FOC,1,',num2str(mid(1,2)),',',num2str(mid(1,3)),',',num2str(mid(1,4))]};
    APDL_data{1,1}(82)={['/DIST,1,',num2str(cluster_length*0.8)]};
    APDL_data{1,1}(155)={['sf,all,pres,',num2str(pressure_applied)]};
    APDL_data{1,1}(158)={['nsubst,',num2str(Substep_number)]};
    APDL_data{1,1}(178)={[' /input,post_process_clsuter',num2str(iii),',txt']};
    
    str = sprintf('APDL_file_cluster%d.txt',iii);
    fid=fopen(str,'wt');
    [A,B]=size(APDL_data{1,1});
    for i=1:A
        every_row=char(APDL_data{1,1}(i));
        fprintf(fid,'%s\n',every_row);
    end
    fclose(fid);
   
    every_row=[];
    clear total_node_information;
    clear element_information;
    clear circumferential_position_hh_mm;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % APDL post process file
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    str = sprintf('post_process_clsuter%d.txt',iii);
    fid=fopen(str,'wt');
    fprintf(fid,'*cfopen,stress_cluster%d,txt',iii);
    fprintf(fid,'\n');
    fprintf(fid,'*vwrite,nodemaxs(1,1),nodemaxs(1,2)');
    fprintf(fid,'\n');
    fprintf(fid,'(f20.5,f20.5)');
    fprintf(fid,'\n');
    fprintf(fid,'*cfclos');
    fclose(fid);

    
    cluster_number=iii;
    tic
    jobname=['pipe_burst_test_cluster_',num2str(cluster_ID_unique(cluster_number))];
    skriptFileName=['APDL_file_cluster',num2str(cluster_number),'.txt'];
    outputFilename=['cluster',num2str(cluster_ID_unique(cluster_number)),'_output.txt'];
    sys_char=strcat('SET KMP_STACKSIZE=4096k &',32,ansys_path,32,...
        '-b -p ansys -i',32,skriptFileName,32,...
        '-j',32,jobname,32,...
        '-o',32,outputFilename);
    ans1=system(sys_char);
    toc
    
    i = iii;
    internal_stress_curve=importdata(strcat(['stress_cluster',num2str(i),'.txt']));
    internal_pressure=internal_stress_curve(:,1)* pressure_applied;
    Mises_stress=internal_stress_curve(:,2);
    true_UTS=true_ultimate;
    judge_vector=Mises_stress-true_UTS;
    new_vector=judge_vector(1:end-1).*(judge_vector(2:end));
    possible_points=min(find(new_vector<=0));
    if isempty(possible_points)
        burst_pressure{i,2}=NaN;
    else
        burst_pressure{i,2}=(true_UTS-Mises_stress(possible_points))*(internal_pressure(possible_points+1)-internal_pressure(possible_points))/(Mises_stress(possible_points+1)-Mises_stress(possible_points))+internal_pressure(possible_points);
    end
    burst_pressure{i,1}=i;
    
    
    i =iii;
    if length(burst_pressure{i,2})>1
        continue;
    end
    time_step=burst_pressure{i,2}/pressure_applied;                              % time step
    
    
    internal_stress_curve=importdata(strcat(['stress_cluster',num2str(i),'.txt']));
    FEA_time_step=internal_stress_curve(:,1);
    sub_step_num = find(time_step-FEA_time_step<0,1)-1;                            % this is the sub step number during burst
    
    fid = fopen('post_process_strain_stress_plot.txt');
    post_process_strain_stress= textscan(fid,'%s','delimiter','\n');
    post_process_strain_stress{1,1}(1)={['RESUME,pipe_burst_test_cluster_',num2str(ID_no),',db,,0,0']};
    post_process_strain_stress{1,1}(11)={['SET,,,,,,,',num2str(sub_step_num)]};
    post_process_strain_stress{1,1}(17)={['SET,,,,,,,',num2str(sub_step_num)]};
    
    str = sprintf('post_process_strain_stress_plot%d.txt',i);
    fid=fopen(str,'wt');
    [A,B]=size(post_process_strain_stress{1,1});
    for j=1:A
        every_row=char(post_process_strain_stress{1,1}(j));
        fprintf(fid,'%s\n',every_row);
    end
    every_row=[];
    fclose(fid);
    
    jobname=['pipe_burst_test_cluster_',num2str(ID_no)];
    skriptFileName=['post_process_strain_stress_plot',num2str(i),'.txt'];
    outputFilename=['plot',num2str(i),'_output.txt'];
    sys_char=strcat('SET KMP_STACKSIZE=4096k &',32,ansys_path,32,...
        '-b -p ansys -i',32,skriptFileName,32,...
        '-j',32,jobname,32,...
        '-o',32,outputFilename),
    ans1=system(sys_char);
    
    cd (currentFolder);
    work_folder='./burst_capacity_folder/';                  %ԭʼͼƬ·��
    savepath ='./Finite_element_picture/';                   %���洦�����ͼƬ·��
    file_list=dir(fullfile(work_folder,'*.jpg'));            %��ȡ����·��
    for i1=1:length(file_list)
        im =imread([work_folder,file_list(i1).name]);             %����·����ÿһ��ͼƬ
        imwrite(im,[savepath,file_list(i1).name],'jpg');      %���µ�ͼƬд�뵽ָ���ļ���
    end
    
end

result=burst_pressure;
