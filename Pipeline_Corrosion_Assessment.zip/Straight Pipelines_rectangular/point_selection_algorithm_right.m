function [points_y,points_x,depth_i]=point_selection_algorithm_right(start_point_y,start_point_x,Cluster5,pipethickness,x_coor,y_coor)

half_interaction_window_width=6*pipethickness/2;       
start_point_y_coor=y_coor(start_point_y);
y_coor_difference = abs(y_coor-start_point_y_coor);
possible_index=find(y_coor_difference<=half_interaction_window_width);
intera_point_num=length(possible_index);


% now, calculate the depth of each point
two_dim_index=[(start_point_x+1)*ones(intera_point_num,1),possible_index'];
one_dim_index=sub2ind(size(Cluster5),two_dim_index(:,2),two_dim_index(:,1));
corrosion_depth=Cluster5(one_dim_index);
if sum(corrosion_depth)==0
   corrosion_depth=ones(length(one_dim_index),1);
end
DFi=corrosion_depth/sum(corrosion_depth);
% now, calculate the distance of each point to the anchor point
possible_points_coor=[x_coor(two_dim_index(:,1))',y_coor(two_dim_index(:,2))'];
all_distances=pdist2([x_coor(start_point_x),y_coor(start_point_y)],possible_points_coor);

PFi=all_distances/sum(all_distances);
% now, generate the probability of each point being analyzed
alpha1=0.1;
beta1=0.9;

possibly=alpha1*PFi+beta1*DFi';

% now, generate the next point according to the PDF function

D = cumsum(possibly);
R = rand(1,1); 

index1=find(R<D,1,'first');             % the index1is the index of the cir point
points_x=two_dim_index(index1,1);
points_y=two_dim_index(index1,2);
depth_i=Cluster5(points_y,points_x);
end