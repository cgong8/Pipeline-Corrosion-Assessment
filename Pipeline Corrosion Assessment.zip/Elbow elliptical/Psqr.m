function [Pb_psqr]=Psqr(corrosion_profile,sigmay,AOD,pipethickness,resolution_length)    
% %     AOD=508;
% %     pipethickness=6.35;
% %     sigmay=359;
% %     sigmau=455;
% %         corrosion_profile=corrosion_profile/100*pipethickness;
   % resolution_length=2;
   A = corrosion_profile;
   % 求每�?列的�?大�??
   max_values = max(A);
   
   % 找到这些�?大�?�的列坐�?
   ii=0;
   ccc=[];
   for j=1:length(max_values)
       
       if max_values(j)>0
       gc=find(max_values(j)==A(:,j));
       ii=ii+1;
       ccc(ii)=gc(1);
       end
       
   end
   
   if isempty(ccc)
       diff_max_min=0;
   else   
   diff_max_min = max(ccc) - min(ccc);
   end
   
   
   
   if diff_max_min*resolution_length>6*pipethickness
   
    iiii=1;
    [M,N]=size(corrosion_profile);
    defect_length=resolution_length*(N-1);
    cluster_length(iiii,1)=defect_length;
    cluster_width(iiii,1)=resolution_length*(M-1);

     
   % P2 model
   [M,N]=size(corrosion_profile);
   %resolution_length=2;
   x_coor=[0:resolution_length:resolution_length*N-resolution_length];
   y_coor=[0:resolution_length:resolution_length*M-resolution_length];
   for Monte_carlo_num=1:500
       surface_vector=reshape(corrosion_profile,M*N,1);
    %   a_ran_num=max(1,abs(floor((rand(1,1)-0.0001)*M*N)));
    %   deepest_depth=surface_vector(a_ran_num);
       
       aaa_=surface_vector;

       Prob=surface_vector/sum(surface_vector);
     % save errreee
       deepest_depth=randsrc(1,1,[aaa_';Prob']);
       
       [start_point_y,start_point_x]=find(corrosion_profile==deepest_depth,1,'first');
       
       left_iteration=start_point_x-1;                           % the total number of iteration on left side
       right_iteration=N-start_point_x;                          % the total number of iteration on right side
       start_point_y1=start_point_y;
       start_point_x1=start_point_x;
       start_point_y2=start_point_y;
       start_point_x2=start_point_x;
       start_point_y3=start_point_y;
       start_point_x3=start_point_x;
       start_point_y4=start_point_y;
       start_point_x4=start_point_x;
       if left_iteration==0
           for k=1:right_iteration
               [points_y,points_x,corrosion_depth_right(k)]=point_selection_algorithm_right(start_point_y1,start_point_x1,corrosion_profile,pipethickness,x_coor,y_coor);
               start_point_y1=points_y;
               start_point_x1=points_x;
           end
           failure_profile=[deepest_depth,corrosion_depth_right];
       elseif right_iteration==0
           for k=1:left_iteration
               [points_y,points_x,corrosion_depth_left(k)]=point_selection_algorithm_left(start_point_y2,start_point_x2,corrosion_profile,pipethickness,x_coor,y_coor);
               start_point_y2=points_y;
               start_point_x2=points_x;
           end
       failure_profile=[corrosion_depth_left(end:-1:1),deepest_depth];
                
       elseif right_iteration~=0 && left_iteration~=0
           corrosion_depth_left=zeros(left_iteration,1);
           for j=1:left_iteration
               [points_y,points_x,corrosion_depth_left(j)]=point_selection_algorithm_left(start_point_y3,start_point_x3,corrosion_profile,pipethickness,x_coor,y_coor);
               start_point_y3=points_y;
               start_point_x3=points_x;
           end
           corrosion_depth_right=zeros(right_iteration,1);
           for k=1:right_iteration
               [points_y,points_x,corrosion_depth_right(k)]=point_selection_algorithm_right(start_point_y4,start_point_x4,corrosion_profile,pipethickness,x_coor,y_coor);
               start_point_y4=points_y;
               start_point_x4=points_x;
           end
           failure_profile=[corrosion_depth_left(end:-1:1)',deepest_depth,corrosion_depth_right'];
       end
       
       as=repmat(failure_profile,2,1);
       [Pb_all(Monte_carlo_num)]=FasterRSTRENG(as,sigmay,AOD,pipethickness,resolution_length);
       
       
       corrosion_depth_left=[];
       corrosion_depth_right=[];
       left_point_x=[];
       left_point_y=[];
       right_point_x=[];
       right_point_y=[];
       
   end
     
     sorted_Pb_all=sort(Pb_all);
     Pb_psqr(1,1)=sorted_Pb_all(round(Monte_carlo_num*0.05));        
   else
Pb_psqr(1,1)=FasterRSTRENG(corrosion_profile,sigmay,AOD,pipethickness,resolution_length);
   end
