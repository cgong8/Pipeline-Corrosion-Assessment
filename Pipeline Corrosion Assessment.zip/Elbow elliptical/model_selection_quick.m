function [Pb]=model_selection_quick(corrosion_profile,SMYS,SMTS,AOD,pipethickness,resolution_length)
%load cluster1
% %     AOD=508;
% %     pipethickness=6.35;
% %     SMYS=359;
% %     SMTS=455;
    
    
    
 corrosion_profile1=corrosion_profile;

 %%data format to 2 mm X 2 mm    
%resolution_length=2;%%should not change
[Pb_CSA]=csa(corrosion_profile1,SMYS,SMTS,AOD,pipethickness,resolution_length);
[Pb_Procc]=Procc(corrosion_profile1,SMTS,AOD,pipethickness,resolution_length);
[Pb_B31G]=B31G_M(corrosion_profile1,SMYS,AOD,pipethickness,resolution_length);
[Pb_DNV]=DNV_model(corrosion_profile1,resolution_length,AOD,pipethickness,SMTS);
%[Pb_CPS]=CPS(corrosion_profile1,pipethickness,AOD,resolution_length,SMYS,SMTS);
%[Pb_PSQR]=Psqr(corrosion_profile1,SMYS,AOD,pipethickness,resolution_length,resolution_length);
[Pb_Rstreng]=Rstreng(corrosion_profile1,SMYS,AOD,pipethickness,resolution_length);

Pb=[Pb_Rstreng Pb_CSA Pb_B31G Pb_Procc Pb_DNV];