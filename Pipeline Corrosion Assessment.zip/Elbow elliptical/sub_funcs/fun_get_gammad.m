function gamma_d=fun_get_gammad(Std_d_t, safety_class)
switch safety_class
    case 'low'
        if Std_d_t<0.04
            gamma_d=1+4*Std_d_t;
        elseif Std_d_t>=0.04 && Std_d_t<0.08
            gamma_d=1+5.5*Std_d_t-37.5.*Std_d_t.^2;
        elseif Std_d_t>=0.08 && Std_d_t<=0.16
            gamma_d=1.2;
        else
            warning('***函数fun_get_gammad中Std_d_t超过了0.16!');
        end

    case 'normal'
        if Std_d_t<=0.16
            gamma_d=1+4.6*Std_d_t-13.9.*Std_d_t.^2;
        else
            warning('***函数fun_get_gammad中Std_d_t超过了0.16!');
        end

    case 'high'
        if Std_d_t<=0.16
            gamma_d=1+4.3*Std_d_t-4.1.*Std_d_t.^2;
        else
            warning('***函数fun_get_gammad中Std_d_t超过了0.16!');
        end
    otherwise
        warning('***函数fun_get_gammad未收到合法的Safety Class!');
end
gamma_d=round(gamma_d,3);
end