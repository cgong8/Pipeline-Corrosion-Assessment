function [result]=APDL_model_generation_rectangle(ansys_path,workname,start_cluster_ID,end_cluster_ID)

currentFolder = pwd;
T=readtable(workname);
C = table2cell(T);
C(cellfun(@(x) isempty(x), C)) = {NaN};
C(cellfun(@(x) ischar(x), C)) = {NaN};
T = cell2table(C, 'VariableNames', T.Properties.VariableNames);

cluster_ID_unique=unique(T{:,2});      % unique parent cluster ID
cluster_ID=T{:,2};                     % parent cluster ID
feature_ID=T{:,1};                     % child corrosion anomaly ID

if length(cluster_ID)~=length(feature_ID)
    disp ("Error! every child anomaly should belong to a cluster,simulation terminates")
    return
end

longitudinal_center=T{:,3};            % longitudinal coordinate of the corrosion anomaly
cir_center_all=T{:,4};                     % circumferential coordinate of the corrosion anomaly
D_all=T{:,5};
wall_thickness_all=T{:,6};
corrosion_type_all=T{:,7};
defect_depth_all=T{:,8};
defect_length_all=T{:,9};
defect_width_all=T{:,10};
E_value_all=T{:,11}; 
YS_all=T{:,12};                         % yield strength
UTS_all=T{:,13};                       % UTS
Axial_Force_Pre_all=T{:,14}*1000;
axial_force_all=T{:,15}*1000;
ELE_size=T{:,17};
Substep_number_all=T{:,18};



ans = dos('md burst_capacity_folder');       % generate the folder to save all the files



for iii=start_cluster_ID:end_cluster_ID
    % axial stress incompatible warning: a cluster must have the same axial stress
    
    cd (currentFolder);
    ID_no=cluster_ID_unique(iii);
    index_no=find(cluster_ID==ID_no);
    t=wall_thickness_all(index_no(1));
    D=D_all(index_no(1));
    out_D=D_all(index_no(1));
    E_value=E_value_all(index_no(1));
    corrosion_type=corrosion_type_all(index_no);
    Substep_Number=Substep_number_all(index_no(1));
    %%%Ĭ��Ϊ�ⸯʴ
    if isnan(corrosion_type)
        corrosion_type=1;
    end
    %%%%%%1��ʾ�ⸯʴ��0��ʾ�ڸ�ʴ
    if corrosion_type==1
        D=D-2*t;
    end
    
    %��ʴ��Ϣ
    defect_length=defect_length_all(index_no);                                           % for example, the 4rd column is the defect length (but convert it to the (mm)
    defect_width=defect_width_all(index_no);                                             % for example, the 5th column is the defect width (but convert it to the (mm)
    defect_depth=defect_depth_all(index_no)/100*t;                                       % for example, the 6th column is the defect depth in the unit of mm

    if length(unique(wall_thickness_all(index_no)))>1
        disp ("Error! wall thickness for a cluster shoould be consistent,simulation terminates")
       return
        
    end
    if length(unique(YS_all(index_no)))>1
        disp ("Error! Yield strength for a cluster shoould be consistent,simulation terminates")
        return
    end
    if length(unique(UTS_all(index_no)))>1
        disp ("Error! UTS for a cluster should be consistent,simulation terminates")
        return
    end
    
    
    element_size= D * pi / 16;                                 % I assume at least 16 elements should be created along the circumference
    translation_element_layer=min(3,max(round(element_size/54),1));        % the layer amount of transitional element should be between 1 and 3, that is the element size for defect free part is between 2 and 54
    
    if defect_depth~=0
        if isnan(ELE_size(index_no(1)))
            element_size=2;
        else
            element_size=ELE_size(index_no(1));
        end
    else
        %��ȱ�����
        translation_element_layer=0;
        element_size=pi*D/40;
    end
    
    element_size_x=element_size;
    element_size_y=element_size;

    % element size in the corrosion free area (mm)
    circumsurround=element_size_y*3^translation_element_layer;
    longsurround=element_size_x*3^translation_element_layer;
    
 %%%���õ���ģ��Ĭ��ֵ
    if isnan(E_value)
        E_value=200000;
    end
    %%%���û������Ӳ���
    if isnan(Substep_Number)
        Substep_Number=500;
    end
    %�ж��Ƿ���ѹ����Ӧ������
       %�ж��Ƿ���ѹ����Ӧ������
    if isnan(Axial_Force_Pre_all(index_no))
        Axial_Force_Pre=0;
    else
        Axial_Force_Pre=Axial_Force_Pre_all(index_no(1));
    end
    %�ж��Ƿ�����������
    if isnan(axial_force_all(index_no))
        axial_force=0;
    else
        axial_force=axial_force_all(index_no(1));
    end
    
    
    longitudinal_position = longitudinal_center(index_no,1)*1000; 
    circumferential_position_hh_mm=cir_center_all(index_no,1);
    circumferential_position=circumferential_position_hh_mm*2*pi*out_D;  % in the unit of (mm)
    
    
    
    defect_length=defect_length_all(index_no);                                           % for example, the 4rd column is the defect length (but convert it to the (mm)
    defect_width=defect_width_all(index_no);                                             % for example, the 5th column is the defect width (but convert it to the (mm)
    defect_depth=defect_depth_all(index_no)/100*t;                                       % for example, the 6th column is the defect depth in the unit of mm
  
    % here, determine the length/width of the corrosion cluster in the
    % FEA model
    %%%%ȫ����ʴ�ı߽�ߴ磬Ψһ
    long_start =  min(longitudinal_position   -  defect_length/2);
    long_end   =  max(longitudinal_position    +  defect_length/2);
    cir_start  =  min(circumferential_position -  defect_width/2);
    cir_end    =  max(circumferential_position +  defect_width/2);
    cir_move   =  (cir_start+cir_end)/2-pi*D/2;
    circumferential_position1=(max(circumferential_position)+min(circumferential_position))/2;
    
    
    %%%ÿ����ʴ�ĳ���
    cluster_length = long_end -  long_start ;
    cluster_width  = cir_end  -  cir_start  ;
    
    %%%%%ÿ����ʴ�ı߽�ߴ磬�������
    cluster_long_start =  longitudinal_position - defect_length/2;
    cluster_long_end   =  cluster_long_start + defect_length;
    cluster_cir_start  =  circumferential_position-cir_move-defect_width/2;
    cluster_cir_end    =  cluster_cir_start  +  defect_width;
    
    %%%%%
    long_start =  min(cluster_long_start);
    long_end   =  max(cluster_long_end);
    cir_start  =  min(cluster_cir_start);
    cir_end    =  max(cluster_cir_end);
    border_length=8;
    
    startlong_fine  = long_start -  border_length;
    endlong_fine    = long_end   +  border_length;
    startcircum_fine= cir_start  -  border_length;
    endcircum_fine  = cir_end    +  border_length;
    
 
    % compare the cluster width to prevent the corrosion area to be too wide
    corrosion_cluster_width_limit = D * pi * 2 / 3;
    if cluster_width >= corrosion_cluster_width_limit
        disp ("Corrosion feature is too wide, simulation teminates")
        continue;
    end
                                                              % Young's modulus: must be positive (MPa)
    YS_value=YS_all(index_no(1));                                         % Tield strength : must be positive (MPa)
    UTS_value=UTS_all(index_no(1));                                       % Ultimate tensile strength : must be positive (MPa)
    pressure_applied=4*UTS_value*t/D;                                     %%%Ԥ����ѹ
    strain_exponential=0.224*(UTS_value/YS_value-1)^0.604;                % Sigma= K *epsilon^n;
    true_ultimate=UTS_value*exp(strain_exponential);
    K=true_ultimate/(strain_exponential^strain_exponential);
    plastic_stress_ansys=linspace(YS_value,true_ultimate+100,20);
    plastic_strain_ansys=(plastic_stress_ansys/K).^(1/strain_exponential);
    plastic_strain_ansys(1)=YS_value/E_value;
    
    outputdata=cat(2,'tbpt,','defi');
    B = repmat(outputdata,[20,1]);
    for ii=1:20
        M{ii}=[B(ii,:),',',num2str(plastic_strain_ansys(ii)),',',num2str(plastic_stress_ansys(ii))];
    end
    

    % move the generated file to the newly created folder
    DST_PATH_t = './burst_capacity_folder/';
    copyfile('plane_remesh.txt',DST_PATH_t);
    copyfile('node_element_FEA_generation.txt',DST_PATH_t);
    copyfile('cluster_2.txt',DST_PATH_t);
    copyfile('post_process_strain_stress_plot.txt',DST_PATH_t);
    copyfile('corner_element.txt',DST_PATH_t);
    copyfile('corner_nodes.txt',DST_PATH_t);
    copyfile('Cluster_depth.txt',DST_PATH_t);
    cd (DST_PATH_t);
    
    
    % call ANSYS to generate the mesh on a plate
    fid = fopen('plane_remesh.txt');
    plane_mesh_data= textscan(fid,'%s','delimiter','\n');
    plane_mesh_data{1,1}(8)={['D=',num2str(D)]};
    plane_mesh_data{1,1}(9)={['startlong_fine=',num2str(startlong_fine)]};
    plane_mesh_data{1,1}(10)={['endlong_fine=',num2str(endlong_fine)]};
    plane_mesh_data{1,1}(11)={['startcircum_fine=',num2str(startcircum_fine)]};
    plane_mesh_data{1,1}(12)={['endcircum_fine=',num2str(endcircum_fine)]};
    plane_mesh_data{1,1}(13)={['circum_increment=',num2str(element_size)]};
    plane_mesh_data{1,1}(14)={['long_increment=',num2str(element_size)]};
    plane_mesh_data{1,1}(15)={['translation_element_layer=',num2str(translation_element_layer)]};
    fclose(fid);
    
    str = sprintf('plane_element%d.txt',iii);
    fid=fopen(str,'wt');
    [A,B]=size(plane_mesh_data{1,1});
    for j=1:A
        every_row=char(plane_mesh_data{1,1}(j));
        fprintf(fid,'%s\n',every_row);
    end
    
    every_row=[];
   fclose(fid);
    
    % call ANSYS to generate the model
    jobname=['model_generation_cluster',num2str(cluster_ID_unique(iii))];
    skriptFileName=['plane_element',num2str(iii),'.txt'];
    outputFilename=['cluster_output.txt'];
    sys_char=strcat('SET KMP_STACKSIZE=4096k &',32,ansys_path,32,...
        '-b -p ansys -i',32,skriptFileName,32,'-j',32,jobname,32,'-o',32,outputFilename),
    ans1=system(sys_char);
    
    str = sprintf('node_file.txt');
    Extra_node_information=importdata(str);
    cd(currentFolder);
    num_node_one_layer=length(Extra_node_information);
    outer_radius=D/2;
    
    x_coor_node=Extra_node_information(:,1);
    y_coor_node=Extra_node_information(:,2);
    z_coor_node=outer_radius*ones(num_node_one_layer,1);
    
    coor_num1=1:num_node_one_layer;
    node_coor_matrix_all=[coor_num1',x_coor_node,y_coor_node,z_coor_node];
    
    
    cd('./burst_capacity_folder/');
    str = sprintf('element_file.txt');
    element_information=importdata(str);
    element_number=length(element_information);
    cd(currentFolder);
        %�ҵ���ʴ���ĵ㣬ȷ���۽�λ��
        long_index1 = intersect(find(x_coor_node>=(endlong_fine+startlong_fine)/2-element_size),find(x_coor_node<=(endlong_fine+startlong_fine)/2+element_size));
        cir_index1  = intersect(find(y_coor_node>=(endcircum_fine+startcircum_fine)/2-element_size),find(y_coor_node<=(endcircum_fine+startcircum_fine)/2+element_size));
        node_selected_index_mid = intersect(long_index1,cir_index1);
        mid_index = node_selected_index_mid(1);
    
    %�и�ʴ��
    sum_element=0;
    for j=1:length(index_no)
        long_index = intersect(find(x_coor_node>cluster_long_start(j)),find(x_coor_node<cluster_long_end(j)));
        cir_index  = intersect(find(y_coor_node>cluster_cir_start(j)),find(y_coor_node<cluster_cir_end(j)));
        node_selected_index_inside = intersect(long_index,cir_index);
        Lia=ismember(element_information,node_selected_index_inside);
        element_inside=find(sum(Lia,2)==4);
        num_cluster_element=length(element_inside(:,1));
        Extra_element_first_4=repmat([1,1,1,j+1,0,0,0,0,4,0],num_cluster_element,1);
        element_information_inside_temp=[Extra_element_first_4,[sum_element+1:sum_element+num_cluster_element]',element_information(element_inside,:)];
        if j==1
            element_information_inside=element_information_inside_temp;
        else
            element_information_inside=[element_information_inside;element_information_inside_temp];
        end
        sum_element=sum_element+num_cluster_element;
    end
    %�޸�ʴ��
    for k=1:length(index_no)
        long_index_1 = intersect(find(x_coor_node>cluster_long_start(k)),find(x_coor_node<cluster_long_end(k)));
        cir_index_1  = intersect(find(y_coor_node>cluster_cir_start(k)),find(y_coor_node<cluster_cir_end(k)));
        node_selected_index_inside = intersect(long_index_1,cir_index_1);
        if k==1
            node_selected_index_inside_all=node_selected_index_inside;
        else
            node_selected_index_inside_all=union(node_selected_index_inside_all,node_selected_index_inside);
        end
    end
    Lia_1=ismember(element_information,node_selected_index_inside_all);
    element_outside=find(sum(Lia_1,2)~=4);
    num_nocluster_element=length(element_outside(:,1));
    Extra_element_first_10=repmat([1,1,1,1,0,0,0,0,4,0],num_nocluster_element,1);
    element_information_outside=[Extra_element_first_10,[sum_element+1:sum_element+num_nocluster_element]', element_information(element_outside,:)];
    
    
    % now, generate the transitional element
    total_node_matrix=node_coor_matrix_all;
    total_element_matrix=[element_information_inside;element_information_outside];
    
    %ת��ΪԲ������
    orientation_degree1=-pi/2;%�Ƚ���ʴ��������y�����Ϸ�
    
    total_node_matrix(:,2)=total_node_matrix(:,4).*cos(total_node_matrix(:,3)/D*2+orientation_degree1);
    total_node_matrix(:,3)=total_node_matrix(:,4).*sin(total_node_matrix(:,3)/D*2+orientation_degree1);
    total_node_matrix(:,4)=node_coor_matrix_all(:,2);
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Node information files
    
    cd('./burst_capacity_folder/');
    str = sprintf('node_element_information_cluster%d.txt',iii);
    fid=fopen(str,'wt');
    fprintf(fid,'/batch');
    fprintf(fid,'\n');
    fprintf(fid,'/wb,file,start');
    fprintf(fid,'\n');
    fprintf(fid,'/prep7');
    fprintf(fid,'\n');
    fprintf(fid,'SHPP,OFF,,NOWARN');
    fprintf(fid,'\n');
    fprintf(fid,'/nolist');
    fprintf(fid,'\n');
    fprintf(fid,'/com,*********** Nodes for the whole assembly ***********');
    fprintf(fid,'\n');
    fprintf(fid,'csys,0');
    fprintf(fid,'\n');
    fprintf(fid,'nblock,3');
    fprintf(fid,'\n');
    fprintf(fid,'(1i16,3e16.6e2)');
    fprintf(fid,'\n');
    fprintf(fid,'%16.0f%16E%16E%16E\n',total_node_matrix');
    fprintf(fid,'/wb,elem,start');
    fprintf(fid,'\n');
    fprintf(fid,'/com,*********** Elements for Body 1 "Solid" ***********');
    fprintf(fid,'\n');
    fprintf(fid,'et,1,181');
    fprintf(fid,'\n');
    fprintf(fid,'eblock,19,solid,,%s',num2str(element_number));
    fprintf(fid,'\n');
    fprintf(fid,'(19i16)');
    fprintf(fid,'\n');
    fprintf(fid,'%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f\n', total_element_matrix');
    fclose(fid);
    
    
    mid=total_node_matrix(mid_index,:);
    
    %%%%%%%%%��ʴ�����ļ�
    fid = fopen('Cluster_depth.txt');
    Cluster_data= textscan(fid,'%s','delimiter','\n');
    fclose(fid);
    if  corrosion_type==1
        for i=0:length(index_no)-1
            Cluster_data{1,1}(1+3*i)={['sectype,',num2str(i+2),',shell,,']};
            Cluster_data{1,1}(2+3*i)={['secdata,',num2str(t-defect_depth(i+1)),',1,0,5']};
            Cluster_data{1,1}(3+3*i)={['secoffset,bot']};
        end
        temp=3*length(index_no);
        Cluster_data{1,1}(1+temp)={['sectype,',num2str(1),',shell,,']};
        Cluster_data{1,1}(2+temp)={['secdata,',num2str(t),',1,0,5']};
        Cluster_data{1,1}(3+temp)={['secoffset,bot']};
    else
        for i=0:length(index_no)-1
            Cluster_data{1,1}(1+3*i)={['sectype,',num2str(i+2),',shell,,']};
            Cluster_data{1,1}(2+3*i)={['secdata,',num2str(defect_depth(i+1)),',1,0,5']};
            Cluster_data{1,1}(3+3*i)={['secoffset,top']};
        end
        temp=3*length(index_no);
        Cluster_data{1,1}(1+temp)={['sectype,',num2str(1),',shell,,']};
        Cluster_data{1,1}(2+temp)={['secdata,',num2str(t),',1,0,5']};
        Cluster_data{1,1}(3+temp)={['secoffset,top']};
    end
    
    if defect_depth==0
        for i=0:length(index_no)-1
            Cluster_data{1,1}(1+3*i)={['sectype,',num2str(i+2),',shell,,']};
            Cluster_data{1,1}(2+3*i)={['secdata,',num2str(t),',1,0,5']};
            Cluster_data{1,1}(3+3*i)={['secoffset,bot']};
        end
    end
    
    
    
    str = sprintf('Cluster_depth%d.txt',iii);
    fid=fopen(str,'wt');
    [A,B]=size(Cluster_data{1,1});
    for i=1:3+temp
        every_row=char(Cluster_data{1,1}(i));
        fprintf(fid,'%s\n',every_row);
    end
    every_row=[];
    fclose(fid);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % APDL model generation file
    fid = fopen('cluster_2.txt');
    APDL_data= textscan(fid,'%s','delimiter','\n');
    fclose(fid);

    
    APDL_data{1,1}(1)={['/input,node_element_information_cluster',num2str(iii),',txt']};
    APDL_data{1,1}(2)={['/input, Cluster_depth',num2str(iii),',txt']};
    APDL_data{1,1}(3)={['/eshape,1']};
    APDL_data{1,1}(4)={['eplot']};
    
    
    if isnumeric(Axial_Force_Pre) | ~isnan(Axial_Force_Pre)
        if Axial_Force_Pre~=0 & ~isnan(Axial_Force_Pre)
            APDL_data{1,1}(12)={['flag_force_pre=1']};
            APDL_data{1,1}(131)={['f,new_nodemax,fz,',num2str(Axial_Force_Pre)]};
        end
    end

    if isnumeric(axial_force) | ~isnan(axial_force)
        if axial_force~=0 & ~isnan(axial_force)
            APDL_data{1,1}(13)={['flag_force=1']};
             APDL_data{1,1}(141)={['f,new_nodemax,fz,',num2str(axial_force)]};
        end
    end
    
    for i=33:52
        APDL_data{1,1}(i)=cellstr(M{i-32});
    end
    
    APDL_data{1,1}(16)={['pipediameter=',num2str(D)]};
    APDL_data{1,1}(17)={['wallthickness=',num2str(t)]};
    APDL_data{1,1}(18)={['Youngs=',num2str(E_value)]};
    APDL_data{1,1}(19)={['startlong_fine=',num2str(startlong_fine)]};
    APDL_data{1,1}(20)={['endlong_fine=',num2str(endlong_fine)]};
    APDL_data{1,1}(69)={['/FOC,1,',num2str(mid(1,2)),',',num2str(mid(1,3)),',',num2str(mid(1,4))]};
    APDL_data{1,1}(77)={['/FOC,1,',num2str(mid(1,2)),',',num2str(mid(1,3)),',',num2str(mid(1,4))]};
    APDL_data{1,1}(78)={['/DIST,1,',num2str(cluster_length)]};
    APDL_data{1,1}(147)={['sf,all,pres,',num2str(pressure_applied)]};
    APDL_data{1,1}(151)={['nsubst,',num2str(Substep_Number)]};
    APDL_data{1,1}(171)={[' /input,post_process_clsuter',num2str(iii),',txt']};
    

    str = sprintf('APDL_file_cluster%d.txt',iii);
    fid=fopen(str,'wt');
    [A,B]=size(APDL_data{1,1});
    for i=1:A
        every_row=char(APDL_data{1,1}(i));
        fprintf(fid,'%s\n',every_row);
    end
    fclose(fid);
    every_row=[];
    clear total_node_information;
    clear element_information;
    clear circumferential_position_hh_mm;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % APDL post process file
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    str = sprintf('post_process_clsuter%d.txt',iii);
    fid=fopen(str,'wt');
    fprintf(fid,'*cfopen,stress_cluster%d,txt',iii);
    fprintf(fid,'\n');
    fprintf(fid,'*vwrite,nodemaxs(1,1),nodemaxs(1,2)');
    fprintf(fid,'\n');
    fprintf(fid,'(f20.5,f20.5)');
    fprintf(fid,'\n');
    fprintf(fid,'*cfclos');
    fclose(fid);
   
    
 
    
    cluster_number=iii;
    
    tic
    jobname=['pipe_burst_test_cluster_',num2str(cluster_ID_unique(cluster_number))];
    skriptFileName=['APDL_file_cluster',num2str(cluster_number),'.txt'];
    outputFilename=['cluster',num2str(cluster_ID_unique(cluster_number)),'_output.txt'];
    sys_char=strcat('SET KMP_STACKSIZE=4096k &',32,ansys_path,32,...
        '-b -p ansys -i',32,skriptFileName,32,...
        '-j',32,jobname,32,...
        '-o',32,outputFilename);
    ans1=system(sys_char);
    toc
    
    
    i = iii;
    ID_no=cluster_ID_unique(i);
    index_no=find(cluster_ID==ID_no);
    YS_value=YS_all(index_no(1));                                     % must be positive (MPa)
    UTS_value=UTS_all(index_no(1));                                    % must be positive (MPa)
    strain_exponential=0.224*(UTS_value/YS_value-1)^0.604;
    true_ultimate=UTS_value*exp(strain_exponential);
    internal_stress_curve=importdata(strcat(['stress_cluster',num2str(i),'.txt']));
    internal_pressure=internal_stress_curve(:,1)*pressure_applied;                                                  % pressure_applied;
    Mises_stress=internal_stress_curve(:,2);
    
    if isnumeric(axial_force) | ~isnan(axial_force)
        if axial_force~=0 & ~isnan(axial_force)
            Mises_stress=Mises_stress-1;
        end
    end
    
    true_UTS=true_ultimate;
    judge_vector=Mises_stress-true_UTS;
    new_vector=judge_vector(1:end-1).*(judge_vector(2:end));
    possible_points=min(find(new_vector<=0));
    if isempty(possible_points)
        burst_pressure{i,2}=NaN;
    else
        burst_pressure{i,2}=(true_UTS-Mises_stress(possible_points))*(internal_pressure(possible_points+1)-internal_pressure(possible_points))/(Mises_stress(possible_points+1)-Mises_stress(possible_points))+internal_pressure(possible_points);
    end
    burst_pressure{i,1}=i;
    
    % this is for the post process, to extract the stess/strain plot at the burst step
    
    ID_no=cluster_ID_unique(i);
    index_no=find(cluster_ID==ID_no);
    YS_value=YS_all(index_no(1));                                     % must be positive (MPa)
    UTS_value=UTS_all(index_no(1));                                    % must be positive (MPa)
    t=wall_thickness_all(index_no(1));
    D=D_all(index_no(1));
    D=D;
    
    if length(burst_pressure{i,2})>1
        continue;
    end
    time_step=burst_pressure{i,2}/pressure_applied;                              % time step
    
    
    internal_stress_curve=importdata(strcat(['stress_cluster',num2str(i),'.txt']));
    FEA_time_step=internal_stress_curve(:,1);
    sub_step_num = find(time_step-FEA_time_step<0,1)-1;                            % this is the sub step number during burst
    
    fid = fopen('post_process_strain_stress_plot.txt');
    post_process_strain_stress= textscan(fid,'%s','delimiter','\n');
    post_process_strain_stress{1,1}(1)={['RESUME,pipe_burst_test_cluster_',num2str(ID_no),',db,,0,0']};
    post_process_strain_stress{1,1}(11)={['SET,,,,,,,',num2str(sub_step_num)]};
    post_process_strain_stress{1,1}(17)={['SET,,,,,,,',num2str(sub_step_num)]};
    fclose(fid);
    
    
    str = sprintf('post_process_strain_stress_plot%d.txt',i);
    fid=fopen(str,'wt');
    [A,B]=size(post_process_strain_stress{1,1});
    for j=1:A
        every_row=char(post_process_strain_stress{1,1}(j));
        fprintf(fid,'%s\n',every_row);
    end
    every_row=[];
    fclose(fid);
    
    jobname=['pipe_burst_test_cluster_',num2str(ID_no)];
    skriptFileName=['post_process_strain_stress_plot',num2str(i),'.txt'];
    outputFilename=['plot',num2str(i),'_output.txt'];
    sys_char=strcat('SET KMP_STACKSIZE=4096k &',32,ansys_path,32,...
        '-b -p ansys -i',32,skriptFileName,32,...
        '-j',32,jobname,32,...
        '-o',32,outputFilename),
    ans1=system(sys_char);
    
    cd (currentFolder);
    work_folder='./burst_capacity_folder/';                  %ԭʼͼƬ·��
    savepath ='./Finite_element_picture/';                   %���洦�����ͼƬ·��
    file_list=dir(fullfile(work_folder,'*.jpg'));            %��ȡ����·��
    for i=1:length(file_list)
        im =imread([work_folder,file_list(i).name]);             %����·����ÿһ��ͼƬ
        imwrite(im,[savepath,file_list(i).name],'jpg');      %���µ�ͼƬд�뵽ָ���ļ���
    end
    
end



result=burst_pressure;
