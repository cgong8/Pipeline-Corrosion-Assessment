function [total_node_matrix,total_element_matrix]=edge_east(node_coor_matrix_inside,total_element_matrix,t,outside_node_x_east,total_node_matrix)
transition_node_edge=[1	0	0	1
    2	0	0	0
    3	0	0	0.499212598
    4	1	0	0
    5	1	0	1
    6	1	0	0.749606299
    7	1	0	0.499212598
    8	1	0	0.250393701
    9	0.56	0	0.722834646
    10	0.56	0	0.277165354
    11	0.51984252	0	0.499212598];
        element_connection_transition=[1	10	11	7	8	21	22	18	19
                                       2	11	9	6	7	22	20	17	18
                                       3	10	8	4	2	21	19	15	13
                                       4	11	10	2	3	22	21	13	14
                                       5	9	11	3	1	20	22	14	12
                                       6	6	9	1	5	17	20	12	16];    
       element_connection_transition1=  element_connection_transition;  
       node_coor_matrix_inside=round(node_coor_matrix_inside,1);
       x_coor_all_node_inside= node_coor_matrix_inside(:,2);
       y_coor_all_node_inside= node_coor_matrix_inside(:,3);
       z_coor_all_node_inside= node_coor_matrix_inside(:,4);
       start_x_loc=max(x_coor_all_node_inside);
       transition_element_length=abs(outside_node_x_east-start_x_loc);
       transition_element_depth=t;
       transition_node_edge(:,2)=start_x_loc+(1-transition_node_edge(:,2))*transition_element_length;
       transition_node_edge(:,4)=min(z_coor_all_node_inside)+transition_node_edge(:,4)*transition_element_depth; 
       y_coor_all_node_sorted=sort(unique(y_coor_all_node_inside(intersect(find(x_coor_all_node_inside>=(start_x_loc-0.1)),find(x_coor_all_node_inside<=(start_x_loc+0.1))))));
       for i=1:length(y_coor_all_node_sorted)-1
           transition_node_edge(:,3)=y_coor_all_node_sorted(i);
           node_num_now=max(total_node_matrix(:,1));
           element_num_now=length(total_element_matrix(:,1));
           transition_node_edge(:,1)=node_num_now+[1:11]';
           transition_node_edge1=transition_node_edge;
           transition_node_edge1(:,1)=transition_node_edge(:,1)+11;
           transition_node_edge1(:,3)=y_coor_all_node_sorted(i+1);
           element_connection_transition(:,1)=element_num_now+[1:6]';
           element_connection_transition(:,2:end)=element_connection_transition1(:,2:end)+node_num_now;
           total_node_matrix=[total_node_matrix;transition_node_edge;transition_node_edge1];
           total_element_matrix=[total_element_matrix;[repmat([1,1,1,1,0,0,0,0,8,0],6,1),element_connection_transition]]; 
       end     
end