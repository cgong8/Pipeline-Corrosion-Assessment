function step_size = stepgong(G,grad_G,u,d,indicator, denum,total,dist_para)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

il_max = 100;


c = ( norm(u) / norm(grad_G) ) * 2 + 10;

merit = 0.5 * (norm(u))^2 + c * abs(G);

trial_step_size = 1;

trial_u = u + trial_step_size * d;


%%[ trial_G, dummy ] = gfun(lsf,trial_x,'no ',probdata,gfundata,femodel,randomfield);
                    [ trial_G, dummy ] = gfun(trial_u, indicator, denum,total,dist_para);
%[ trial_G, trial_grad_g ] = gfun(lsf,trial_x,grad_flag,probdata,gfundata,femodel,randomfield);
%trial_grad_G = (trial_grad_g * J_x_u)';

merit_new = 0.5 * (norm(trial_u))^2 + c * abs(trial_G);

%merit_new = 0.5 * (norm(trial_u))^2 + (( norm(trial_u) / norm(trial_grad_G) ) * 2 + 10)* abs(trial_G);


i = 1;

while ( merit_new > merit ) & ( i < il_max + 1 )
   
   trial_step_size = trial_step_size * 0.5;
   
   trial_u = u + trial_step_size * d;



                    [ trial_G, dummy ] = gfun(trial_u, indicator, denum,total,dist_para);

	%[ trial_G, trial_grad_g ] = gfun(lsf,trial_x,grad_flag,probdata,gfundata,femodel,randomfield);
	%trial_grad_G = (trial_grad_g * J_x_u)';


	merit_new = 0.5 * (norm(trial_u))^2 + c * abs(trial_G);

	%merit_new = 0.5 * (norm(trial_u))^2 + (( norm(trial_u) / norm(trial_grad_G) ) * 2 + 10)* abs(trial_G);
   
   i = i + 1;
   
   if ( i == il_max ) & ( merit_new > merit )
      factor = 2^(il_max); 
      disp(['The step size has been reduced by a factor of 1/',num2str(factor),' before continuing.'])
   end
   
end

step_size = trial_step_size;
