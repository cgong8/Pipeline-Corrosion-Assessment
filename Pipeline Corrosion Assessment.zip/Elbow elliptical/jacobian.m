function [J_u_x] = jacobian(x,u,covariance,rv_para)

% Inverse normal transformation
% Generally follows the macro function developed by Low and Tang (2007): "Efficient Spreadsheet Algorithm for First-order Reliability Method" J. Eng. Mech. 133(12): 1378-1387
% dis_para(:,6) is a vector containing the following information:
% dis_para(:,1) = distribution type, dis_para(:,2) = para1, dis_para(:,3) = para2, dis_para(:,4) = empty, dis_para(:,5) = lower bound, dis_para(:,6) = upper bound
    % Distribution Type:
    % Deterministic = 0; Uniform = 1; Normal = 2; Lognormal = 3; Gamma = 4; Weibull = 5; Gumbel = 6; Beta = 7; Exponential = 8; Poisson = 9; Triangular = 10;
        % for Lognormal distribution, dist_para(:,5) = lower bound (shift)
        % for Beta distribution, dist_para(:,5)=lower bound, dist_para(:,6) = upper bound
        % for Exponential distribution, dist_para(:,5) = lower bound (shift)
        % for Triangular distribution, dist_para(:,5)=lower bound, dist_para(:,6) = upper bound
   
        dist_para = Cal_distpara(rv_para);
        
        J_z_x = zeros(length(u)); 
    n = length(u);
    for i = 1:n
        
    mean = rv_para(i,2);
    stdev = rv_para(i, 3)+rv_para(i, 4)*mean;
    LB = rv_para(i,5);
    UB = rv_para(i, 6);
        
        
        dist_type = dist_para(i,1);
        switch dist_type
        case 0
            J_z_x(i,i) =0;
        case 1
            ll = dist_para(i,2);
            ul = dist_para(i,3);
           J_z_x(i,i) =(1/(ul-ll)) /normpdf(u(i));
        case 2
           
            stdev = dist_para(i,3);
            J_z_x(i,i) =1/stdev;
        case 3
         xi = sqrt( log( 1 + (  stdev  /  mean  )^2 ) );
         J_z_x(i,i) = 1/( xi * x(i) );
         
        case 4
            k = dist_para(i,2);  % Gamma distribution parameter k, corresponding to parameter a in Matlab function Gamrnd(a,b)
            v = dist_para(i,3);                                       % Gamma distribution parameter v, corresponding to inverse of parameter b (1/b) in Matlab function Gamrnd(a,b)
            J_z_x(i,i)=gampdf(x(i),k, 1./v)/normpdf(u(i));
        case 5
            k = dist_para(i,2);                                                                        % Weibull distribution parameter, k, corresponding to parameter b in Matlab function Weibrnd(a,b)
            v = dist_para(i,3);                        % Weibull distribution parameter, v, parameter a in Matlab function Weibrnd(a,b) = (1/v)^k     
            J_z_x(i,i)= wblpdf(x(i),v,k)/normpdf(u(i));
        case 6
            alfa = dist_para(i,2);       % Gumbel distribution parameter, alfa
            v = dist_para(i,3);   % Gumbel distribution parameter, u
            J_z_x(i,i)=alfa*exp(-alfa*(x(i)-v)-exp(-alfa*(x(i)-v)))/normpdf(u(i));
        case 7
            r = dist_para(i,2);
            q = dist_para(i,3);
            LB = dist_para(i,5);
            UB=dist_para(i,6);
            x01(i)=(x(i)-LB)./(UB-LB);
            J_z_x(i,i) =betapdf(x01(i),q, r)./(UB-LB)./normpdf(u(i));
        case 8
            mean = dist_para(i,2);
            LB = dist_para(i,5);
            J_z_x(i,i) = exppdf(x(i), mean)./normpdf(u(i));
        case 9
            mean = dist_para(i,2);
            J_z_x(i,i) = poissinv(normcdf(x(i),0,1), mean)./normpdf(u(i));
        case 10
          J_z_x(i,i) = normpdf(u(i));
        end
    end
    
 
J_u_x = inv(covariance) * J_z_x;