 function [Burst_pressure]=FasterRSTRENG(Cluster5,sigmay,AOD,pipethickness,resolution_length)
    river_bottom=max(Cluster5);
    d_max=max(river_bottom);
    d_min=min(river_bottom);
    river_bottom_length=length(river_bottom); 
    unchecked_possible_k_list=1:river_bottom_length;
     p=1;
     current_min_RSF=1;
while ~isempty(unchecked_possible_k_list)
    if p==1
     k=unchecked_possible_k_list(floor((length(unchecked_possible_k_list))/2));
    else  
       k=next_k;      
    end
     p=p+1;
    if (resolution_length*k)^ 2 <= 50 *(AOD * pipethickness) 
    M =(1 + 0.6275 * (resolution_length*k) ^ 2 / (AOD * pipethickness) - 0.003375 *(resolution_length*k)^ 4 / (AOD * pipethickness) ^ 2) ^0.5;
    else
    M=3.3+0.032*(resolution_length*k)^2/(AOD*pipethickness);
    end
     A=[];
     for j=1:river_bottom_length-k+1
              sum_d1=0;

         for i=j:j+k-1
            sum_d1=sum_d1+river_bottom(i);   
         end
         A(j)=sum_d1;
     end
     sum_d=max(A);
     d_k_current=sum_d/k;
     current_RSF=(1-k*d_k_current*resolution_length/pipethickness/resolution_length/river_bottom_length)/(1-k*d_k_current*resolution_length/pipethickness/resolution_length/river_bottom_length/M); 
    left=unchecked_possible_k_list(1:find(unchecked_possible_k_list==k)-1);
    right=unchecked_possible_k_list(find(unchecked_possible_k_list==k)+1:max(size(unchecked_possible_k_list)));
    if ~isempty(left) || ~isempty(right)
     if  length(left)>length(right)
         next_k=left(floor((length(left)+1)/2));
     else
         next_k=right(floor((length(right)+1)/2));
     end
    end
      unchecked_possible_k_list(unchecked_possible_k_list==k)=[];
      
     if current_RSF<current_min_RSF
        current_min_RSF=current_RSF;
     end
     if ~isempty(unchecked_possible_k_list)
             k_remain=unchecked_possible_k_list; 
          for x=1:length(k_remain)
                if k_remain(x)<k
                    d_k_upper(x)=min(d_max,(k*d_k_current-d_min*(k-k_remain(x)))/k_remain(x));
                else
                    d_k_upper(x)=min(d_max,(k*d_k_current+d_max*(k_remain(x)-k))/k_remain(x));
                end
                   if (resolution_length*k_remain(x))^ 2 <= 50 *(AOD * pipethickness) 
                     M2=(1 + 0.6275 * (resolution_length*k_remain(x)) ^ 2 / (AOD * pipethickness) - 0.003375 *(resolution_length*k_remain(x))^ 4 / (AOD * pipethickness) ^ 2) ^0.5;
                   else
                     M2=3.3+0.032*(resolution_length*k_remain(x))^2/(AOD*pipethickness);
                   end
                current_RSFy(x)=(1-k_remain(x)*d_k_upper(x)/pipethickness/river_bottom_length)/(1-k_remain(x)*d_k_upper(x)/pipethickness/ river_bottom_length/M2);
               
                if current_RSFy(x)>=current_min_RSF
                    unchecked_possible_k_list(unchecked_possible_k_list==k_remain(x))=[];           
                end
          end
     end
  Pb(p-1)=2*pipethickness*(sigmay+68.95)/AOD*current_min_RSF;
end
  Burst_pressure=min(Pb);
end
