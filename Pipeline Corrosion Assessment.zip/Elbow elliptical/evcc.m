 function [ g] = evcc(x,det_para)

 global model_sel
 
 switch model_sel
          case 1
              %%%%%%%%CSA Model%%%%%%%
              M=Folias(x(6),x(7),x(3),x(2),det_para);%l,gl,D,t
              dav=(x(4)+x(5)*det_para)*x(10);wt=x(2);D=x(3);
              l=x(6)+det_para*x(7);
              if x(1)>241
              sigmau=0.9*x(11);
              else
              sigmau=1.15*x(1);    
              end 
              ra=2*(sigmau)*wt/D*(1-dav/wt)/(1-dav/wt/M); 
              g=x(8)*ra-x(9);%x(10)*ra-x(9);

           case 2
              %%%%%%%%B31G-M Model%%%%%%%
              M=Folias(x(6),x(7),x(3),x(2),det_para);%l,gl,D,t
              dmax=(x(4)+x(5)*det_para);wt=x(2);D=x(3);
              l=x(6)+det_para*x(7);sigmau=x(1);
           
              if dmax<=wt*0.8
              ra=2*(sigmau+68.95)*wt/D*(1-0.85*dmax/wt)/(1-0.85*dmax/M/wt);       
              else
              dmax1=wt*0.8;
              ra1=2*(sigmau+68.95)*wt/D*(1-0.85*dmax1/wt)/(1-0.85*dmax1/M/wt);
              ra=ra1*(1-(dmax/wt-0.8)/0.2);
              end  
              g=x(8)*ra-x(9);%x(10)*ra-x(9);

          case 3
              %%%%%%%%PCORRC Model%%%%%%%
              dmax=(x(4)+x(5)*det_para);wt=x(2);D=x(3);
              l=x(6)+det_para*x(7);sigmau=x(11);
           
              if l>2*D
                 l=2*D;
              end
              if dmax>wt*0.8
                 dmax=wt*0.8;
              end
                  
              ra=2*(sigmau)*wt/D*(1-dmax/wt*(1-exp(-0.157*l/(D*(1-dmax/wt)/2)^0.5)));       
            
              g=x(8)*ra-x(9);%x(10)*ra-x(9);

 end   

 
 
 
 
 
 
 % %  denum=1;
% % M=Folias(x(6+10*(denum-1)),x(7+10*(denum-1)),x(3+10*(denum-1)),x(2+10*(denum-1)),det_para);%l,gl,D,t
% %         
% %         dmax=(x(4+10*(denum-1))+x(5+10*(denum-1))*det_para)*x(10+10*(denum-1));wt=x(2+10*(denum-1));sigmau=x(1+10*(denum-1))*0.9;D=x(3+10*(denum-1));
% %         l=x(6+10*(denum-1))+det_para*x(7+10*(denum-1));
% %         
% %   
% % %            if dmax>0.8*wt %& dmax<wt
% % %                
% % %               
% % %                  co=(0.2*wt-(dmax-0.8*wt))/(0.2*wt);
% % %         
% % %                                  
% % %                  dmax=0.8*wt;
% % %                 rb=2*(sigmau+68.95)*wt/D*(1-0.85*dmax/wt)/(1-0.85*dmax/M/wt);
% % %                   ra=co*rb;         
% % %            elseif dmax<=0.8*wt
% %                  ra=2*(sigmau)*wt/D*(1-dmax/wt)/(1-dmax/M/wt);       
% %                
% %            %else 
% %             %    ra=0;
% % %            end
% %            
% %            g=x(8+10*(denum-1))*ra-x(9+10*(denum-1));
 