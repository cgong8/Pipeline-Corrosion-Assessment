function  [Burst_pressure]=Rstreng(Cluster5,sigmay,AOD,pipethickness,resolution_length)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% In the table of Tran_table:
% 1st column is the defect start, 2nd column is the orientation
% 3rd column is the defect length, 4th column is the defect width


    [M,N]=size(Cluster5);
    % Calculation of M2
    river_bottom=max(Cluster5);
    river_bottom_length=length(river_bottom);           % this is just the length of index, instead of the length of ...

    k=1;
for start_point=1:river_bottom_length-1                 % this is the position index 
    for  end_point=start_point+1: river_bottom_length   % this is the position index
        profile_selected=river_bottom(start_point:end_point);
        corroded_area=(sum(profile_selected)-(profile_selected(1)+profile_selected(end))/2)*resolution_length;
        profile_selected_length=resolution_length*(length(profile_selected)-1);
        %corroded_area=mean(profile_selected)*profile_selected_length;
        parameter1=profile_selected_length^2/(AOD*pipethickness);
        if parameter1<=50
            M2=sqrt(1+0.6275*parameter1-0.003375*parameter1^2);
        else
            M2=3.3+0.032*parameter1;
        end
        Pb(k)=2*pipethickness*(sigmay+68.95)/AOD*(1-corroded_area/(profile_selected_length*pipethickness))/(1-corroded_area/(profile_selected_length*pipethickness*M2));      
        k=k+1;
        clear profile_selected;
    end
end
  clear river_bottom;
  Burst_pressure=min(Pb);
end


    
    
    
