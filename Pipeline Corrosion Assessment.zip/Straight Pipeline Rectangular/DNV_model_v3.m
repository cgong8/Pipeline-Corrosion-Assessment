function p_corr_min=    DNV_model_v3(corrosion_profile, ...
    resolution_length, ...
    D, ...
    t, ...
    f_u)
if max(corrosion_profile) ~= 0

% 2023-1-30-根据公�?�师要求 去掉"安全系数，或者对均�?�增加了error"
% 2023_5_18_d_ei_te_meas_all中t 改成t_e_j
% d_ei_te_meas_all(k)=       d_ei_all(k)/t_e_j(j);

%% Appendix_Examples_trails
addpath('sub_funcs\')
small_subfuncs;
% safety_class=       'normal';
% measurement=        'UT';
if_plot_figure=     0; % 是否绘图
%%  A.3 Complex shaped defect
% Example 5


%% 随机生成Profile of corrosion depth
data_profile=   max(corrosion_profile);
x=              (0:length(data_profile)-1).*resolution_length;%data_profile(:,1);
d_all=          data_profile;%data_profile(:,2);
l_max=          max(x);
d_max=          max(d_all);

% As a single defect
% 2023-1-30-
Std_d_t=        0;%fun_StD_d_t(measurement, 0.1, 0.9,t);
gamma_d=        1;%fun_get_gammad(Std_d_t, safety_class);
e_d=            0;%fun_get_ed(Std_d_t);
gamma_m=        1;%fun_get_gammam(measurement, safety_class);
Q_total=        fun_Q(l_max,D,t);
d_t_meas=       d_max/t;
d_t_star=       d_t_meas+e_d.*Std_d_t;
p_corr_max=     fun_p(gamma_m,t,f_u,D,gamma_d,d_t_star,Q_total);
% As a single defect with average depth
A=              trapz(x,d_all);
d_ave=          A./l_max;
d_t_meas_ave=   d_ave/t;
d_t_star_ave=   d_t_meas_ave+e_d.*Std_d_t;
p_corr_ave=     fun_p(gamma_m,t,f_u,D,gamma_d,d_t_star_ave,Q_total);

%%
% Progressive Depth Analysis
% 将最大缺陷深度划分为增量，并对所有深度增量（dj）进行以下计算（见图6-1）�??
% 剖面的每个分区将剖面分成理想化的 "补丁 "部分�?
% 比深度分区浅（即 "补丁 "的最大深度为dj�?
% 以及比分区深�? "凹坑"（见�?6-2）�??
% 建议增量的数量在10�?50之间�?
% 剖面被切�?50级，并对每个增量的允许腐�?管道压力进行估算�?
% 图A-2显示了允许的腐蚀管道压力估计值随深度的变化�??
% �?小的允许腐蚀管道压力估计值为9.19N/mm2�?91.9bar）�??
% 断面深度�?1.06毫米，相当于补丁和坑的自然分界线，这在图A-1中可以看到�??
% 在这个深度，相对明显的剖面变化的影响�?
% 在估计的允许腐蚀管道压力曲线上产生了急剧的变化，如图A-2�?示�??
num_levels=         30;
d_inv=              d_max./num_levels;
d_j_all=            (1:num_levels)*d_inv;
p_corr_j=           nan(num_levels,1);
p_patch_j=          nan(num_levels,1);
p_cap_patch_j=      nan(num_levels,1);
t_e_j=              nan(num_levels,1);
p_i_min_j=          nan(num_levels,1);
p_nm_min_j=         nan(num_levels,1);

for j=1:num_levels
    % if j==32
    %     disp('!');
    % end
    %%
    % j=1;
    d_j=        d_j_all(j);
    % 假设
    % sign_pit([6 7])=0
    % 捕捉pit location
    sign_pit=                       (d_all>=d_j);
    sign_pit_diff=                  diff(sign_pit);
    pit_l_no=                       find(sign_pit_diff==1)+1;
    pit_r_no=                       find(sign_pit_diff==-1);
    %%
    % figure
    % plot(d_all)
    % hold on
    % plot([0 length(x)],[d_j d_j])
    %%
    if length(unique(sign_pit_diff))==1
        N_pits=         1;
        pit_l_no=       1;
        pit_r_no=       length(x);
    else
        if sign_pit(1)==1 %% pit_l_no(1)~=1
            pit_l_no=   [1 pit_l_no];
        end
        if sign_pit(end)==1 %% pit_r_no(end)~=length(x)
            pit_r_no=   [pit_r_no length(x)];
        end
        %     if length(pit_r_no)<            length(pit_l_no)
        %         % 有进无出
        %         pit_r_no(end+1)=            length(x);%(end);
        %     end
        N_pits=                         length(pit_l_no);
    end

    % patch
    d_patch_all=                    d_all;
    d_patch_all(d_patch_all>=d_j)=   d_j;
    % 尝试夸张面积 不行。�??
    %     d_patch_all=                    ones(size(d_all)).*d_j;

    A_patch=                        trapz(x,    d_patch_all);
    d_patch=                        A_patch/l_max;
    d_patch_t_meas=                 d_patch/t;
    d_patch_t_star=                 d_patch_t_meas+e_d*Std_d_t;
    % Q_total=                      fun_Q(l_max,D,t);
    p_patch_j(j)=                   fun_p(gamma_m,t,f_u,D, ...
        gamma_d,d_patch_t_star,Q_total);
    % 2023-1-30-
    %     p_cap_patch_j(j)=               fun_p(1.09,t,f_u,D, ...
    %         gamma_d,d_patch_t_meas,Q_total);
    p_cap_patch_j(j)=               fun_p(1.0,t,f_u,D, ...
        gamma_d,d_patch_t_meas,Q_total);

    % pits
    % 对于每一个理想化�? "�?"，如�?6-2�?示，计算当前深度区间的名义厚度圆柱体的面积损失，
    % 并估计每�?个理想化 "�? "的平均深度�??

    d_pits_all=                     d_all;
    d_pits_all(d_pits_all<=d_j)=     0;

    % 尝试夸张面积 不行。�??
    %     d_pits_all(d_pits_all>=d_j)=     d_max;
    % 2023-1-30- 1.09-->1.0
    t_e_j(j)=                       p_cap_patch_j(j).*D./(2*1.0*f_u+p_cap_patch_j(j));
    %     t_e_j(j)=                       p_cap_patch_j(j).*D./(2*1.09*f_u+p_cap_patch_j(j));

    if N_pits>0 % 首先 你得有pits
        l_i_all=                        zeros(N_pits,1);
        A_pits_all=                     zeros(N_pits,1);
        d_i_all=                        zeros(N_pits,1);
        d_ei_all=                       zeros(N_pits,1);
        Q_i_all=                        zeros(N_pits,1);
        d_ei_te_meas_all=               zeros(N_pits,1);
        d_ei_te_star_all=               zeros(N_pits,1);
        p_i_all=                        zeros(N_pits,1);
        % 如果有多个pits
        if N_pits>1
            s_i_all=                    zeros(N_pits-1,1);
        end
        for k=1:N_pits
            if k<N_pits
                s_i_all(k)=             x(pit_l_no(k+1))-x(pit_r_no(k));
            end
            if pit_r_no(k)~= pit_l_no(k)
                l_i_all(k)=                 x(pit_r_no(k)) -x(pit_l_no(k));
                A_pits_all(k)=              trapz(x(pit_l_no(k):pit_r_no(k)),    ...
                    d_pits_all(pit_l_no(k):pit_r_no(k)));
            else
                temp_x=diff(x);
                temp_x=temp_x(1);
                l_i_all(k)=  temp_x;
                A_pits_all(k)= l_i_all(k)*d_pits_all(pit_l_no(k));
            end

            d_i_all(k)=                 A_pits_all(k)./l_i_all(k);
            d_ei_all(k)=                d_i_all(k)-(t-t_e_j(j));

            Q_i_all(k)=                 fun_Q(l_i_all(k),D,t_e_j(j));
            %这一步骤可能有问�? 2023-1-9 感觉没啥影响 把te换成t
            % 2023_5_18 改回�? t_e_j(j)
            d_ei_te_meas_all(k)=        d_ei_all(k)/t_e_j(j); %d_ei_all(k)/t_e;
            d_ei_te_star_all(k)=        d_ei_te_meas_all(k)+e_d*Std_d_t;

            p_i_all(k)=                 fun_p(gamma_m,t_e_j(j),f_u,D, ...
                gamma_d,                d_ei_te_star_all(k),Q_i_all(k));
        end
        %     if N_pits>0
        p_i_min_j(j) =       min(p_i_all);
    else
        p_i_min_j(j) =   NaN;
    end
    % pits cobination
    if N_pits>1
     %   disp(['�?' num2str(N_pits) '个pits �?要�?�虑组合效应.....'])
        l_nm=[];
        d_enm_all=[];
        Q_nm_all=[];
        d_enm_te_meas_all=[];
        d_enm_te_star_all=[];
        p_nm_all=[];
        len_l_nm=1;
        for n=1:N_pits-1
            for m=n+1:N_pits
                l_nm(len_l_nm)=         l_i_all(m)+sum(l_i_all(n:m-1)+s_i_all(n:m-1));
                d_enm_all(len_l_nm)=    sum(d_ei_all(n:m).*l_i_all(n:m))./l_nm(len_l_nm);

                % Std_d_t=        fun_StD_d_t(measurement, 0.1, 0.9,t)
                % 2023-1-30-
                %                 Std_denm_t=     sum(l_i_all(n:m).*Std_d_t)./l_nm(len_l_nm);
                %                 gamma_d_enm=    fun_get_gammad(Std_denm_t, safety_class);
                %                 Std_denm_t=0;
                gamma_d_enm=        1.0;
                %                 e_d_enm=        fun_get_ed(Std_denm_t);

                Q_nm_all(len_l_nm)=           fun_Q(l_nm(len_l_nm),D,t_e_j(j));

                %这一步骤可能有问�? 2023-1-9 感觉没啥影响
                % d_enm_te_meas_all(len_l_nm)=        d_enm_all(len_l_nm)/t;
                % 2023_5_18_d_ei_te_meas_all中t 改成t_e_j
                d_enm_te_meas_all(len_l_nm)=       d_enm_all(len_l_nm)/t_e_j(j); 
                d_enm_te_star_all(len_l_nm)=       d_enm_te_meas_all(len_l_nm)+e_d*Std_d_t;

                p_nm_all(len_l_nm)=                fun_p(gamma_m,t_e_j(j),f_u,D, ...
                    gamma_d_enm,d_enm_te_star_all(len_l_nm),Q_nm_all(len_l_nm));
                len_l_nm=len_l_nm+1;
            end
            
        end
        p_nm_min_j(j)=min(p_nm_all);
        if p_nm_min_j(j)==0
            disp('!')
        end
        [p_corr_max p_corr_ave p_patch_j(j) p_i_min_j(j) p_nm_min_j(j)];
        p_corr_j(j)= min([ p_i_min_j(j) p_nm_min_j(j)]);

    else
      %  disp(['就一个pit不用考虑 组合效应啦�?��?��??'])
        [p_corr_max p_corr_ave p_patch_j(j) p_i_min_j(j)];
        p_corr_j(j)= min([   p_i_min_j(j)]);
    end
end
% �?13步是根据补丁和坑的最小估计�?�来估计当前水平台阶深度的允许腐�?管道压力�?
% 在这种情况下，最小的允许腐蚀管道压力是来自pits�?
if if_plot_figure
    figure
    subplot(2,1,1)
    plot(x,-d_all,'k')
    xlabel({'Length (mm)','(a)'})
    ylabel('Corrosion depth (mm)')
    ylim([-10 0])

    subplot(2,1,2)
    plot(d_j_all,p_corr_j,'k')
    hold on
    plot(d_j_all,p_patch_j,'b')
    plot(d_j_all,p_i_min_j,'r--')
    plot(d_j_all,p_nm_min_j,'g:')
    plot(d_j_all(p_corr_j==min(p_corr_j)),min(p_corr_j),'pentagram','Color','k');

    xlabel({'Depth increment (mm)','(b)'})
    ylabel('Predicted Allowable Corroded Pressure (MPa)')
    %     ylim([fix(min(p_corr_j)) ceil(max(p_patch_j))])
    legend('Allowable corroded pipe pressure', ...
        'Patch allowable corroded pipe pressure', ...
        'Single pits allowable corroded pipe pressure', ...
        'Combined pits allowable corroded pipe pressure',...
        'Minimum allowable corroded pipe pressure')
end
p_corr_min=min(p_corr_j);
else
p_corr_min=0;
end