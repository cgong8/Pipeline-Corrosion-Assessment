function [result] = zhi2wan(in_def)
in_def(4:end,2)=in_def(4:end,2)/180*pi*in_def(1,4)/2;%环向坐标
defect_length_degree=in_def(1,6)*2*2*pi;
in_def(3,3:end)=in_def(3,3:end)/180*pi*(in_def(1,8)-in_def(1,4)/2*sin(defect_length_degree));%轴向坐标
result=in_def;
end
