clear
clc
n=1
%function [Pb,Pl]=group(n)
%n=5
%clear
%clc
%n=0
%clear
%clc
ac=1;
%n=0
numcorrelation=1; %number of correlated defects
T_max=1;       % total year 
initialcre=0;  %initla plus 1

global df;
global gcor;
global denum;
global indicator;
global numsimulation;
global gcor1 model_sel;
numsimulation=1e5;
gcor=0;
df=0.8;
gcor1=0;

model_sel=1;
              for i=1:numcorrelation
              [xin((1+11*(i-1)):(11+11*(i-1)),1:6)]=tiquxin(i+n,ac);
             end


   tStart = tic;   
for i=1:numcorrelation

denum=i;        % No. of defect

     for   indicator=1:2
   
     [t,alfa,beta,x]=diaoqu(xin,T_max,numcorrelation) ;

     if indicator==1
    c1{denum}=alfa;
      bet1(denum,:)=beta;
      elseif indicator==2
      c2{denum}=alfa;
      bet2(denum,:)=beta; 
      end    
     end 
end
      toc(tStart)     
      cccb=c1;ccel=c2;betaab=bet1;betaal=bet2;
  %[Pb1]=diaoqutestb(T_max,cccb, ccel,betaab,betaal);    
%  [Pb1]=diaoqutestbb(T_max,cccb, ccel,betaab,betaal);    

%plot(1:21,Pb1,'b')
%%figure
[anburst,anleak,cburst,cleak]=diaoqusim3(xin,initialcre,T_max,numcorrelation,numsimulation);
%Pb=anburst';Pl=anleak';
% %   
% %   cRE=[bet1;bet2];
% %   c_dir=[cccb ccel];


% % for i=1:21
% %    
% %    beta1= bet1(1,1:i);
% %    cor1 = cccb{1}(:,1:i);
% % 
% %    beta2= bet2(1,1:i);
% %    cor2 = ccel{1}(:,1:i);
% % 
% %      if numcorrelation>=2
% %        for j=2:numcorrelation
% %        beta1 = [beta1 bet1(j,1:i)];
% %        cor1 = [cor1 cccb{j}(:,1:i)];
% %        beta2 = [beta2 bet2(j,1:i)];
% %        cor2 = [cor2 ccel{j}(:,1:i)];
% %        end
% %      end
% %     
% % [ps(i)]=multi_normal_integral([beta1 beta2],[cor1 cor2]'*[cor1 cor2]);
% % 
% % beta1=[];cor1=[];
% % beta2=[];cor2=[];
% % end
% % 
% % for i=1:20
% %    
% %    beta1= bet1(1,2:i+1);
% %    cor1 = cccb{1}(:,2:i+1);
% % 
% %    beta2= bet2(1,1:i);
% %    cor2 = ccel{1}(:,1:i);
% % 
% %      if numcorrelation>=2
% %        for j=2:numcorrelation
% %        beta1 = [beta1 bet1(j,2:i+1)];
% %        cor1 = [cor1 cccb{j}(:,2:i+1)];
% %        beta2 = [beta2 bet2(j,1:i)];
% %        cor2 = [cor2 ccel{j}(:,1:i)];
% %        end
% %      end
% %     
% % [ps_B(i)]=multi_normal_integral([beta1 beta2],[cor1 cor2]'*[cor1 cor2]);
% % 
% % beta1=[];cor1=[];
% % beta2=[];cor2=[];
% % end
[P0]=combineburstc(T_max,[cccb ccel],[bet1;bet2],numcorrelation*2);

  cRE_leak=[bet1(:,1:T_max);bet2(:,2:T_max+1)];
  cRE_burst=[bet1(:,2:T_max+1);bet2(:,1:T_max)];
  
  for i=1:numcorrelation
      ccb0{i}(:,1:T_max) = cccb{i}(:,2:T_max+1);
      ccel0{i}(:,1:T_max) = ccel{i}(:,1:T_max);
      
      ccb1{i}(:,1:T_max) = cccb{i}(:,1:T_max);
      ccel1{i}(:,1:T_max) = ccel{i}(:,2:T_max+1);
  end       
        

  [P0_b]=combineburstc(T_max,cccb,bet1,numcorrelation);
  [P0_l]=combineburstc(T_max,ccel,bet2,numcorrelation);

  
  [Pb_Delt_leak]=combineburstc(T_max-1,[ccb1 ccel1],cRE_leak,numcorrelation*2);
  [Pb_Delt_burst]=combineburstc(T_max-1,[ccb0 ccel0],cRE_burst,numcorrelation*2);
    
  Pb_inc=abs(Pb_Delt_burst-P0(1:T_max));
  Pl_inc=abs(Pb_Delt_leak-P0(1:T_max));
  
  Pb_inc_new=Pb_inc;
  
  for i=1:length(Pb_inc)-1
  gra_b(i)=Pb_inc(i+1)-Pb_inc(i);
  gra_l(i)=Pl_inc(i+1)-Pl_inc(i);
  end
  
  t_in=zeros(1,length(Pb_inc)-2);
  for i=1:length(Pb_inc)-3
      if i>1
        if gra_b(i)*gra_b(i+1)<0 && gra_b(i+2)>0
    %    print("1")
        Pb_inc(i+1)=Pb_inc(i+2)*0.5+Pb_inc(i)*0.5;
        Pl_inc(i+1)=Pl_inc(i+2)*0.5+Pl_inc(i)*0.5;
        
        end 
      end 
      if i>1
         if gra_b(i-1)<0 && gra_b(i)*gra_b(i+1)<0 
          Pb_inc(i+2)=Pb_inc(i+3)*0.5+Pb_inc(i+1)*0.5;
          Pl_inc(i+2)=Pl_inc(i+3)*0.5+Pl_inc(i+1)*0.5;
         end 
      end 
  end
    
 % [P1b0,P1l0]=TEST(c1,c2,bet1,bet2,numcorrelation,T_max);

  for t=1:T_max+1
    if t==1
    Pb_I(t)=P0_b(1);
    Pl_I(t)=P0_l(1);
    else
    Pb_I(t)= P0_b(1)+sum(Pb_inc(1:t-1));   
    Pl_I(t)= P0_l(1)+sum(Pl_inc(1:t-1));
   % Pb_C(t)= P0_b(1)+sum(P1b0(1:t-1));   
   % Pl_C(t)= P0_l(1)+sum(P1l0(1:t-1));
    end
  end

aaaBurst = [Pb_I' cburst' anburst'];
aaaLeak = [Pl_I' cleak' anleak'];


% figure 
% plot(1:T_max+1,aaaBurst)
% figure
% plot(1:T_max+1,aaaLeak)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%[Pb1]=diaoqutestb1(T_max,cccb, ccel,betaab,betaal);    
 %[Pl1]=diaoqutestb1(T_max,ccel, cccb,betaal,betaab);      
% for t=1:T_max+1
%     if t==1
%     an(t)=1-normcdf(bet1(1));
%     la(t)=1-normcdf(bet2(1));
%     else
%     an(t)=1-normcdf(bet1(1))+sum(Pb1(1:t-1));
%     la(t)=1-normcdf(bet2(1))+sum(Pl1(1:t-1));
%     end
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% % hold on
% % plot(1:20,Pb_inc,'r')
%hold on
%plot(1:20,anburst)
%f=fit([1:20]',[Pb_inc]','poly9');
%plot(f,[1:20]',[Pb_inc]')
% % 
% %  plot(1:T_max+1,(Pb))
% %  hold on
% %  plot(1:T_max+1,(anburst))
% %  
% %  figure
% %   plot(1:T_max+1,log(Pl))
% %  hold on
% %  plot(1:T_max+1,log(anleak))

      
%[Fb]=1-normcdf(bet1)';%combineburstc(0,c1,bet1,numcorrelation);
%[Fl]=1-normcdf(bet2)';%combineburstc(0,c2,bet2,numcorrelation);


%plot(1:31,log(Pb))
%hold on
%plot(1:31,log(Fb),'b')
%hold on
%plot(1:31,log(anburst),'r')


%createfigure1(1:T_max+1,[Pb' anburst' Fb])
%createfigure1(1:T_max+1,[Pl' anleak' Fl])




