function [P]=multi_normal_integral(Index,R)
%P is the series failure probability 
%Index is the n-by-1 reliability index vector 
%R is n-by-n correlation matrix
%P is the computed as described in [1]

%References:
%  [1] Gong, C., & Zhou, W. (2017). Improvement of equivalent component approach for reliability analyses of series systems. Structural Safety, 68, 65-72.
%  If you encounter any problems, you are encouraged to contact Changqing Gong at chg218@lehigh.edu.


ReIn=find(Index>8);
if length(ReIn)==length(Index)
   error(['All reliability index is larger than 8.'...
   ' Failure probability is too small'])
end
Index(ReIn)=[];
R(ReIn,:)=[];
R(:,ReIn)=[];
n=length(Index);
try 
  covariance = chol(R)';  
catch 
  
    R=nearestSPD(R);
  covariance = chol(R)';
  warning('Select the nearest PSD')

end
ccc=inv((covariance));
I=ones(1,1);iz=zeros(n,1);
for i=1:n
  iz=zeros(n,1);
  s=R(i,i);
  ga(i)=-2*Index(i)/sqrt(I'*s*I);
  c(i)=Index(i)*sqrt(I'*s*I);
  iz(i,1)=I;
  Y(:,i)=-ga(i)/2*R*iz;
  alfa(:,i)=ccc*Y(:,i)/Index(i);
end  
  rr=alfa'*alfa;
for i=1:n-1
  rr=rr-diag(diag(rr))-8*eye(length(rr(:,1)));
  [M,I]=max(rr);
  [I_row, I_col] = ind2sub(size(rr),I(1));
  cc=(alfa(:,I_row))'*(alfa(:,I_col));
  dr1=alfa(:,I_row);dr2=alfa(:,I_col);
  rr(I_row,:)=[];rr(:,I_row)=[];
  rr(I_col,:)=[];rr(:,I_col)=[];
  alfa(:,I_row)=[]; alfa(:,I_col)=[];
  ubeta=Index(I_row);beta=Index(I_col);
  Index(I_row)=[];Index(I_col)=[];
  rcc(i)=cc;
if cc<=0.99
  ps=1-mvncdf([ubeta;beta],[0;0],[1 cc;cc 1]);
  rs=-norminv(ps);
  rss(i)=rs;
  ualfa=-(-exp((rs^2-ubeta^2)*0.5)*normcdf(...
  (beta-cc*ubeta)/sqrt(1-cc^2))*dr1-exp((rs^2.-beta^2)...
  *0.5)*normcdf((ubeta-cc*beta)/sqrt(1-cc^2))*dr2);
  ualfa(:,1)=ualfa(:,1)/norm(ualfa(:,1));
else 
  [Mm,Im]=min([ubeta;beta]);
  ps=1-normcdf(Mm);  
  rs=Mm;
  rss(i)=rs;
  ualfase=[dr1 dr2];
  ualfa(:,1)=ualfase(:,Im);
end
  alfa(:,n-i)=ualfa(:,1);
  addr=ualfa(:,1)'*alfa(:,1:end);
  readdr{i}=addr;
  rr(n-i,1:n-i)=addr;rr(1:n-i,n-i)=addr';
  Index(n-i)=rs;
end
  P=ps;

