clear all
clc;

delete('1.png');
delete('data.mat');
ansys_path = '"C:\Program Files\ANSYS Inc\v192\ansys\bin\winx64\ANSYS192.exe"'; 
% ansys_path = '"E:\ansys\ANSYS Inc\v192\ANSYS\bin\winx64\ANSYS192.exe"';  
in_def=xlsread ('Elbow_natural_corrosion.xlsx');
%%%%��ʴ�ܵ���Ϣ��ȡ
Cluster_num=i;
GWID=in_def(1,1);
Threshold=in_def(1,2);
corrosion_type=in_def(1,3);
D=in_def(1,4);
t=in_def(1,5);
Clock_Position=in_def(1,6);
staraight_length=in_def(1,7);
bend_r=in_def(1,8);
bend_angel=in_def(1,9);
bend_location_angel=in_def(1,10);
Elastic_Modulus_MPa=in_def(1,11);
SMYS_MPa=in_def(1,12);
SMTS_MPa=in_def(1,13);
Axial_Force_Pre=in_def(1,14);
Axial_Force=in_def(1,15);
MOP_MPa=in_def(1,16);

Interaction_Rule=in_def(1,17);
Element_size=in_def(1,18);
Substep_number=in_def(1,19);

AOD=D;
rule_int=Interaction_Rule;  %select 1:1:4
pipethickness=t; 
SMYS=SMYS_MPa;
SMTS=SMTS_MPa;
% MOP=MOP_MPa;

%���
defectmtrixl=in_def(4:end,3:end);
defectmtrix=abs(defectmtrixl);

  
if isnan(Element_size)
    Element_size=2;
end
reso_x=Element_size;%%set up �������޸�
resolution_length=reso_x;

%%%%�Ƕȱ䳤��
[result]=zhi2wan(in_def);
in_def=result;
%%%%%%%
element_size_x=in_def(3,4)-in_def(3,3);
element_size_y=in_def(6,2)-in_def(5,2);%input resolution
defectmtrix(find(defectmtrix<=in_def(1,2)))=0;

x_coor_Cluster=0:element_size_x:element_size_x*(length(defectmtrix(1,:))-1);
y_coor_Cluster=0:element_size_y:element_size_y*(length(defectmtrix(:,1))-1);
[X_coor_Cluster,Y_coor_Cluster]=meshgrid(x_coor_Cluster,y_coor_Cluster);
x_coor_Cluster_new=0:reso_x:element_size_x*(length(defectmtrix(1,:))-1);
y_coor_Cluster_new=0:Element_size:element_size_y*(length(defectmtrix(:,1))-1);
[X_coor_Cluster_new,Y_coor_Cluster_new]=meshgrid(x_coor_Cluster_new,y_coor_Cluster_new);
vq = griddata(X_coor_Cluster,Y_coor_Cluster,defectmtrix,X_coor_Cluster_new,Y_coor_Cluster_new,'nearest');

depth_correction_matrix=vq;
%
connect_component=bwlabel(depth_correction_matrix);
defect_amount=max(max(connect_component));

%Here,I want to generate a new matrix,the row is the defect number (from 1 to defect amount)
%the 4 columns are the_coordiates of four borders

border_matrix=zeros(defect_amount,4);

if rule_int==1  %CSA
k_y=ceil(6*pipethickness/2/Element_size/1);
k_x=ceil(6*pipethickness/2/reso_x/1);
elseif rule_int==2 %B31G
k_y=ceil(3*pipethickness/2/Element_size/1);
k_x=ceil(3*pipethickness/2/reso_x/1);   
elseif rule_int==3 %B31.4
k_y=ceil(3*pipethickness/2/Element_size/1);
k_x=ceil(25.4/2/reso_x/1);
elseif rule_int==4 %%%DNV
k_y=ceil(3.14*(AOD*pipethickness)^0.5/2/Element_size/1);
k_x=ceil(2*(AOD*pipethickness)^0.5/2/reso_x/1);    
else
k_y=ceil(6*pipethickness*100/2/Element_size/1);
k_x=ceil(6*pipethickness*100/2/reso_x/1);    
end 

depth_mask=zeros(size(depth_correction_matrix));

% expand the corrosion anomalies for interaction rule
for i=1:defect_amount
    [row_index,column_index]=find(connect_component==i);
    border_matrix(i,1)=max(min(row_index)-k_y,1);
    border_matrix(i,2)=min(max(row_index)+k_y,length(depth_correction_matrix(:,1)));
    border_matrix(i,3)=max(min(column_index)-k_x,1);
    border_matrix(i,4)=min(max(column_index)+k_x,length(depth_correction_matrix(1,:)));
    depth_mask(border_matrix(i,1):border_matrix(i,2),border_matrix(i,3):border_matrix(i,4))=1000;
   
    border_matrix_origin(i,1)=min(row_index);         % JB
    border_matrix_origin(i,2)=max(row_index);         % JB
    border_matrix_origin(i,3)=min(column_index);      % JB
    border_matrix_origin(i,4)=max(column_index);      % JB
   % depth_anomaly(i) =max( depth_correction_matrix(find(connect_component==i)));           % JB

end

connect_component_r=bwlabel(depth_mask);
cluster_amount=max(max(connect_component_r));

for j=1:cluster_amount
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    %[row_index,column_index]=find(connect_component_r==j);
    %test_matrix=depth_mask(row_index,column_index)+connect_component(row_index,column_index);#it is not functioning like what you thought
    %[cluster_row_index,cluster_column_index]=find(test_matrix>1000);
    %%%!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    anomaly_index=find(connect_component_r==j);                    % return the indices of points contained in a cluster
    anomaly_nums=nonzeros(unique(connect_component(anomaly_index)));
    
    border_matrix_coor(j,1)=min(border_matrix_origin(anomaly_nums,1));
    border_matrix_coor(j,2)=max(border_matrix_origin(anomaly_nums,2));
    border_matrix_coor(j,3)=min(border_matrix_origin(anomaly_nums,3));
    border_matrix_coor(j,4)=max(border_matrix_origin(anomaly_nums,4));
    clu_depth=depth_correction_matrix(border_matrix_coor(j,1):border_matrix_coor(j,2),border_matrix_coor(j,3):border_matrix_coor(j,4));         %JB
    %[Pb(j,:)]=model_selection_quick(clu_depth{j}/100*pipethickness,SMYS,SMTS,AOD,pipethickness);
   if length(clu_depth(1,:))==1
    [Pb(j,:)]=[NaN, NaN, NaN, NaN, NaN];                 % JB
   else
    [Pb(j,:)]=model_selection_quick(clu_depth/100*pipethickness,SMYS,SMTS,AOD,pipethickness,resolution_length);                 % JB
   end
    
 %   [Pb_psqr(j,:)]=Psqr(clu_depth/100*pipethickness,SMYS,AOD,pipethickness,resolution_length); 
    length_defect(j)=(border_matrix_coor(j,4)-border_matrix_coor(j,3))*reso_x;
    width_defect(j)=(border_matrix_coor(j,2)-border_matrix_coor(j,1))*Element_size;
    max_depth(j)=max(max(clu_depth/100*pipethickness));
end

first_point=[border_matrix_coor(:,3) border_matrix_coor(:,1)];
second_point=[border_matrix_coor(:,3) border_matrix_coor(:,2)+1];
third_point=[border_matrix_coor(:,4)+1 border_matrix_coor(:,1)];
forth_point=[border_matrix_coor(:,4)+1 border_matrix_coor(:,2)+1];

% now, the plot is in the unit of index, if you want to include coordinate
% like surface(X,Y,depth_matrix), 
len1=length(depth_correction_matrix(:,1));          %JB
len2=length(depth_correction_matrix(1,:));          %JB

X=in_def(3,3):reso_x:in_def(3,3)+(len2-1)*reso_x;
Y=in_def(4,2):Element_size:in_def(4,2)+(len1-1)*Element_size;
[X1,Y1]=meshgrid(X,Y);

figure1 = figure;
axes1 = axes('Parent',figure1,'ydir','reverse');
hold(axes1,'on');
surf1 = surf(X1,Y1,depth_correction_matrix,'Parent',axes1);
%datatip(surf1,'DataIndex',12347);
ylabel({'Circumferential Direction (mm)'});
xlabel({'Longitudinal Direction (mm)'});
view(axes1,[0 90]);
xlim([min(X)-Element_size*0,max(X)+Element_size*0]);
ylim([min(Y)-Element_size*0,max(Y)+Element_size*0]);
grid(axes1,'on');
hold on;
for i=1:cluster_amount
plot([X(max(first_point(i,1),1))     X(max(second_point(i,1),1))],   [Y(max(first_point(i,2),1))  Y(min(second_point(i,2),len1))],'LineWidth',2,'Color','r');hold on;               
plot([X(max(second_point(i,1),1))    X(min(forth_point(i,1),len2))], [Y(min(second_point(i,2),len1)) Y(min(forth_point(i,2),len1)) ],'LineWidth',2,'Color','r');hold on;               
plot([X(min(third_point(i,1),len2))  X(min(forth_point(i,1),len2))], [Y(max(third_point(i,2),1))  Y(min(forth_point(i,2),len1)) ],'LineWidth',2,'Color','r');hold on;                 
plot([X(max(first_point(i,1),1))     X(min(third_point(i,1),len2))], [Y(max(first_point(i,2),1))  Y(max(third_point(i,2),1)) ],'LineWidth',2,'Color','r');hold on;                  
end
print('-dpng','-r1000','1.png');


summ_=[max_depth' length_defect' Pb];
c_c=[];time=[];
for i=1:cluster_amount
%clu_depth=depth_correction_matrix(border_matrix_coor(i,1):border_matrix_coor(i,2),border_matrix_coor(i,3):border_matrix_coor(i,4));         %JB
clu_depth=depth_correction_matrix(max(first_point(i,2),1):min(second_point(i,2),len1),max(second_point(i,1),1):min(forth_point(i,1),len2));         %JB
%[Pb_psqr(i)]=Psqr(clu_depth/100*pipethickness,SMYS,AOD,pipethickness,resolution_length); 
final_matrix=[];
final_matrix=zeros(length(clu_depth(:,1))+1,length(clu_depth(1,:))+2);
final_matrix(2:(length(clu_depth(:,1))+1),3:end)=clu_depth;
final_matrix(1,3:end)=X(1,max(second_point(i,1),1):min(forth_point(i,1),len2));
final_matrix(2:end,2)=(Y(1,max(first_point(i,2),1):min(second_point(i,2),len1)))';
%final_matrix(2:end,1)=[(border_matrix_coor(i,1)-1)*Element_size*2/AOD:Element_size*2/AOD:(border_matrix_coor(i,2)-1)*Element_size*2/AOD]'*180/3.14;
final_matrix_output=[];
final_matrix_output=zeros(length(clu_depth(:,1))+1+3,length(clu_depth(1,:))+2);
final_matrix_output(4:end,1:end)=final_matrix;
final_matrix_output(1:2,:)=[];

%%%%%%ת��ʱ��λ��
degree=final_matrix(fix(length(final_matrix(:,2))/2)+1,2)/(pi*D)*360;
hours=fix(degree/30);
minutes=fix((degree-hours*30)*2);
time1=[num2str(hours),':',num2str(minutes)];
time{i}=time1;
%%%%%%ת����ʴ����Ƕ�
   point_mid=round((border_matrix_coor(:,3)+border_matrix_coor(:,4))./2);
   Axial_center_length=X(point_mid);
   cluster_center_degree=round(Axial_center_length(i)/(bend_r*bend_angel/180*pi)*bend_angel,2);

%%%%%%%%%%
%c_one=table(i,in_def(1,1),in_def(1,2),in_def(1,3),in_def(1,4),in_def(1,5),in_def(1,6),in_def(1,7),in_def(1,8),in_def(1,9),in_def(1,10),max_depth(i)/in_def(1,6)*100,length_defect(i),width_defect(i),Pb(i,1)/in_def(1,9),Pb(i,2)/in_def(1,9),Pb(i,3)/in_def(1,9),Pb(i,4)/in_def(1,9),Pb(i,5)/in_def(1,9),0,0,'VariableNames',A);
if i==1
c_c=[c_c;[i,GWID,Threshold,corrosion_type,D,t,Clock_Position,staraight_length,bend_r,bend_angel,cluster_center_degree,Elastic_Modulus_MPa,SMYS_MPa,SMTS_MPa,Axial_Force_Pre,Axial_Force,MOP_MPa,Interaction_Rule,max_depth(i)/t*100,length_defect(i),width_defect(i),Pb(i,1)/MOP_MPa,Pb(i,2)/MOP_MPa,Pb(i,3)/MOP_MPa,Pb(i,4)/MOP_MPa,Pb(i,5)/MOP_MPa,0,0,0,Element_size,Substep_number,1,1,1]];
else 
c_c=[c_c;[i,GWID,Threshold,corrosion_type,D,t,Clock_Position,staraight_length,bend_r,bend_angel,cluster_center_degree,Elastic_Modulus_MPa,SMYS_MPa,SMTS_MPa,Axial_Force_Pre,Axial_Force,MOP_MPa,Interaction_Rule,max_depth(i)/t*100,length_defect(i),width_defect(i),Pb(i,1)/MOP_MPa,Pb(i,2)/MOP_MPa,Pb(i,3)/MOP_MPa,Pb(i,4)/MOP_MPa,Pb(i,5)/MOP_MPa,0,0,0,Element_size,Substep_number,1,1,0]];    
end

%writetable(c_one,filename)
%dlmwrite(filename,final_matrix_output,'delimiter',',','-append');
% FE_input{i}=[i,GWID,Threshold,corrosion_type,D,t,Clock_Position,staraight_length,bend_r,bend_angel,cluster_center_degree,Elastic_Modulus_MPa,SMYS_MPa,SMTS_MPa,Axial_force_KN,MOP_MPa,Interaction_Rule,max_depth(i)/t*100,length_defect(i),width_defect(i),Pb(i,1)/MOP_MPa,Pb(i,2)/MOP_MPa,Pb(i,3)/MOP_MPa,Pb(i,4)/MOP_MPa,Pb(i,5)/MOP_MPa,Element_size,Substep_number];
FE_input_depth{i}=final_matrix_output;
end



A= {'Cluster number','GWID','Threshold(%wt)','corrosion type','Outside Diameter','Wt (mm)','Clock Position(hrs:mins)','staraight_length(mm)','bend r(mm)','bend angel(��)','bend location angel(��)','Elastic Modulus(MPa)','SMYS (MPa)','SMTS (MPa)','Axial Force Pre(KN)','Axial Force(KN)','MOP (MPa)','Interaction Rule',...
    'Max Depth(%)','Length (mm) ','Width(mm)','FPR_Rstreng','FPR_CSA','FPR_B31G','FPR_PCORRC','FPR_DNV','FPR_DNV_COM','FPR_Psqr','FPR_FEM','Ele_size','Substep number','DNV_COM_Indicator','Psqr_Indicator','FEM_Indicator'};


AA=[A;num2cell(c_c)];

for i=1:cluster_amount
AA{i+1,7}=time{i};
end
Excel = actxserver('excel.application');
filename2=['Elbow_natural_corrosion_burst_capacity.xlsx'];
filename3=['Elbow_natural_corrosion_burst_capacity_update.xlsx'];
delete(filename2);
delete(filename3);
xlswrite(filename2,AA)
xlswrite(filename3,AA)



fclose all;
close all;
[status, message, messageid] =rmdir('burst_capacity_folder','s')  ;


save data