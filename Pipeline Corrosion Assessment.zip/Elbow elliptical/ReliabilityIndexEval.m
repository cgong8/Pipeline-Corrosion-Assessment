function [beta_index,gg] = ReliabilityIndexEval(u)

global corr_matrix;
u=u';

beta_index = u*inv(corr_matrix)*u';
if beta_index <0 
    disp('beta value less than zero - correlation matrix has to be positive definite!');
else
    beta_index = (sqrt(beta_index));
end
gg=[];
