  function [Pb]=burst_calculation_DNV(length_group_j,dmax_group_j,AOD,pipethickness,sigmau)
        
        Mm=(1+0.31*length_group_j^2/AOD/pipethickness)^0.5;
        Pb=2*pipethickness*sigmau/(AOD-pipethickness)*(1-dmax_group_j/pipethickness)/(1-dmax_group_j/pipethickness/Mm);
