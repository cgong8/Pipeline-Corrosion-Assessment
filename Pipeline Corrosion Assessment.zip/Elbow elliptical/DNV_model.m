function Pb=DNV_model(corrosion_profile,resolution_length,AOD,pipethickness,sigmau)

if max(corrosion_profile) ~= 0
   cluster_max=max(corrosion_profile);
   defect_nmber_Cluster5=max(bwlabel(cluster_max));
   cluster5_contour=bwlabel(cluster_max);  
   
   
   
    
   j=1;
   for m=1:defect_nmber_Cluster5                         % start defect number index
       for n=(m):defect_nmber_Cluster5                 % end defect number index
           groupj_defect{j}=m:n;
           j=j+1;         
       end
   end
   
   for j=1:length(groupj_defect)
       cluster_all_length_index=[];
       accumulator1=0;
       
       for k=1:length(groupj_defect{j})
           [width_index,length_index]=find(cluster5_contour==groupj_defect{j}(k));
           length_defect_k=(max(length_index)-min(length_index))*resolution_length;
           linearInd = sub2ind(size(cluster5_contour),width_index,length_index);
           dmax_defect_k=max(cluster_max(linearInd));
           
           cluster_all_length_index=[cluster_all_length_index;length_index'];
           accumulator1=accumulator1+length_defect_k*dmax_defect_k;
       end
           length_group_j=(max(cluster_all_length_index) - min(cluster_all_length_index)+2)*resolution_length;   
           dmax_group_j=accumulator1/length_group_j;
           Pb(j) = burst_calculation_DNV(length_group_j,dmax_group_j,AOD,pipethickness,sigmau);
   end
   
   Pb=min(Pb);
else
    Pb=0;
end
  
