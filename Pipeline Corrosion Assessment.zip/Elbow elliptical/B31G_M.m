function [ra]=B31G_M(Cluster5,SMYS,AOD,pipethickness,resolution_length)
    
    river_bottom=max(Cluster5);
    profile_selected=river_bottom(1:end);
    profile_selected_length=resolution_length*(length(profile_selected)-1);

    det_para=0;x(6)=profile_selected_length;x(7)=0;x(3)=AOD;x(2)=pipethickness;
    M=Folias(x(6),x(7),x(3),x(2),det_para);%l,gl,D,t
    wt=x(2);D=x(3);
    
    dmax=(max(river_bottom));
    sigmau=SMYS;
    
    if dmax<=wt*0.8
              ra=2*(sigmau+68.95)*wt/D*(1-0.85*dmax/wt)/(1-0.85*dmax/M/wt);       
    else
              dmax=wt*0.8;  
              ra=2*(sigmau+68.95)*wt/D*(1-0.85*dmax/wt)/(1-0.85*dmax/M/wt);
    end         
                       