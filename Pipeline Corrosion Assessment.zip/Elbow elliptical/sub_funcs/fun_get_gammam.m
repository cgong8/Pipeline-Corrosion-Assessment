function gammam=fun_get_gammam(measurement, safety_class)
switch measurement
    case 'MFL'
        switch safety_class
            case 'low'
                gammam=0.79;%0.82;
            case 'normal'
                gammam=0.74;%0.77;
            case 'high'
                gammam=0.7;%0.73;
            otherwise
                warning('***函数fun_get_xi未收到合法的Safety Class!');
        end
    case 'UT'
        switch safety_class
            case 'low'
                gammam=0.82;%0.85;
            case 'normal'
                gammam=0.77;%0.8;
            case 'high'
                gammam=0.72;%0.75;
            otherwise
                warning('***函数fun_get_xi未收到合法的Safety Class!');
        end
    otherwise
        warning('***函数fun_get_xi未收到合法的measurement!');
end
end