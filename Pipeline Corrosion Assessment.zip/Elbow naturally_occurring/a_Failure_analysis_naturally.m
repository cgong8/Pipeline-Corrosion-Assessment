

load('data.mat')
currentFolder = pwd;

FE_input_temp=readtable(filename2);
C = table2cell(FE_input_temp);
C(cellfun(@(x) isempty(x), C)) = {NaN};
C(cellfun(@(x) ischar(x), C)) = {NaN};
FE_input_temp = cell2table(C, 'VariableNames', FE_input_temp.Properties.VariableNames);
corrosion_type=FE_input_temp{:,4};
E_value=FE_input_temp{:,12};
cluster_num=FE_input_temp{:,1};
fea_index=FE_input_temp{:,34};

filename33=['jindu.txt'];
delete(filename33);
str = sprintf('jindu.txt');
fid=fopen(str,'wt');
fprintf(fid,'%d',length(FE_input_temp{:,1}));


for i=1:cluster_amount
    FE_input{i}=FE_input_temp{i,:};
end


[~,~,raw ]= xlsread(filename3);
[status1, message1, messageid1] = rmdir('Finite_element_picture','s');
[status2, msg2, msgID2] = mkdir('Finite_element_picture');
[status, message, messageid] =rmdir('burst_capacity_folder','s');
[status4, msg4, msgID4] = mkdir('burst_capacity_folder');

for j=1:cluster_amount
   
    lia=ismember(1, fea_index(j));
    if lia==0
        fprintf(fid,'\n');
        fprintf(fid,'%d',j);
    else
        fprintf(fid,'\n');
        fprintf(fid,'%d=%d',j,cluster_num(j));
    end
    %%%%%%%psqr
    try 
        
    clu_depth=depth_correction_matrix(border_matrix_coor(j,1):border_matrix_coor(j,2),border_matrix_coor(j,3):border_matrix_coor(j,4));         %JB
    
    if (length(clu_depth(1,:))) >=2 && (length(clu_depth(:,1))) >=2 && FE_input_temp{j,33}==1    
        [Pb_psqr]=Psqr(clu_depth/100*pipethickness,SMYS,AOD,pipethickness,resolution_length);
        raw{1+j,28} =Pb_psqr/MOP_MPa; % setting value
        xlswrite(filename3, raw); % saving it again
    else
        raw{1+j,28} =0; % setting value
        xlswrite(filename3, raw); % saving it again
    end
    catch
        cd (currentFolder);
            raw{1+j,28} =-100; % setting value
            xlswrite(filename3, raw); % saving it again
   end

    
   %%%%%%%%%%%%%%DNV
   try
        clu_depth=depth_correction_matrix(border_matrix_coor(j,1):border_matrix_coor(j,2),border_matrix_coor(j,3):border_matrix_coor(j,4));         %JB
        
        if (length(clu_depth(1,:))) >=2 && (length(clu_depth(:,1))) >=2 && FE_input_temp{j,32}==1
            
            % [DNV_com]=Psqr(clu_depth/100*pipethickness,SMYS,AOD,pipethickness,resolution_length);
            
            [DNV_com]=DNV_model_v3(clu_depth/100*pipethickness,resolution_length, AOD, pipethickness, SMTS);
            
            raw{1+j,27} =DNV_com/MOP_MPa;% setting value
            xlswrite(filename3, raw); % saving it again
            
            
        else
            raw{1+j,27} =0; % setting value
            xlswrite(filename2, raw); % saving it again
        end
        
    catch
        cd (currentFolder);
            raw{1+j,27} =-100; % setting value
            xlswrite(filename3, raw); % saving it again
   end
 
    
 
   
%%%%%%%%%%%%%%%FEA
   try
    if length(FE_input_depth{j}(1,:))>=4 && length(FE_input_depth{j}(:,1))>=4 && FE_input_temp{j,34}==1
        folder = 'burst_capacity_folder';  %
        files = fullfile(folder, '*');  % 
        delete(files);  %
        
        test_result{j}=APDL_model_generation_naturally11_8(ansys_path,Elastic_Modulus_MPa,FE_input{j},FE_input_depth{j},j);
        
        inter_tr= cell2mat(test_result{j}(j,2));
        raw{1+j,29} =inter_tr/MOP_MPa; % setting value
        xlswrite(filename3, raw); % saving it again
    else
        raw{1+j,29} = 0; % setting value
        xlswrite(filename3, raw); % saving it again
    end
        catch
        raw{1+j,29} = -100; % setting value
        xlswrite(filename3, raw); % saving it again
    end
end
fclose('all')
