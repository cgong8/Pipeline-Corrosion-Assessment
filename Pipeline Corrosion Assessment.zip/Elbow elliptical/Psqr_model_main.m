clear all;
clc;


iiii=1;
    
    load(['cluster',num2str(iiii),'.mat']);
    
    AOD=508;
    pipethickness=6.35;
    sigmay=359;
    sigmau=455;
        corrosion_profile=corrosion_profile/100*pipethickness;

    
    [M,N]=size(corrosion_profile);
    defect_length=2*(N-1);
    cluster_length(iiii,1)=defect_length;
    cluster_width(iiii,1)=2*(M-1);
    
     
   % P2 model
   [M,N]=size(corrosion_profile);
   resolution_length=2;
   x_coor=[0:2:2*N-2];
   y_coor=[0:2:2*M-2];
   for Monte_carlo_num=1:500
       surface_vector=reshape(corrosion_profile,M*N,1);
       a_ran_num=max(1,abs(floor((rand(1,1)-0.0001)*M*N)));
       deepest_depth=surface_vector(a_ran_num);
       [start_point_y,start_point_x]=find(corrosion_profile==deepest_depth,1,'first');
       
       left_iteration=start_point_x-1;                           % the total number of iteration on left side
       right_iteration=N-start_point_x;                          % the total number of iteration on right side
       start_point_y1=start_point_y;
       start_point_x1=start_point_x;
       start_point_y2=start_point_y;
       start_point_x2=start_point_x;
       start_point_y3=start_point_y;
       start_point_x3=start_point_x;
       start_point_y4=start_point_y;
       start_point_x4=start_point_x;
       if left_iteration==0
           for k=1:right_iteration
               [points_y,points_x,corrosion_depth_right(k)]=point_selection_algorithm_right(start_point_y1,start_point_x1,corrosion_profile,pipethickness,x_coor,y_coor);
               start_point_y1=points_y;
               start_point_x1=points_x;
           end
           failure_profile=[deepest_depth,corrosion_depth_right];
       elseif right_iteration==0
           for k=1:left_iteration
               [points_y,points_x,corrosion_depth_left(k)]=point_selection_algorithm_left(start_point_y2,start_point_x2,corrosion_profile,pipethickness,x_coor,y_coor);
               start_point_y2=points_y;
               start_point_x2=points_x;
           end
       failure_profile=[corrosion_depth_left(end:-1:1),deepest_depth];
                
       elseif right_iteration~=0 && left_iteration~=0
           corrosion_depth_left=zeros(left_iteration,1);
           for j=1:left_iteration
               [points_y,points_x,corrosion_depth_left(j)]=point_selection_algorithm_left(start_point_y3,start_point_x3,corrosion_profile,pipethickness,x_coor,y_coor);
               start_point_y3=points_y;
               start_point_x3=points_x;
           end
           corrosion_depth_right=zeros(right_iteration,1);
           for k=1:right_iteration
               [points_y,points_x,corrosion_depth_right(k)]=point_selection_algorithm_right(start_point_y4,start_point_x4,corrosion_profile,pipethickness,x_coor,y_coor);
               start_point_y4=points_y;
               start_point_x4=points_x;
           end
           failure_profile=[corrosion_depth_left(end:-1:1)',deepest_depth,corrosion_depth_right'];
       end
       as=repmat(failure_profile,2,1);
       [Pb_all(Monte_carlo_num)]=Rstreng(as,sigmay,AOD,pipethickness,resolution_length);
       
       
       corrosion_depth_left=[];
       corrosion_depth_right=[];
       left_point_x=[];
       left_point_y=[];
       right_point_x=[];
       right_point_y=[];
       
   end
     
   
     sorted_Pb_all=sort(Pb_all);
     Pb_psqr(1,1)=sorted_Pb_all(round(Monte_carlo_num*0.05));        
   
%[Burst_pressure]=Rstreng(corrosion_profile,sigmay,AOD,pipethickness,resolution_length);
