function p=fun_p(gamma_m,t,f_u,D,gamma_d,d_t_star,Q)
if gamma_d*(d_t_star)<1
    p=round(....
        gamma_m.*2.*t.*f_u./(D-t).*.....
        (1-gamma_d.*(d_t_star))./(1-gamma_d.*(d_t_star)./Q),2);
else
    p=0;
end
end