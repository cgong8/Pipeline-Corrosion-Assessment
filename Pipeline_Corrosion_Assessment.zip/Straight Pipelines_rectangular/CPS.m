function [Pb_cps]=CPS(corrosion_profile,pipethickness,AOD,long_resoultion,sigmay,sigmau)


for iiii=1:1
    
    [M,N]=size(corrosion_profile);
    defect_length=2*(N-1);
    cluster_length(iiii,1)=defect_length;
    cluster_width(iiii,1)=2*(M-1);

   % CPS model
   n=0.239*(sigmau/sigmay-1)^0.565; 
   % n > Zhu. X. K. and Leis. B. N. 2012. Evaluation of burst pressure prediction models for line pipes. International Journal of Pressure Vessels and Piping. 89: 85 - 97.
   C=1/2+1/sqrt(3);
   P_plain=(C/2)^(n+1)*4*pipethickness/AOD*sigmau;

   Pb_cps1=WDD(corrosion_profile,pipethickness,AOD,long_resoultion,P_plain,n,sigmau);
   Pb_cps(iiii,1)=Pb_cps1;
     
end

