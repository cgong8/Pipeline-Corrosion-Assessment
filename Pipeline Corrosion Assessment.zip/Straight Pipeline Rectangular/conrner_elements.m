function [total_node_matrix,total_element_matrix]=conrner_elements(node_coor_matrix_inside,total_element_matrix,t,outside_node_x_east,outside_node_x_west,outside_node_y_north,outside_node_y_south,total_node_matrix)
transition_node_edge=[1	0	1	1
    2	0	1	0
    3	0	1	0.499212598
    4	1	1	0
    5	1	1	1
    6	1	1	0.749606299
    7	1	1	0.499212598
    8	1	1	0.250393701
    9	0.56	1	0.722834646
    10	0.56	1	0.277165354
    11	0.51984252	1	0.499212598
    12	1	0	0
    13	1	0	1
    14	1	0	0.499212598
    15	1	0.560629921	0.277165354
    16	1	0.560629921	0.722834646
    17	1	0.519685039	0.499212598
    18	0	0	1
    19	0	0	0
    20	0	0	0.499212598
    21	0.517637795	0.518110236	0.264566929
    22	0.517637795	0.518110236	0.735433071
    23	0.510393701	0.51023622	0.499212598];


element_connection_transition=[1	8	7	11	10	15	17	23	21
2	7	6	9	11	17	16	22	23
3	6	5	1	9	16	13	18	22
4	9	1	3	11	22	18	20	23
5	11	3	2	10	23	20	19	21
6	10	2	4	8	21	19	12	15
7	15	17	23	21	12	14	20	19
8	17	16	22	23	14	13	18	20];  

      
       x_coor_all_node_inside= node_coor_matrix_inside(:,2);
       y_coor_all_node_inside= node_coor_matrix_inside(:,3);
       z_coor_all_node_inside= node_coor_matrix_inside(:,4);
       
       start_x_loc=min(x_coor_all_node_inside);
       end_x_loc=max(x_coor_all_node_inside);
       
       start_y_loc=min(y_coor_all_node_inside);
       end_y_loc=max(y_coor_all_node_inside);
       
       transition_element_depth=t;
       
      
       
       transition_node_edge1=transition_node_edge;
       element_connection_transition1=element_connection_transition;
       
       % north_west 
       length_NW = abs(start_x_loc-outside_node_x_west);
       width_NW  = abs(start_y_loc-outside_node_y_north);
       node_num_now=max(total_node_matrix(:,1));
       element_num_now=length(total_element_matrix(:,1));
       transition_node_edge(:,1)=node_num_now+[1:23]';
       transition_node_edge(:,2)=start_x_loc-(1-transition_node_edge1(:,2))*length_NW;
       transition_node_edge(:,4)=min(z_coor_all_node_inside)+transition_node_edge1(:,4)*transition_element_depth; 
       transition_node_edge(:,3)=start_y_loc-(1-transition_node_edge1(:,3))*width_NW;
       element_connection_transition(:,1)=element_connection_transition1(:,1)+element_num_now;
       element_connection_transition(:,2:end)=element_connection_transition1(:,2:end)+node_num_now;
       total_node_matrix=[total_node_matrix;transition_node_edge];
       total_element_matrix=[total_element_matrix;[repmat([1,1,1,1,0,0,0,0,8,0],8,1),element_connection_transition]]; 
              
       % south_west 
       length_SW = abs(start_x_loc-outside_node_x_west);
       width_SW  = abs(end_y_loc-outside_node_y_south);
       node_num_now=max(total_node_matrix(:,1));
       element_num_now=length(total_element_matrix(:,1));
       transition_node_edge(:,1)=node_num_now+[1:23]';
       transition_node_edge(:,2)=start_x_loc-(1-transition_node_edge1(:,2))*length_SW;
       transition_node_edge(:,4)=min(z_coor_all_node_inside)+transition_node_edge1(:,4)*transition_element_depth; 
       transition_node_edge(:,3)=end_y_loc+(1-transition_node_edge1(:,3))*width_SW;
       element_connection_transition(:,1)=element_connection_transition1(:,1)+element_num_now;
       element_connection_transition(:,2:end)=element_connection_transition1(:,2:end)+node_num_now;
       total_node_matrix=[total_node_matrix;transition_node_edge];
       total_element_matrix=[total_element_matrix;[repmat([1,1,1,1,0,0,0,0,8,0],8,1),element_connection_transition]]; 
       
       % south_east 
       length_SE = abs(end_x_loc-outside_node_x_east);
       width_SE  = abs(end_y_loc-outside_node_y_south);
       node_num_now=max(total_node_matrix(:,1));
       element_num_now=length(total_element_matrix(:,1));
       transition_node_edge(:,1)=node_num_now+[1:23]';
       transition_node_edge(:,2)=end_x_loc+(1-transition_node_edge1(:,2))*length_SE;
       transition_node_edge(:,4)=min(z_coor_all_node_inside)+transition_node_edge1(:,4)*transition_element_depth; 
       transition_node_edge(:,3)=end_y_loc+(1-transition_node_edge1(:,3))*width_SE;
       element_connection_transition(:,1)=element_connection_transition1(:,1)+element_num_now;
       element_connection_transition(:,2:end)=element_connection_transition1(:,2:end)+node_num_now;
       total_node_matrix=[total_node_matrix;transition_node_edge];
       total_element_matrix=[total_element_matrix;[repmat([1,1,1,1,0,0,0,0,8,0],8,1),element_connection_transition]]; 
       
       % north_east
       length_NE = abs(end_x_loc-outside_node_x_east);
       width_NE  = abs(start_y_loc-outside_node_y_north);
       node_num_now=max(total_node_matrix(:,1));
       element_num_now=length(total_element_matrix(:,1));
       transition_node_edge(:,1)=node_num_now+[1:23]';
       transition_node_edge(:,2)=end_x_loc+(1-transition_node_edge1(:,2))*length_NE;
       transition_node_edge(:,4)=min(z_coor_all_node_inside)+transition_node_edge1(:,4)*transition_element_depth; 
       transition_node_edge(:,3)=start_y_loc-(1-transition_node_edge1(:,3))*width_NE;
       element_connection_transition(:,1)=element_connection_transition1(:,1)+element_num_now;
       element_connection_transition(:,2:end)=element_connection_transition1(:,2:end)+node_num_now;
       total_node_matrix=[total_node_matrix;transition_node_edge];
       total_element_matrix=[total_element_matrix;[repmat([1,1,1,1,0,0,0,0,8,0],8,1),element_connection_transition]]; 
       
 
end