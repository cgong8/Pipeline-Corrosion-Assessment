function data_profile=gen_samples(len,mean,std,x_max,num_x)
RFInput.Type =          'RandomField';
RFInput.Corr.Family =   'Gaussian';
RFInput.RFType =        'Lognormal';
RFInput.Corr.Length =   len;
RFInput.Mean=           mean;
RFInput.Std=            std;
RFInput.Mesh=           linspace(0,x_max,num_x)';
myRF =                  uq_createInput(RFInput);
data_profile=           [RFInput.Mesh uq_getSample(1)'];
end
