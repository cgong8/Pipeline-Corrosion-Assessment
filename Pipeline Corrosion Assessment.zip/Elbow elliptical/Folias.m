%This is a function to calaulate the folias factor
function m=Folias(l,gl,D,t,tao)
a=((l+gl*tao)^2)/(D*t);
if a<=50
    m=sqrt(1+0.6275*a-0.003375*(a^2));
else
    m=0.032*a+3.293;
end

    