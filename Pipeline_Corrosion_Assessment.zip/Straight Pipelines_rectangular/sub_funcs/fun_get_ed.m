function e_d=fun_get_ed(Std_d_t)
if Std_d_t<0.04
    e_d=        0;
elseif Std_d_t>=0.04 && Std_d_t<=0.16
    e_d=-1.33+37.5*Std_d_t-104.2.*Std_d_t.^2;
else
    warning('***函数fun_get_ed中Std_d_t超过了0.16!');
end
e_d=round(e_d,2);
end