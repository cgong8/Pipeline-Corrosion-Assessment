function [formresults]=mini(u0,covariance,tiqu_xin,indicator, denum,total,t)

%%%u, indicator, denum,total,dist_para

e1=1/1000;
e2=0.001;
i = 1;         % Initialize counter.
conv_flag = 0; % Convergence is achieved when this flag is set to 1.
i_max=100;
u=(covariance*u0')';
%save error

% Perform iterative loop to find the design point
dist_para=Cal_distpara(tiqu_xin);
ccd=dist_para(1+11*(denum-1):11+11*(denum-1),:);

while conv_flag == 0
  % disp('..................................')
  % disp('Now carrying out iteration number:'),disp(i)

   x= u_x_transform((covariance*u'), ccd);
   J_u_x= jacobian(x,(covariance*u')',covariance,tiqu_xin(1+11*(denum-1):11+11*(denum-1),:));
   J_x_u = inv(J_u_x);
   %save error
  [ G,grad_g] = gfun((covariance*u'), indicator, denum,total,ccd,t);
   grad_G = (grad_g*J_x_u)';

   % Set scale parameter Go and inform about struct. resp.
   if i == 1
      Go = G;
    %  disp('Value of limit-state function in the first step:')
    %  disp(G)
   end
   
   % Compute alpha vector
   alpha = -grad_G / norm(grad_G);
      
   % Check convergence
   if ( (abs(G/Go)<e1) & (norm(u'-alpha'*u'*alpha)<e2) ) | i==i_max
      conv_flag = 1;
   end
   
   

   % Take a step if convergence is not achieved
   if conv_flag == 0;
      
      % Determine search direction
      d = search_dir(G,grad_G,u);
      
     if norm(d)==0
        d = 0.000001*ones(length(grad_G),1); 
     end   
      
      % Determine step size
       step_code=0;
      if step_code == 0
         
         %step = step_size_previous(lsf,G,grad_G,alpha,u,d,Lo,probdata,gfundata,femodel,randomfield,analysisopt,J_x_u);
         step =  stepgong(G,grad_G,u',d,indicator, denum,total,ccd,t,covariance);
      else
         step = 0.1;
      end



      % Determine new trial point
      u_new = u + step * d';
      
      % Prepare for a new round in the loop
      
      u = u_new;
      i = i + 1;

   end
   
end   
   %  Post-processing 
   formresults.iter= i;                                                   % Number_of_iterations
   formresults.beta1= alpha'* u';                                          % Reliability_index_beta 
   formresults.dsptu= u;                                                  % Design_point_u_star
   formresults.dsptx= x';                                                 % Design_point_in_original_space
   formresults.alpha= alpha;                                              % Alpha_vector
   
