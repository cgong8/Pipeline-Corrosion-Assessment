function x = u_x_transformX(u1, dist_para,covariance)

% Inverse normal transformation
% Generally follows the macro function developed by Low and Tang (2007): "Efficient Spreadsheet Algorithm for First-order Reliability Method" J. Eng. Mech. 133(12): 1378-1387
% dis_para(:,6) is a vector containing the following information:
% dis_para(:,1) = distribution type, dis_para(:,2) = para1, dis_para(:,3) = para2, dis_para(:,4) = empty, dis_para(:,5) = lower bound, dis_para(:,6) = upper bound
    % Distribution Type:
    % Deterministic = 0; Uniform = 1; Normal = 2; Lognormal = 3; Gamma = 4; Weibull = 5; Gumbel = 6; Beta = 7; Exponential = 8; Poisson = 9; Triangular = 10;
        % for Lognormal distribution, dist_para(:,5) = lower bound (shift)
        % for Beta distribution, dist_para(:,5)=lower bound, dist_para(:,6) = upper bound
        % for Exponential distribution, dist_para(:,5) = lower bound (shift)
        % for Triangular distribution, dist_para(:,5)=lower bound, dist_para(:,6) = upper bound
    u = (covariance * u1')';
    n = size(u(1,:),2);
    for i = 1:n
        dist_type = dist_para(i,1);
        switch dist_type
        case 0
            x(:,i) = dist_para(i,2);
        case 1
            ll = dist_para(i,2);
            ul = dist_para(i,3);
            x(:,i) = ll + (ul - ll)*normcdf(u(:,i),0,1);
        case 2
            mean = dist_para(i,2);
            stdev = dist_para(i,3);
            x(:,i) = mean + u(:,i)*stdev;
        case 3
            lamda = dist_para(i,2);
            zeta = dist_para(i,3);
            LB = dist_para(i,5);
            x(:,i)= LB + exp(lamda + zeta*u(:,i));
        case 4
            k = dist_para(i,2);  % Gamma distribution parameter k, corresponding to parameter a in Matlab function Gamrnd(a,b)
            v = dist_para(i,3);                                       % Gamma distribution parameter v, corresponding to inverse of parameter b (1/b) in Matlab function Gamrnd(a,b)
            x(:,i)=gaminv(normcdf(u(:,i),0,1),k, 1/v);
        case 5
            k = dist_para(i,2);                                                                        % Weibull distribution parameter, k, corresponding to parameter b in Matlab function Weibrnd(a,b)
            v = dist_para(i,3);                        % Weibull distribution parameter, v, parameter a in Matlab function Weibrnd(a,b) = (1/v)^k     
            x(:,i) = weibinv(normcdf(u(:,i),0,1),(1/v)^k,k);
        case 6
            alfa = dist_para(i,2);       % Gumbel distribution parameter, alfa
            v = dist_para(i,3);   % Gumbel distribution parameter, u
            x(:,i)=v - log(-log(normcdf(u(:,i),0,1)))/alfa;
        case 7
            r = dist_para(i,2);
            q = dist_para(i,3);
            LB = dist_para(i,5);
            UB=dist_para(i,6);
            x(:,i) = LB + (UB - LB)*betainv(normcdf(u(:,i),0,1),q, r);
        case 8
            mean = dist_para(i,2);
            LB = dist_para(i,5);
            x(:,i) = LB + expinv(normcdf(u(:,i),0,1), mean);
        case 9
            mean = dist_para(i,2);
            x(:,i) = poissinv(normcdf(u(:,i),0,1), mean);
        case 10
            mode = dist_para(i,2);
            a = dist_para(i,5);
            b = dist_para(i,6);
            maba = (mode-a)/(b-a);
            if normcdf(u(i),0,1)< maba
                x(:,i)= a + sqrt(normcdf(u(:,i),0,1)*(mode-a)*(b-a));
            else
                x(:,i) = b - sqrt((1-normcdf(u(:,i),0,1))*(b-a)*(b-mode));
            end
        end
    end