function [result]=APDL_model_generation_bend_ellipse(ansys_path,workname,E_value,start_cluster_ID,end_cluster_ID)
currentFolder = pwd;
T=readtable(workname);
C = table2cell(T);
C(cellfun(@(x) isempty(x), C)) = {NaN};
C(cellfun(@(x) ischar(x), C)) = {NaN};
T = cell2table(C, 'VariableNames', T.Properties.VariableNames);

cluster_ID_unique=unique(T{:,2});      % unique parent cluster ID
cluster_ID=T{:,2};                     % parent cluster ID
feature_ID=T{:,1};                     % child corrosion anomaly ID

if length(cluster_ID)~=length(feature_ID)
    disp ("Error! every child anomaly should belong to a cluster,simulation terminates")
    return
end
longitudinal_center=T{:,3};
D_all=T{:,4};        % outer diameter of all the pipelines
wall_thickness=T{:,5};                 % wall thickness
straight_length_all=T{:,6};
bend_r_all=T{:,7};
bend_angel_all=T{:,8};
cir_center_all=T{:,9};
bend_location_angel_all=T{:,10};
corrosion_type_all=T{:,11};
defect_depth_all=T{:,12};               % anomaly depth
defect_length_all=T{:,13};              % anomaly length
defect_width_all=T{:,14};                % anomaly width
YS_all=T{:,16};                         % yield strength
UTS_all=T{:,17};                       % UTS
Axial_Force_Pre_all=T{:,18}*1000;
axial_force_all=T{:,19}*1000;
ELE_size=T{:,21};
Substep_Number_all=T{:,22};
bend_start_all=0;
bend_end_all=bend_r_all.*bend_angel_all/180*pi;

ans = dos('md burst_capacity_folder');       % generate the folder to save all the files



for iii=start_cluster_ID:end_cluster_ID
 
    cd (currentFolder);
    ID_no=cluster_ID_unique(iii);
    index_no=find(cluster_ID==ID_no);
    t=wall_thickness(index_no(1));
    D=D_all(index_no(1));
    bend_r=bend_r_all(index_no(1));
    bend_start=bend_start_all;
    bend_end=bend_end_all(index_no(1));
    bend_length=bend_end-bend_start;
    straight_length=straight_length_all(index_no(1));
    bend_location_angel=bend_location_angel_all(index_no(:));
    bend_angel=bend_angel_all(index_no(1));
    corrosion_type=corrosion_type_all(index_no(1));
    Substep_Number=Substep_Number_all(index_no(1));
    
    
    
    %%%%%%%%%%������������жϳ���
    if bend_r==0
        longitudinal_position = longitudinal_center(index_no)*1000-min(longitudinal_center(index_no)*1000);
    else
        longitudinal_position = bend_r*bend_location_angel/180*pi;
    end
    circumferential_position_hh_mm=cir_center_all(index_no,1);
   circumferential_position=circumferential_position_hh_mm*2*pi*D;  % in the unit of (mm)
   cir_clock_degree_radian=circumferential_position/(D/2);
    defect_length_affection=(bend_r-D/2*sin(cir_clock_degree_radian))/bend_r;
  
    
    %��ʴ��Ϣ
    defect_length=defect_length_all(index_no)./defect_length_affection;
    defect_width=defect_width_all(index_no);                                              % for example, the 5th column is the defect width (but convert it to the (mm)
    defect_depth=defect_depth_all(index_no)/100*t;                                       % for example, the 6th column is the defect depth in the unit of mm
    cluster_size_min=min(defect_length,defect_width);
    
    
    %%%%%%%��ʾ
    
    if length(unique(wall_thickness(index_no)))>1
        disp ("Error! wall thickness for a cluster shoould be consistent,simulation terminates")
        return;
    end
    
    if length(unique(YS_all(index_no)))>1
        disp ("Error! Yield strength for a cluster shoould be consistent,simulation terminates")
         return;
    end
    
    if length(unique(UTS_all(index_no)))>1
        disp ("Error! UTS for a cluster should be consistent,simulation terminates")
          return;
    end
    
    %%%%%%%%%%%���������С
    element_corrosion_num= max(cluster_size_min(1)/(pi*D)*360,30);%%%%%%%��ʴ����������
    element_minnum=30;%%%%%%%�Ǹ�ʴ����С��������
    element_maxnum=70;%%%%%%%�Ǹ�ʴ�������������
    translation_element_layer=1;%%%%%%%���ɴ���
    if defect_depth~=0
        %���������С
        if isnan(ELE_size(index_no(1)))
            element_size=cluster_size_min(1)/element_corrosion_num;
        else
            element_size=ELE_size(index_no(1));
        end
        element_outermost_num=pi*D/(element_size*3^translation_element_layer);
        while (element_outermost_num>element_maxnum && element_outermost_num>=element_minnum)
            translation_element_layer=translation_element_layer+1;
            element_outermost_num=pi*D/(element_size*3^translation_element_layer);
            if element_outermost_num<element_minnum
                translation_element_layer=translation_element_layer-1;
                element_outermost_num=pi*D/(element_size*3^translation_element_layer);
                break;
            end
        end
        if element_outermost_num<element_minnum
            translation_element_layer=1;
            element_size=pi*D/(element_minnum*3^translation_element_layer);
        end
    else
        %��ȱ�����
        translation_element_layer=0;
        element_size=pi*D/(element_minnum*3^translation_element_layer);
    end
    element_size_x=element_size;
    element_size_y=element_size;
    
    
    %%%Ĭ��Ϊ�ⸯʴ
    if isnan(corrosion_type)
        corrosion_type=1;
    end
    %%%���õ���ģ��Ĭ��ֵ
    if isnan(E_value)
        E_value=200000;
    end
    %%%���û������Ӳ���
    if isnan(Substep_Number)
        Substep_Number=200;
    end
    
    %�ж��Ƿ���ѹ����Ӧ������
    if isnan(Axial_Force_Pre_all(index_no(1)))
        Axial_Force_Pre=0;
    else
        Axial_Force_Pre=Axial_Force_Pre_all(index_no(1));
    end
    %�ж��Ƿ�����������
    if isnan(axial_force_all(index_no(1)))
        axial_force=0;
    else
        axial_force=axial_force_all(index_no(1));
    end
    
    % element size in the corrosion free area (mm)
    circumsurround=element_size_y*3^translation_element_layer;
    longsurround=element_size_x*3^translation_element_layer;

    % here, determine the length/width of the corrosion cluster in the
    % FEA model
    long_start =  min(longitudinal_position   -  defect_length/2);
    long_end   =  max(longitudinal_position    +  defect_length/2);
    cir_start  =  min(circumferential_position -  defect_width/2);
    cir_end    =  max(circumferential_position +  defect_width/2);
    cir_move   =  (cir_start+defect_width(1)/2)-pi*D/2;
    cir_pos_index=find(circumferential_position==max(circumferential_position));
    cir_center=circumferential_position(cir_pos_index(1))/D*2;
    
    cir_center1=(max(circumferential_position)+min(circumferential_position))/2;
    
    cluster_length = long_end -  long_start ;
    cluster_width  = cir_end  -  cir_start  ;
    
    cluster_long_start =  longitudinal_position - defect_length/2;
    cluster_long_end   =  cluster_long_start + defect_length;
    cluster_cir_start  =  circumferential_position-cir_move-defect_width/2;
    cluster_cir_end    =  cluster_cir_start  +  defect_width;
    circumferential_position1=circumferential_position-cir_move;
    
    long_start =  min(cluster_long_start);
    long_end   =  max(cluster_long_end);
    cir_start  =  min(cluster_cir_start);
    cir_end    =  max(cluster_cir_end);
    
    
    cluster_border_num=8;
    startlong_fine  = long_start -  element_size*cluster_border_num;
    endlong_fine    = long_end   +  element_size*cluster_border_num;
    startcircum_fine= cir_start  -  element_size*cluster_border_num;
    endcircum_fine  = cir_end    +  element_size*cluster_border_num;
    
    % compare the cluster width to prevent the corrosion area to be too wide
    corrosion_cluster_width_limit = D * pi * 2 / 3;
    if cluster_width >= corrosion_cluster_width_limit
        disp ("Corrosion feature is too wide, simulation teminates")
        continue;
    end
    
    corrosion_cluster_num_long =  round(cluster_length/element_size);
    corrosion_cluster_num_cir  =  round(cluster_width /element_size);
    
    
    Cluster_corrosion_profile=zeros(corrosion_cluster_num_cir,corrosion_cluster_num_long);
    for j=1:length(index_no)
        x_coor = linspace( startlong_fine,endlong_fine,corrosion_cluster_num_long);
        y_coor = linspace(startcircum_fine,endcircum_fine,corrosion_cluster_num_cir);
        
        for i_x=1:length(x_coor)
            if  x_coor(i_x)<cluster_long_start(j) || x_coor(i_x)>cluster_long_end(j)
                x_coor(i_x) = 1e9;
            end
        end
        for i_y=1:length(y_coor)
            if  y_coor(i_y)<cluster_cir_start(j) || y_coor(i_y)>cluster_cir_end(j)
                y_coor(i_y) = 1e9;
            end
        end
        
        [X_coor,Y_coor]=meshgrid(x_coor,y_coor);
        z_squared=defect_depth(j)^2*(1-(X_coor-longitudinal_position(j)).^2/(defect_length(j)/2)^2-(Y_coor-circumferential_position1(j)).^2/(defect_width(j)/2)^2);
        z_squared(z_squared<0)=0;
        Cluster_corrosion_profile_supplement=sqrt(z_squared);
        overlapped_elements=max(Cluster_corrosion_profile(Cluster_corrosion_profile_supplement>0),Cluster_corrosion_profile_supplement(Cluster_corrosion_profile_supplement>0));
        Cluster_corrosion_profile=Cluster_corrosion_profile+Cluster_corrosion_profile_supplement;
        Cluster_corrosion_profile(Cluster_corrosion_profile_supplement>0)=overlapped_elements;
        Cluster_corrosion_profile(1,:)=0;
    end
    Cluster=Cluster_corrosion_profile;
    
    % This part is the FEA generation part
    % firstly, I want to caculate the stress-strain curve
    % E_value=2e5;                                                          % Young's modulus: must be positive (MPa)
    YS_value=YS_all(index_no(1));                                         % Tield strength : must be positive (MPa)
    UTS_value=UTS_all(index_no(1));                                       % Ultimate tensile strength : must be positive (MPa)
    
    strain_exponential=0.224*(UTS_value/YS_value-1)^0.604;                % Sigma= K *epsilon^n;
    true_ultimate=UTS_value*exp(strain_exponential);
    K=true_ultimate/(strain_exponential^strain_exponential);
    plastic_stress_ansys=linspace(YS_value,true_ultimate+100,20);
    plastic_strain_ansys=(plastic_stress_ansys/K).^(1/strain_exponential);
    plastic_strain_ansys(1)=YS_value/E_value;
    pressure_applied=4*UTS_value*t/D;
    
    outputdata=cat(2,'tbpt,','defi');
    B = repmat(outputdata,[20,1]);
    for ii=1:20
        M{ii}=[B(ii,:),',',num2str(plastic_strain_ansys(ii)),',',num2str(plastic_stress_ansys(ii))];
    end
    
    
    % call ANSYS to generate the mesh on a plate
    fid = fopen('plane_remesh.txt');
    plane_mesh_data= textscan(fid,'%s','delimiter','\n');
    plane_mesh_data{1,1}(7)={['D=',num2str(D)]};
    plane_mesh_data{1,1}(8)={['startlong_fine=',num2str(startlong_fine)]};
    plane_mesh_data{1,1}(9)={['endlong_fine=',num2str(endlong_fine)]};
    plane_mesh_data{1,1}(10)={['startcircum_fine=',num2str(startcircum_fine)]};
    plane_mesh_data{1,1}(11)={['endcircum_fine=',num2str(endcircum_fine)]};
    plane_mesh_data{1,1}(12)={['circum_increment=',num2str(element_size)]};
    plane_mesh_data{1,1}(13)={['long_increment=',num2str(element_size)]};
    plane_mesh_data{1,1}(14)={['translation_element_layer=',num2str(translation_element_layer)]};
    plane_mesh_data{1,1}(15)={['bend_start=',num2str(bend_start)]};
    plane_mesh_data{1,1}(16)={['bend_end=',num2str(bend_end)]};
    plane_mesh_data{1,1}(17)={['straight_length=',num2str(straight_length)]};
    fclose(fid);
    
    str = sprintf('plane_element%d.txt',iii);
    fid=fopen(str,'wt');
    [A,B]=size(plane_mesh_data{1,1});
    for i=1:A
        every_row=char(plane_mesh_data{1,1}(i));
        fprintf(fid,'%s\n',every_row);
    end
    
    every_row=[];
    fclose(fid);
    % move the generated file to the newly created folder
    DST_PATH_t = './burst_capacity_folder/';
    movefile(str,DST_PATH_t);
    copyfile('plane_remesh.txt',DST_PATH_t);
    copyfile('node_element_FEA_generation.txt',DST_PATH_t);
    copyfile('cluster16.txt',DST_PATH_t);
    copyfile('post_process_strain_stress_plot.txt',DST_PATH_t);
    copyfile('corner_element.txt',DST_PATH_t);
    copyfile('corner_nodes.txt',DST_PATH_t);
    copyfile('post_process_strain_stress_plot.txt',DST_PATH_t);
    
    cd (DST_PATH_t);
    
    % call ANSYS to generate the model
    jobname=['model_generation_cluster',num2str(cluster_ID_unique(iii))];
    skriptFileName=['plane_element',num2str(iii),'.txt'];
    outputFilename=['cluster_output.txt'];
    sys_char=strcat('SET KMP_STACKSIZE=4096k &',32,ansys_path,32,...
        '-b -p ansys -i',32,skriptFileName,32,'-j',32,jobname,32,'-o',32,outputFilename),
    ans1=system(sys_char);
    
    str = sprintf('node_file.txt');
    Extra_node_information=importdata(str);
    cd(currentFolder);
    num_node_one_layer=length(Extra_node_information);
    internal_radius=D/2-t;
    outer_radius=D/2;
    
    
    % scatter(Extra_node_information(:,1),Extra_node_information(:,2))
    x_coor_node=Extra_node_information(:,1);
    y_coor_node=Extra_node_information(:,2);
    z_coor_node=outer_radius*ones(num_node_one_layer,1);
    
    
    % inside the corrosion cluster area
    x_index=intersect(find(x_coor_node>=startlong_fine),find(x_coor_node<=endlong_fine));
    y_index=intersect(find(y_coor_node>=startcircum_fine),find(y_coor_node<=endcircum_fine));
    corrosion_region_index=intersect(x_index,y_index);
    x_coor_Cluster= linspace( startlong_fine,endlong_fine,corrosion_cluster_num_long);
    y_coor_Cluster = linspace(startcircum_fine,endcircum_fine,corrosion_cluster_num_cir);
    
    
    [X_coor_Cluster,Y_coor_Cluster]=meshgrid(x_coor_Cluster,y_coor_Cluster);
    vq = griddata(X_coor_Cluster,Y_coor_Cluster,Cluster,x_coor_node(corrosion_region_index),y_coor_node(corrosion_region_index),'v4');
    vq( vq<0)=0;
    long_index = intersect(find(x_coor_node>startlong_fine-(translation_element_layer+1)*longsurround),find(x_coor_node<endlong_fine+(translation_element_layer+1)*longsurround));
    cir_index  = intersect(find(y_coor_node>startcircum_fine-(translation_element_layer+1)*longsurround),find(y_coor_node<endcircum_fine+(translation_element_layer+1)*longsurround));
    node_selected_index_inside = intersect(long_index,cir_index);
    % node_num=length(X_coor_Cluster(:));
    %%%%%%1��ʾ�ⸯʴ��0��ʾ�ڸ�ʴ
    if corrosion_type==1
        z_coor_node(corrosion_region_index)=outer_radius-vq;
        % now, generate all the node and elements
        x_coor_all_node_inside=repmat(x_coor_node(node_selected_index_inside),5,1);
        y_coor_all_node_inside=repmat(y_coor_node(node_selected_index_inside),5,1);
        z_coor_all_node_inside=[z_coor_node(node_selected_index_inside);3/4*z_coor_node(node_selected_index_inside)+1/4*internal_radius;2/4*z_coor_node(node_selected_index_inside)+2/4*internal_radius;1/4*z_coor_node(node_selected_index_inside)+3/4*internal_radius;0/4*z_coor_node(node_selected_index_inside)+4/4*internal_radius];
    else
        z_coor_node( node_selected_index_inside)=internal_radius;
        z_coor_node(corrosion_region_index)= internal_radius+vq;
        % now, generate all the node and elements
        x_coor_all_node_inside=repmat(x_coor_node(node_selected_index_inside),5,1);
        y_coor_all_node_inside=repmat(y_coor_node(node_selected_index_inside),5,1);
        z_coor_all_node_inside=[0*z_coor_node(node_selected_index_inside)+outer_radius;1/4*z_coor_node(node_selected_index_inside)+3/4*outer_radius;2/4*z_coor_node(node_selected_index_inside)+2/4*outer_radius;3/4*z_coor_node(node_selected_index_inside)+1/4*outer_radius; z_coor_node(node_selected_index_inside);];
    end
    node_coor_matrix_inside=[[node_selected_index_inside;node_selected_index_inside+num_node_one_layer;node_selected_index_inside+num_node_one_layer*2;node_selected_index_inside+num_node_one_layer*3;node_selected_index_inside+num_node_one_layer*4],x_coor_all_node_inside,y_coor_all_node_inside,z_coor_all_node_inside];
    pres_node_index_1=node_selected_index_inside+num_node_one_layer*4;
    
    
    
    cd('./burst_capacity_folder/');
    str = sprintf('element_file.txt');
    Extra_element_information=importdata(str);
    % cd(currentFolder);
    Lia=ismember(Extra_element_information,node_selected_index_inside);
    element_inside=find(sum(Lia,2)==4);
    num_extra_element=length(element_inside(:,1));
    Extra_element_information=[Extra_element_information(element_inside,:),Extra_element_information(element_inside,:)+num_node_one_layer
        Extra_element_information(element_inside,:)+num_node_one_layer,Extra_element_information(element_inside,:)+2*num_node_one_layer
        Extra_element_information(element_inside,:)+2*num_node_one_layer,Extra_element_information(element_inside,:)+3*num_node_one_layer
        Extra_element_information(element_inside,:)+3*num_node_one_layer,Extra_element_information(element_inside,:)+4*num_node_one_layer];
    Extra_element_first_10=repmat([1,1,1,1,0,0,0,0,8,0],num_extra_element*4,1);
    element_information_inside=[Extra_element_first_10,[1:num_extra_element*4]', Extra_element_information];
    
    
    % now, it is the outside area
    long_index = union(find(x_coor_node<=startlong_fine-(translation_element_layer+1)*longsurround),find(x_coor_node>=endlong_fine+(translation_element_layer+1)*longsurround));
    cir_index  = union(find(y_coor_node<=startcircum_fine-(translation_element_layer+1)*longsurround),find(y_coor_node>=endcircum_fine+(translation_element_layer+1)*longsurround));
    node_selected_index_outside = union(long_index,cir_index);
    x_coor_all_node_outside=repmat(x_coor_node(node_selected_index_outside),3,1);
    y_coor_all_node_outside=repmat(y_coor_node(node_selected_index_outside),3,1);
    z_coor_all_node_outside=[z_coor_node(node_selected_index_outside);2/4*z_coor_node(node_selected_index_outside)+2/4*internal_radius;0/4*z_coor_node(node_selected_index_outside)+4/4*internal_radius];
    node_coor_matrix_outside=[[node_selected_index_outside;node_selected_index_outside+num_node_one_layer;node_selected_index_outside+num_node_one_layer*2],x_coor_all_node_outside,y_coor_all_node_outside,z_coor_all_node_outside];
    pres_node_index_2=node_selected_index_outside+num_node_one_layer*2;
    
    
    str = sprintf('element_file.txt');
    Extra_element_information=importdata(str);
    cd(currentFolder);
    Lia=ismember(Extra_element_information,node_selected_index_outside);
    element_outside=find(sum(Lia,2)==4);
    
    num_extra_element1=length(element_outside(:,1));
    Extra_element_information=[Extra_element_information(element_outside,:),Extra_element_information(element_outside,:)+num_node_one_layer
        Extra_element_information(element_outside,:)+num_node_one_layer,Extra_element_information(element_outside,:)+2*num_node_one_layer];
    
    Extra_element_first_10=repmat([1,1,1,1,0,0,0,0,8,0],num_extra_element1*2,1);
    element_information_outside=[Extra_element_first_10,[(num_extra_element*4+1):(num_extra_element*4+num_extra_element1*2)]', Extra_element_information];
    
    
    % now, generate the transitional element
    outside_node_x_west=max(x_coor_node(x_coor_node<startlong_fine-(translation_element_layer+1)*longsurround));
    outside_node_x_east=min(x_coor_node(x_coor_node>endlong_fine+(translation_element_layer+1)*longsurround));
    outside_node_y_north=max(y_coor_node(y_coor_node<startcircum_fine-(translation_element_layer+1)*longsurround));
    outside_node_y_south=min(y_coor_node(y_coor_node>endcircum_fine+(translation_element_layer+1)*longsurround));
    
    total_node_matrix=[node_coor_matrix_inside;node_coor_matrix_outside];
    total_element_matrix=[element_information_inside;element_information_outside];
    
    [total_node_matrix,total_element_matrix,force_node_matrix_west]=edge_west(node_coor_matrix_inside,total_element_matrix,t,outside_node_x_west,total_node_matrix);
    [total_node_matrix,total_element_matrix,force_node_matrix_east]=edge_east(node_coor_matrix_inside,total_element_matrix,t,outside_node_x_east,total_node_matrix);
    [total_node_matrix,total_element_matrix,force_node_matrix_north]=edge_north(node_coor_matrix_inside,total_element_matrix,t,outside_node_y_north,total_node_matrix);
    [total_node_matrix,total_element_matrix,force_node_matrix_south]=edge_south(node_coor_matrix_inside,total_element_matrix,t,outside_node_y_south,total_node_matrix);
    [total_node_matrix,total_element_matrix,force_node_matrix_conrner]=conrner_elements(node_coor_matrix_inside,total_element_matrix,t,outside_node_x_east,outside_node_x_west,outside_node_y_north,outside_node_y_south,total_node_matrix);
    total_node_matrix1=total_node_matrix;
    
    
    %%%%%%%%%%%�������������Լ���߽�
    node_coor=total_node_matrix(:,1);
    border_index=intersect(find(total_node_matrix(:,2)>bend_start-straight_length-0.1),find(total_node_matrix(:,2)<bend_start-straight_length+0.1));
    border_node_left_index=node_coor(border_index);
    border_node_left_num=length(border_node_left_index);
    
    %%%%%%%%%%%%�������������Լ���߽�
    border_index=intersect(find(total_node_matrix(:,2)>bend_end+straight_length-0.1),find(total_node_matrix(:,2)<bend_end+straight_length+0.1));
    border_node_right_index=node_coor(border_index);
    border_node_right_num=length(border_node_right_index);
    
    %����ڵ���Լ���ڵ���
    cd('./burst_capacity_folder/');
    str = sprintf('border_node_left%d.txt',iii);
    fid=fopen(str,'wt');
    fprintf(fid,'%d\n',border_node_left_index);
    fclose(fid);
    %����ڵ���Լ���ڵ���
    str = sprintf('border_node_right%d.txt',iii);
    fid=fopen(str,'wt');
    fprintf(fid,'%d\n',border_node_right_index);
    fclose(fid);
    
    %�����ڲ����ؽڵ�
    pres_node_index=[pres_node_index_1',pres_node_index_2',force_node_matrix_west,force_node_matrix_east,force_node_matrix_north,force_node_matrix_south,force_node_matrix_conrner]';
    internal_node_index_num=length(pres_node_index);
    %�����ѹ�ڵ���
    str = sprintf('pres_node%d.txt',iii);
    fid=fopen(str,'wt');
    fprintf(fid,'%9.0f\n',pres_node_index');
    fclose(fid);
    
    %�ҵ���ʴ���ĵ�
    long_index1 = intersect(find(total_node_matrix(:,2)>=(endlong_fine+startlong_fine)/2-element_size),find(total_node_matrix(:,2)<=(endlong_fine+startlong_fine)/2+element_size));
    cir_index1  = intersect(find(total_node_matrix(:,3)>=(endcircum_fine+startcircum_fine)/2-element_size),find(total_node_matrix(:,3)<=(endcircum_fine+startcircum_fine)/2+element_size));
    node_selected_index_mid = intersect(long_index1,cir_index1);
    %     total_node_matrix_id= total_node_matrix(:,1);
    %     mid_index =  total_node_matrix_id(node_selected_index_mid);
    mid_index=node_selected_index_mid(1);
    
    %��Ƭ�ӽ�
    if cir_center1>0 && cir_center1<=pi*D/2
        view_y=1;
    else
        view_y=-1;
    end
    
    if cir_center1<=pi*D/2
        view_1=-1;
    else
        view_1=1;
    end
    
    orientation_degree1=-pi/2;%�Ƚ���ʴ��������y�����Ϸ�
    
    total_node_matrix(:,2)=total_node_matrix(:,4).*cos(total_node_matrix(:,3)/D*2+orientation_degree1-cir_center);
    total_node_matrix(:,3)=total_node_matrix(:,4).*sin(total_node_matrix(:,3)/D*2+orientation_degree1-cir_center);
    total_node_matrix(:,4)=total_node_matrix1(:,2);
    
    %%%%%%%%%%%%%��������
    transition_0=total_node_matrix(:,1);%�ڵ����
    transition_z=total_node_matrix(:,4);%�ڵ�z����
    transition_x=total_node_matrix(:,2);
    transition_y=total_node_matrix(:,3);
    transition_x_1=total_node_matrix(:,2);
    transition_z_1=total_node_matrix(:,4);
    
    index_bend_z=intersect(find(transition_z_1>=bend_start-1),find(transition_z_1<=bend_end+1));%�������ֵĽڵ�����
    index_stright_z=find(transition_z_1>bend_end);%������ֱ�ܵĽڵ�����
    
    degree_matrix=(transition_z(index_bend_z)-bend_start)/(bend_r);%�����ǶȾ���
    if bend_r==0
        degree_matrix=transition_z(index_bend_z)*0;
    end
    max_degree=max(degree_matrix);%��������Ƕ�
    max_degree1=max(degree_matrix)/pi*180;%��������Ƕ�
    %�������ֱ任
    transition_x(index_bend_z)=(bend_r)-(bend_r-transition_x_1(index_bend_z)).*cos(degree_matrix);
    transition_z(index_bend_z)=bend_start+(bend_r-transition_x_1(index_bend_z)).*sin(degree_matrix);
    %������ֱ�ܲ��ֱ任
    transition_x(index_stright_z)=(bend_r)-(bend_r-transition_x_1(index_stright_z)).*cos(max_degree)+(transition_z_1(index_stright_z)-bend_end).*sin(max_degree);
    transition_z(index_stright_z)=bend_start+(bend_r-transition_x_1(index_stright_z)).*sin(max_degree)+(transition_z_1(index_stright_z)-bend_end).*cos(max_degree);
    %�������Ͻڵ����
    total_node_matrix=[transition_0,transition_x,transition_y,transition_z];
    
    
    mid=total_node_matrix(mid_index,:);
    if defect_depth~=0
        degree_photo=[mid(2),mid(3),mid(4)];
    else
        degree_photo=[1,0.5,-1];
    end
    
    %%�߽�Լ����
    boundary_left_x=0;
    boundary_left_y=0;
    boundary_left_z=bend_start-straight_length;
    
    boundary_right_x=bend_r*(1-cos(max_degree))+straight_length*sin(max_degree);
    boundary_right_y=0;
    boundary_right_z=bend_r*sin(max_degree)+straight_length*cos(max_degree);
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Node information files
    
    str = sprintf('node_element_information_cluster%d.txt',iii);
    fid=fopen(str,'wt');
    fprintf(fid,'/batch');
    fprintf(fid,'\n');
    fprintf(fid,'/wb,file,start');
    fprintf(fid,'\n');
    fprintf(fid,'/prep7');
    fprintf(fid,'\n');
    fprintf(fid,'SHPP,OFF,,NOWARN');
    fprintf(fid,'\n');
    fprintf(fid,'/nolist');
    fprintf(fid,'\n');
    fprintf(fid,'/com,*********** Nodes for the whole assembly ***********');
    fprintf(fid,'\n');
    fprintf(fid,'csys,0');
    fprintf(fid,'\n');
    fprintf(fid,'nblock,3');
    fprintf(fid,'\n');
    fprintf(fid,'(1i16,3e16.6e2)');
    fprintf(fid,'\n');
    fprintf(fid,'%16.0f%16E%16E%16E\n',total_node_matrix');
    fprintf(fid,'/wb,elem,start');
    fprintf(fid,'\n');
    fprintf(fid,'/com,*********** Elements for Body 1 "Solid" ***********');
    fprintf(fid,'\n');
    fprintf(fid,'et,1,185');
    fprintf(fid,'\n');
    fprintf(fid,'eblock,19,solid,,41503');
    fprintf(fid,'\n');
    fprintf(fid,'(19i16)');
    fprintf(fid,'\n');
    fprintf(fid,'%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f\n', total_element_matrix');
    fclose(fid);
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % APDL model generation file
    fid = fopen('cluster16.txt');
    APDL_data= textscan(fid,'%s','delimiter','\n');
    
    APDL_data{1,1}(1)={['/input,node_element_information_cluster',num2str(iii),',txt']};
    APDL_data{1,1}(14)={['pipediameter=',num2str(D)]};
    APDL_data{1,1}(15)={['wallthickness=',num2str(t)]};
    APDL_data{1,1}(16)={['Youngs=',num2str(E_value)]};
    APDL_data{1,1}(17)={['border_left=',num2str(bend_start-straight_length)]};
    APDL_data{1,1}(18)={['border_node_left_num=',num2str(border_node_left_num)]};
    APDL_data{1,1}(19)={['border_node_right_num=',num2str(border_node_right_num)]};
    APDL_data{1,1}(20)={['internal_surface_node_num=',num2str(internal_node_index_num)]};
    APDL_data{1,1}(25)={['*vread,border_node_left(1),border_node_left',num2str(iii),',txt,,ijk,border_node_left_num,1']};
    APDL_data{1,1}(28)={['*vread,border_node_right(1),border_node_right',num2str(iii),',txt,,ijk,border_node_right_num,1']};
    APDL_data{1,1}(31)={['*vread,internal_surface_node(1),pres_node',num2str(iii),',txt,,ijk,internal_surface_node_num,1']};
    
    if isnumeric(Axial_Force_Pre) | ~isnan(Axial_Force_Pre)
        if Axial_Force_Pre~=0 & ~isnan(Axial_Force_Pre)
            APDL_data{1,1}(8)={['flag_force_pre=1']};
            APDL_data{1,1}(140)={['f,new_nodemax,fx,',num2str(Axial_Force_Pre)]};
        end
    end
    
    if isnumeric(axial_force) | ~isnan(axial_force)
        if axial_force~=0 & ~isnan(axial_force)
            APDL_data{1,1}(9)={['flag_force=1']};
            APDL_data{1,1}(150)={['f,new_nodemax,fx,',num2str(axial_force)]};
        end
    end
    
    
    for i=45:64
        APDL_data{1,1}(i)=cellstr(M{i-44});
    end
    
    APDL_data{1,1}(80)={['/view,1,0,',num2str(view_y),',0']};
    APDL_data{1,1}(82)={['/FOC,1,',num2str(boundary_right_x/3),',',num2str(0),',',num2str(boundary_left_z/3)]};
    APDL_data{1,1}(88)={['/view,1,',num2str(degree_photo(1)),',',num2str(degree_photo(2)),',',num2str(degree_photo(3)*view_1)]};
    APDL_data{1,1}(90)={['/FOC,1,',num2str(mid(1,2)),',',num2str(mid(1,3)),',',num2str(mid(1,4))]};
    APDL_data{1,1}(91)={['/DIST,1,',num2str(cluster_length*2)]};  
    APDL_data{1,1}(106)={['n,boundary_left,',num2str(boundary_left_x),',',num2str(boundary_left_y),',',num2str(boundary_left_z),]};
    APDL_data{1,1}(107)={['n,boundary_right,',num2str(boundary_right_x),',',num2str(boundary_right_y),',',num2str(boundary_right_z)]};
    APDL_data{1,1}(157)={['sf,all,pres,',num2str(pressure_applied)]};
    APDL_data{1,1}(161)={['nsubst,',num2str(Substep_Number)]};
    APDL_data{1,1}(173)={['wpoffs,',num2str(boundary_right_x+straight_length*sin(max_degree)),',',num2str(boundary_right_y)',',',num2str(boundary_right_z-straight_length*cos(max_degree))]};
    APDL_data{1,1}(174)={['wprota,,,',num2str(max_degree1)]};
    APDL_data{1,1}(188)={['/input,post_process_clsuter',num2str(iii),',txt']};
    fclose(fid);
    
    str = sprintf('APDL_file_cluster%d.txt',iii);
    fid=fopen(str,'wt');
    [A,B]=size(APDL_data{1,1});
    for i=1:A
        every_row=char(APDL_data{1,1}(i));
        fprintf(fid,'%s\n',every_row);
    end
    fclose(fid);
    clear total_node_information;
    clear element_information;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % APDL post process file
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    str = sprintf('post_process_clsuter%d.txt',iii);
    fid=fopen(str,'wt');
    fprintf(fid,'*cfopen,stress_cluster%d,txt',iii);
    fprintf(fid,'\n');
    fprintf(fid,'*vwrite,nodemaxs(1,1),nodemaxs(1,2)');
    fprintf(fid,'\n');
    fprintf(fid,'(f20.5,f20.5)');
    fprintf(fid,'\n');
    fprintf(fid,'*cfclos');
    fclose(fid);
 
    
    tic
    jobname=['pipe_burst_test_cluster_',num2str(cluster_ID_unique(iii))];
    skriptFileName=['APDL_file_cluster',num2str(iii),'.txt'];
    outputFilename=['cluster',num2str(cluster_ID_unique(iii)),'_output.txt'];
    sys_char=strcat('SET KMP_STACKSIZE=4096k &',32,ansys_path,32,...
        '-b -p ansys -i',32,skriptFileName,32,...
        '-j',32,jobname,32,...
        '-o',32,outputFilename);
    ans1=system(sys_char);
    toc

 
    internal_stress_curve=importdata(strcat(['stress_cluster',num2str(iii),'.txt']));
    internal_pressure=internal_stress_curve(:,1)*4*UTS_value*t/D;
    Mises_stress=internal_stress_curve(:,2);
    true_UTS=true_ultimate;
    judge_vector=Mises_stress-true_UTS;
    new_vector=judge_vector(1:end-1).*(judge_vector(2:end));
    possible_points=min(find(new_vector<=0));
    if isempty(possible_points)
        burst_pressure{iii,2}=NaN;
    else
        burst_pressure{iii,2}=(true_UTS-Mises_stress(possible_points))*(internal_pressure(possible_points+1)-internal_pressure(possible_points))/(Mises_stress(possible_points+1)-Mises_stress(possible_points))+internal_pressure(possible_points);
    end
    burst_pressure{iii,1}=iii;
    
  
    every_row=[];
    
    if length(burst_pressure{iii,2})>1
        continue;
    end
    
    time_step=burst_pressure{iii,2}/pressure_applied;                              % time step
    
    
    internal_stress_curve=importdata(strcat(['stress_cluster',num2str(iii),'.txt']));
    FEA_time_step=internal_stress_curve(:,1);
    sub_step_num = find(time_step-FEA_time_step<0,1)-1;                            % this is the sub step number during burst
    
    fid = fopen('post_process_strain_stress_plot.txt');
    post_process_strain_stress= textscan(fid,'%s','delimiter','\n');
    post_process_strain_stress{1,1}(1)={['RESUME,pipe_burst_test_cluster_',num2str(ID_no),',db,,0,0']};
    post_process_strain_stress{1,1}(16)={['SET,,,,,,,',num2str(sub_step_num)]};
    post_process_strain_stress{1,1}(22)={['SET,,,,,,,',num2str(sub_step_num)]};
    
    str = sprintf('post_process_strain_stress_plot%d.txt',iii);
    fid=fopen(str,'wt');
    [A,B]=size(post_process_strain_stress{1,1});
    for j=1:A
        every_row=char(post_process_strain_stress{1,1}(j));
        fprintf(fid,'%s\n',every_row);
    end
    every_row=[];
    fclose(fid);
    
    jobname=['pipe_burst_test_cluster_',num2str(ID_no)];
    skriptFileName=['post_process_strain_stress_plot',num2str(iii),'.txt'];
    outputFilename=['plot',num2str(iii),'_output.txt'];
    sys_char=strcat('SET KMP_STACKSIZE=4096k &',32,ansys_path,32,...
        '-b -p ansys -i',32,skriptFileName,32,...
        '-j',32,jobname,32,...
        '-o',32,outputFilename),
    ans1=system(sys_char);
    
    cd (currentFolder);
    work_folder='./burst_capacity_folder/';                  %ԭʼͼƬ·��
    savepath ='./Finite_element_picture/';                   %���洦�����ͼƬ·��
    file_list=dir(fullfile(work_folder,'*.jpg'));            %��ȡ����·��
    for i=1:length(file_list)
        im =imread([work_folder,file_list(i).name]);             %����·����ÿһ��ͼƬ
        imwrite(im,[savepath,file_list(i).name],'jpg');      %���µ�ͼƬд�뵽ָ���ļ���
    end
    
end

cd (currentFolder);
result=burst_pressure;

