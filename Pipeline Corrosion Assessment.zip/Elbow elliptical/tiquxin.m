function [xin]=tiquxin(T,i)

 xin = zeros(11,6);
      
       % Deterministic = 0; Uniform = 1; Normal = 2; Lognormal = 3; Gamma = 4; Weibull = 5; Gumbel = 6; Beta = 7; Exponential = 8; 
       %SMYS, wt, D, d0, gd, l0, gl, er, pb, Ttrans, SMTS
   xin(:,1)=[str2num(cell2mat(T{4,3})) str2num(cell2mat(T{4,5})) str2num(cell2mat(T{4,2}))...
        str2num(cell2mat(T{4,8})) str2num(cell2mat(T{4,10})) str2num(cell2mat(T{4,9}))...
        str2num(cell2mat(T{4,11})) str2num(cell2mat(T{4,12}))  str2num(cell2mat(T{4,6}))...
        str2num(cell2mat(T{4,7})) str2num(cell2mat(T{4,4}))];
 
    xin(find(xin(:,1)==7),5)=0;    xin(find(xin(:,1)==7),6)=1;

     %SMYS-3
     xin(1,2)=str2num(cell2mat(T{5,3}))*str2num(cell2mat(T{i+11,3}));
     if isempty(str2num(cell2mat(T{6,3})))
     xin(1,3)=str2num(cell2mat(T{7,3}));
     else    
     xin(1,3)=xin(1,2)*str2num(cell2mat(T{6,3}))/100;
     end
     %wt-5
     xin(2,2)=str2num(cell2mat(T{5,5}))*str2num(cell2mat(T{i+11,5}));
     if isempty(str2num(cell2mat(T{6,5})))
     xin(2,3)=str2num(cell2mat(T{7,5}));
     else    
     xin(2,3)=xin(2,2)*str2num(cell2mat(T{6,5}))/100;
     end
     %D-2
     xin(3,2)=str2num(cell2mat(T{5,2}))*str2num(cell2mat(T{i+11,2}));
     if isempty(str2num(cell2mat(T{6,2})))
     xin(3,3)=str2num(cell2mat(T{7,2}));
     else    
     xin(3,3)=xin(3,2)*str2num(cell2mat(T{6,2}))/100;
     end
      %d0-2
     xin(4,2)=str2num(cell2mat(T{i+11,5}))*str2num(cell2mat(T{i+11,7}))*str2num(cell2mat(T{5,8}))/100;
     if isempty(str2num(cell2mat(T{6,8})))
     xin(4,3)=str2num(cell2mat(T{i+11,5}))*str2num(cell2mat(T{7,8}))/100;
     else    
     xin(4,3)=str2num(cell2mat(T{i+11,5}))*str2num(cell2mat(T{6,8}))/100*xin(4,2);
     end
     %dg-10
     xin(5,2)=str2num(cell2mat(T{5,10}))*str2num(cell2mat(T{i+11,9}));
     if isempty(str2num(cell2mat(T{6,10})))
     xin(5,3)=str2num(cell2mat(T{7,10}));
     else    
     xin(5,3)=xin(5,2)*str2num(cell2mat(T{6,10}))/100;
     end
     %l0-9
     xin(6,2)=str2num(cell2mat(T{5,9}))*str2num(cell2mat(T{i+11,8}));
     if isempty(str2num(cell2mat(T{6,9})))
     xin(6,3)=str2num(cell2mat(T{7,9}));
     else    
     xin(6,3)=xin(6,2)*str2num(cell2mat(T{6,9}))/100;
     end
     %gl-11
     xin(7,2)=str2num(cell2mat(T{5,11}))*str2num(cell2mat(T{i+11,10}));
     if isempty(str2num(cell2mat(T{6,11})))
     xin(7,3)=str2num(cell2mat(T{7,11}));
     else    
     xin(7,3)=xin(7,2)*str2num(cell2mat(T{6,11}))/100;
     end
     %error-12
     xin(8,2)=str2num(cell2mat(T{5,12}));
     if isempty(str2num(cell2mat(T{6,12})))
     xin(8,3)=str2num(cell2mat(T{7,12}));
     else    
     xin(8,3)=xin(8,2)*str2num(cell2mat(T{6,12}))/100;
     end
     %Pb-6
     xin(9,2)=str2num(cell2mat(T{5,6}))*str2num(cell2mat(T{i+11,6}));
     if isempty(str2num(cell2mat(T{6,6})))
     xin(9,3)=str2num(cell2mat(T{7,6}));
     else    
     xin(9,3)=xin(9,2)*str2num(cell2mat(T{6,6}))/100;
     end
     %Ttrans-7
     xin(10,2)=str2num(cell2mat(T{5,7}));
     if isempty(str2num(cell2mat(T{6,7})))
     xin(10,3)=str2num(cell2mat(T{7,7}));
     else    
     xin(10,3)=xin(10,2)*str2num(cell2mat(T{6,7}))/100;
     end
     %SMTS-4
     xin(11,2)=str2num(cell2mat(T{5,4}))*str2num(cell2mat(T{i+11,4}));
     if isempty(str2num(cell2mat(T{6,4})))
     xin(11,3)=str2num(cell2mat(T{7,4}));
     else    
     xin(11,3)=xin(11,2)*str2num(cell2mat(T{6,4}))/100;
     end
     
     xin(find(xin(:,1)==0),3)=0;
     xin(find(xin(:,1)==0),1)=2;
     
     xin(find(xin(:,2)==0),2)=1/100000000000;
     xin(find(xin(:,3)==0),3)=1/1000000000;
     xin(find(xin(:,3)==0),1)=2;
     


