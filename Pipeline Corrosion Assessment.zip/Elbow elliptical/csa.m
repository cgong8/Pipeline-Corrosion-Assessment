function [ra]=csa(Cluster5,SMYS,SMTS,AOD,pipethickness,resolution_length)
    
    river_bottom=max(Cluster5);
    river_bottom_length=length(river_bottom);  
    profile_selected=river_bottom(1:end);
    
    corroded_area=(sum(profile_selected)-(profile_selected(1)+profile_selected(end))/2)*resolution_length;
    profile_selected_length=resolution_length*(length(profile_selected)-1);
    dav=corroded_area/profile_selected_length;%mean(river_bottom);
    
    det_para=0;x(6)=profile_selected_length;x(7)=0;x(3)=AOD;x(2)=pipethickness;
    M=Folias(x(6),x(7),x(3),x(2),det_para);%l,gl,D,t
    wt=x(2);D=x(3);
    
              if SMYS > 241
              sigmau=0.9*SMTS;
              else
              sigmau=1.15*SMYS;    
              end 
              ra=2*(sigmau)*wt/D*(1-dav/wt)/(1-dav/wt/M);