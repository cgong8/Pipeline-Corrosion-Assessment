function [result]=APDL_revise(ansys_path,E_value,F_input,F_input_depth,start_m)


end_m=start_m;
currentFolder = pwd;
ans = dos('md burst_capacity_folder');


for iii=start_m:end_m
    cd(currentFolder);
    corrosion_type=F_input(1,4);
    Axial_Force=F_input(1,5);
    D=F_input(1,5);
    t=F_input(1,6);
    circumferential_position_hh_mm=F_input(1,7);
    straight_length=F_input(1,8);
    bend_r=F_input(1,9);
    bend_angel=F_input(1,10);
    bend_location_angel=F_input(1,11);
    E_value=F_input(1,12);
    YS_value=F_input(1,13);
    UTS_value=F_input(1,14);
    Axial_Force_Pre=F_input(1,15)*1000;
    Axial_Force=F_input(1,16)*1000;
    
    cluster_length=F_input(1,20);
    cluster_width=F_input(1,21);
    reso_y=F_input(1,30);
    Substep_Number=F_input(1,31);
    
    bend_start=0;
    bend_end=bend_r*bend_angel/180*pi;
    
    
    
    
    
    element_size_x=F_input_depth(2,4)-F_input_depth(2,3);
    element_size_y=F_input_depth(4,2)-F_input_depth(3,2);
    element_minsize=min(element_size_x,element_size_y);
    dist_length=max(cluster_length,cluster_width);
    
    if isnumeric(reso_y) | ~isnan(reso_y)
        if reso_y~=0 & ~isnan(reso_y)
            element_size=reso_y;
        end
    else
        element_size=element_minsize;
    end
    
    
    
    %%%%%ȷ�����ɴ���
    element_maxnum=70;
    element_minnum=30;
    translation_element_layer=1;
    element_outermost_num=pi*D/(element_size*3^translation_element_layer);
    while (element_outermost_num>element_maxnum)
        translation_element_layer=translation_element_layer+1;
        element_outermost_num=pi*D/(element_size*3^translation_element_layer);
        if element_outermost_num<element_minnum
            translation_element_layer=translation_element_layer-1;
            element_outermost_num=pi*D/(element_size*3^translation_element_layer);
            break;
        end
    end
    if element_outermost_num<element_minnum
        translation_element_layer=1;
        element_size=pi*D/(element_minnum*3^translation_element_layer);
    end
    %%%%���������ߴ�
    % element size in the corrosion free area (mm)
    circumsurround=element_size*3^translation_element_layer;
    longsurround=element_size*3^translation_element_layer;
    
    
    %%%Ĭ��Ϊ�ⸯʴ
    if isnan(corrosion_type)
        corrosion_type=1;
    end
    
    %%%���õ���ģ��Ĭ��ֵ
    if isnan(E_value)
        E_value=200000;
    end
    %%%���û������Ӳ���
    if isnan(Substep_Number)
        Substep_Number=200;
    end
    
    %�ж��Ƿ���ѹ����Ӧ������
    if isnan(Axial_Force_Pre)
        Axial_Force_Pre=0;
    else
        Axial_Force_Pre=Axial_Force_Pre;
    end
    %�ж��Ƿ�����������
    if isnan(Axial_Force)
        Axial_Force=0;
    else
        Axial_Force=Axial_Force;
    end
    
    %%%%%%%%%%������������жϳ���
    if bend_r==0
        longitudinal_position = longitudinal_center(index_no)*1000-min(longitudinal_center(index_no)*1000);
    else
        longitudinal_position = bend_r*bend_location_angel/180*pi;
    end
    
    
    
    Cluster_corrosion_profile=F_input_depth(3:end,3:end);
    
    
    if max(Cluster_corrosion_profile(:))>100
        disp ("Error! maximum corrosion depth should not be greater than 100%t")
        return;
    end
    
    % This part is the FEA generation part
    % firstly, I want to caculate the stress-strain curve
    %E_value=2e5;                                                      % must be positive (MPa)
    
    
    if UTS_value<=YS_value
        disp ("Error! UTS must be greater than yield strength")
        return;
    end
    strain_exponential=0.224*(UTS_value/YS_value-1)^0.604;
    true_ultimate=UTS_value*exp(strain_exponential);
    K=true_ultimate/(strain_exponential^strain_exponential);
    plastic_stress_ansys=linspace(YS_value,true_ultimate+100,20);
    plastic_strain_ansys=(plastic_stress_ansys/K).^(1/strain_exponential);
    plastic_strain_ansys(1)=YS_value/E_value;
    pressure_applied=4*UTS_value*t/D;
    
    
    outputdata=cat(2,'tbpt,','defi');
    B = repmat(outputdata,[20,1]);
    for ii=1:20
        M{ii}=[B(ii,:),',',num2str(plastic_strain_ansys(ii)),',',num2str(plastic_stress_ansys(ii))];
    end
    
    Cluster1=Cluster_corrosion_profile;
    Cluster=Cluster1/100*t;
    [M_new,N_new]=size(Cluster);
    
    % ����ͻ���λ��
    longitudinal_position=bend_r*bend_location_angel/180*pi;
    circumferential_position=circumferential_position_hh_mm*2*pi*D;  % in the unit of (mm)
 
    startlong_fine=longitudinal_position-cluster_length/2;
    endlong_fine=startlong_fine+cluster_length;
    cir_move   =  circumferential_position-pi*D/2;
    cir_center=circumferential_position/D*2;
    startcircum_fine=circumferential_position-cir_move- cluster_width/2;
    endcircum_fine=startcircum_fine+cluster_width;
    
    %%%%%��ʴ�ر�Ե����ʴ���߽�ľ���
    border_length=0;
    %%%%%��ʴ��������չ��ı߽�
    startlong_fine  = startlong_fine -  border_length;
    endlong_fine    = endlong_fine   +  border_length;
    startcircum_fine= startcircum_fine  -  border_length;
    endcircum_fine  = endcircum_fine    +  border_length;
    
    
    
    
    % call ANSYS to generate the mesh on a plane
    fid = fopen('plane_remesh.txt');
    plane_mesh_data= textscan(fid,'%s','delimiter','\n');
    plane_mesh_data{1,1}(7)={['D=',num2str(D)]};
    plane_mesh_data{1,1}(8)={['startlong_fine=',num2str(startlong_fine)]};
    plane_mesh_data{1,1}(9)={['endlong_fine=',num2str(endlong_fine)]};
    plane_mesh_data{1,1}(10)={['startcircum_fine=',num2str(startcircum_fine)]};
    plane_mesh_data{1,1}(11)={['endcircum_fine=',num2str(endcircum_fine)]};
    plane_mesh_data{1,1}(12)={['circum_increment=',num2str(element_size)]};
    plane_mesh_data{1,1}(13)={['long_increment=',num2str(element_size)]};
    plane_mesh_data{1,1}(14)={['translation_element_layer=',num2str(translation_element_layer)]};
    plane_mesh_data{1,1}(15)={['bend_start=',num2str(bend_start)]};
    plane_mesh_data{1,1}(16)={['bend_end=',num2str(bend_end)]};
    plane_mesh_data{1,1}(17)={['straight_length=',num2str(straight_length)]};
    fclose(fid);
    
    corrosion_cluster_width_limit = D * pi * 2 / 3;
    if (M_new-1)*element_size_y>corrosion_cluster_width_limit
        disp ("Corrosion feature is too wide, simulation teminates")
        continue;
    end
    
    
    str = sprintf('plane_element%d.txt',iii);
    fid=fopen(str,'wt');
    [A,B]=size(plane_mesh_data{1,1});
    for i=1:A
        every_row=char(plane_mesh_data{1,1}(i));
        fprintf(fid,'%s\n',every_row);
    end
    every_row=[];
    fclose(fid);
    DST_PATH_t = './burst_capacity_folder/';
    movefile(str,DST_PATH_t);
    copyfile('plane_remesh.txt',DST_PATH_t);
    copyfile('node_element_FEA_generation.txt',DST_PATH_t);
    copyfile('cluster16.txt',DST_PATH_t);
    copyfile('post_process_strain_stress_plot.txt',DST_PATH_t);
    copyfile('corner_element.txt',DST_PATH_t);
    copyfile('corner_nodes.txt',DST_PATH_t);
    copyfile('post_process_strain_stress_plot.txt',DST_PATH_t);
    cd (DST_PATH_t);
    
    % call ANSYS to generate the model
    
    jobname=['model_generation_cluster',num2str(iii)];
    skriptFileName=['plane_element',num2str(iii),'.txt'];
    outputFilename=['cluster_output.txt'];
    sys_char=strcat('SET KMP_STACKSIZE=4096k &',32,ansys_path,32,...
        '-b -p ansys -i',32,skriptFileName,32,'-j',32,jobname,32,'-o',32,outputFilename),
    ans1=system(sys_char);
    
    str = sprintf('node_file.txt');
    Extra_node_information=importdata(str);
    cd(currentFolder);
    num_node_one_layer=length(Extra_node_information);
    internal_radius=D/2-t;
    outer_radius=internal_radius+t;
    radius_1st_layer=internal_radius+(outer_radius-internal_radius)/4*3;
    radius_2nd_layer=internal_radius+(outer_radius-internal_radius)/2;
    radius_3rd_layer=internal_radius+(outer_radius-internal_radius)/4;
    
    x_coor_node=Extra_node_information(:,1);
    y_coor_node=Extra_node_information(:,2);
    z_coor_node=outer_radius*ones(num_node_one_layer,1);
    
    
    % inside the corrosion cluster area
    x_index=intersect(find(x_coor_node>=startlong_fine),find(x_coor_node<= endlong_fine));
    y_index=intersect(find(y_coor_node>=startcircum_fine),find(y_coor_node<=endcircum_fine));
    corrosion_region_index=intersect(x_index,y_index);
    [length_num_Cluster_x,length_num_Cluster_y]=size(Cluster);
    x_coor_Cluster=linspace(startlong_fine,endlong_fine,length_num_Cluster_y);
    y_coor_Cluster=linspace(startcircum_fine,endcircum_fine,length_num_Cluster_x);
    [X_coor_Cluster,Y_coor_Cluster]=meshgrid(x_coor_Cluster,y_coor_Cluster);
    vq = griddata(X_coor_Cluster,Y_coor_Cluster,Cluster,x_coor_node(corrosion_region_index),y_coor_node(corrosion_region_index),'nearest');
    z_coor_node(corrosion_region_index)=outer_radius-vq;
    long_index = intersect(find(x_coor_node>startlong_fine-(translation_element_layer+1)*longsurround),find(x_coor_node<endlong_fine+(translation_element_layer+1)*longsurround));
    cir_index  = intersect(find(y_coor_node>startcircum_fine-(translation_element_layer+1)*longsurround),find(y_coor_node<endcircum_fine+(translation_element_layer+1)*longsurround));
    node_selected_index_inside = intersect(long_index,cir_index);
    node_num=length(X_coor_Cluster(:));
    
    %%%%%%1��ʾ�ⸯʴ��0��ʾ�ڸ�ʴ
    if corrosion_type==1
        z_coor_node(corrosion_region_index)=outer_radius-vq;
        % now, generate all the node and elements
        x_coor_all_node_inside=repmat(x_coor_node(node_selected_index_inside),5,1);
        y_coor_all_node_inside=repmat(y_coor_node(node_selected_index_inside),5,1);
        z_coor_all_node_inside=[z_coor_node(node_selected_index_inside);3/4*z_coor_node(node_selected_index_inside)+1/4*internal_radius;2/4*z_coor_node(node_selected_index_inside)+2/4*internal_radius;1/4*z_coor_node(node_selected_index_inside)+3/4*internal_radius;0/4*z_coor_node(node_selected_index_inside)+4/4*internal_radius];
    else
        z_coor_node( node_selected_index_inside)=internal_radius;
        z_coor_node(corrosion_region_index)= internal_radius+vq;
        % now, generate all the node and elements
        x_coor_all_node_inside=repmat(x_coor_node(node_selected_index_inside),5,1);
        y_coor_all_node_inside=repmat(y_coor_node(node_selected_index_inside),5,1);
        z_coor_all_node_inside=[0*z_coor_node(node_selected_index_inside)+outer_radius;1/4*z_coor_node(node_selected_index_inside)+3/4*outer_radius;2/4*z_coor_node(node_selected_index_inside)+2/4*outer_radius;3/4*z_coor_node(node_selected_index_inside)+1/4*outer_radius; z_coor_node(node_selected_index_inside);];
    end
    node_coor_matrix_inside=[[node_selected_index_inside;node_selected_index_inside+num_node_one_layer;node_selected_index_inside+num_node_one_layer*2;node_selected_index_inside+num_node_one_layer*3;node_selected_index_inside+num_node_one_layer*4],x_coor_all_node_inside,y_coor_all_node_inside,z_coor_all_node_inside];
    pres_node_index_1=node_selected_index_inside+num_node_one_layer*4;
    
    
    
    cd('./burst_capacity_folder/');
    str = sprintf('element_file.txt');
    Extra_element_information=importdata(str);
    cd(currentFolder);
    Lia=ismember(Extra_element_information,node_selected_index_inside);
    element_inside=find(sum(Lia,2)==4);
    num_extra_element=length(element_inside(:,1));
    Extra_element_information=[Extra_element_information(element_inside,:),Extra_element_information(element_inside,:)+num_node_one_layer
        Extra_element_information(element_inside,:)+num_node_one_layer,Extra_element_information(element_inside,:)+2*num_node_one_layer
        Extra_element_information(element_inside,:)+2*num_node_one_layer,Extra_element_information(element_inside,:)+3*num_node_one_layer
        Extra_element_information(element_inside,:)+3*num_node_one_layer,Extra_element_information(element_inside,:)+4*num_node_one_layer];
    Extra_element_first_10=repmat([1,1,1,1,0,0,0,0,8,0],num_extra_element*4,1);
    element_information_inside=[Extra_element_first_10,[1:num_extra_element*4]', Extra_element_information];
    
    % now, it is the outside area
    long_index = union(find(x_coor_node<=startlong_fine-(translation_element_layer+1)*longsurround),find(x_coor_node>=endlong_fine+(translation_element_layer+1)*longsurround));
    cir_index  = union(find(y_coor_node<=startcircum_fine-(translation_element_layer+1)*longsurround),find(y_coor_node>=endcircum_fine+(translation_element_layer+1)*longsurround));
    node_selected_index_outside = union(long_index,cir_index);
    x_coor_all_node_outside=repmat(x_coor_node(node_selected_index_outside),3,1);
    y_coor_all_node_outside=repmat(y_coor_node(node_selected_index_outside),3,1);
    z_coor_all_node_outside=[z_coor_node(node_selected_index_outside);2/4*z_coor_node(node_selected_index_outside)+2/4*internal_radius;0/4*z_coor_node(node_selected_index_outside)+4/4*internal_radius];
    node_coor_matrix_outside=[[node_selected_index_outside;node_selected_index_outside+num_node_one_layer;node_selected_index_outside+num_node_one_layer*2],x_coor_all_node_outside,y_coor_all_node_outside,z_coor_all_node_outside];
    pres_node_index_2=node_selected_index_outside+num_node_one_layer*2;
    
    cd('./burst_capacity_folder/');
    str = sprintf('element_file.txt');
    Extra_element_information=importdata(str);
    cd(currentFolder);
    Lia=ismember(Extra_element_information,node_selected_index_outside);
    element_outside=find(sum(Lia,2)==4);
    
    num_extra_element1=length(element_outside(:,1));
    Extra_element_information=[Extra_element_information(element_outside,:),Extra_element_information(element_outside,:)+num_node_one_layer
        Extra_element_information(element_outside,:)+num_node_one_layer,Extra_element_information(element_outside,:)+2*num_node_one_layer];
    
    Extra_element_first_10=repmat([1,1,1,1,0,0,0,0,8,0],num_extra_element1*2,1);
    element_information_outside=[Extra_element_first_10,[(num_extra_element*4+1):(num_extra_element*4+num_extra_element1*2)]', Extra_element_information];
    
    
    % now, generate the transitional FEA model
    
    outside_node_x_west=max(x_coor_node(x_coor_node<startlong_fine-(translation_element_layer+1)*longsurround));
    outside_node_x_east=min(x_coor_node(x_coor_node>endlong_fine+(translation_element_layer+1)*longsurround));
    outside_node_y_north=max(y_coor_node(y_coor_node<startcircum_fine-(translation_element_layer+1)*longsurround));
    outside_node_y_south=min(y_coor_node(y_coor_node>endcircum_fine+(translation_element_layer+1)*longsurround));
    
    total_node_matrix=[node_coor_matrix_inside;node_coor_matrix_outside];
    total_element_matrix=[element_information_inside;element_information_outside];
    
    [total_node_matrix,total_element_matrix,force_node_matrix_west]=edge_west(node_coor_matrix_inside,total_element_matrix,t,outside_node_x_west,total_node_matrix);
    [total_node_matrix,total_element_matrix,force_node_matrix_east]=edge_east(node_coor_matrix_inside,total_element_matrix,t,outside_node_x_east,total_node_matrix);
    [total_node_matrix,total_element_matrix,force_node_matrix_north]=edge_north(node_coor_matrix_inside,total_element_matrix,t,outside_node_y_north,total_node_matrix);
    [total_node_matrix,total_element_matrix,force_node_matrix_south]=edge_south(node_coor_matrix_inside,total_element_matrix,t,outside_node_y_south,total_node_matrix);
    [total_node_matrix,total_element_matrix,force_node_matrix_conrner]=conrner_elements(node_coor_matrix_inside,total_element_matrix,t,outside_node_x_east,outside_node_x_west,outside_node_y_north,outside_node_y_south,total_node_matrix);
    total_node_matrix1=total_node_matrix;
    
    %%%%%%%%%%%%�������������Լ���߽�
    node_coor=total_node_matrix(:,1);
    border_index=intersect(find(total_node_matrix(:,2)>bend_start-straight_length-0.1),find(total_node_matrix(:,2)<bend_start-straight_length+0.1));
    border_node_left_index=node_coor(border_index);
    border_node_left_num=length(border_node_left_index);
    
    %%%%%%%%%%%%�������������Լ���߽�
    border_index=intersect(find(total_node_matrix(:,2)>bend_end+straight_length-0.1),find(total_node_matrix(:,2)<bend_end+straight_length+0.1));
    border_node_right_index=node_coor(border_index);
    border_node_right_num=length(border_node_right_index);
    
    %����ڵ���Լ���ڵ���
    cd('./burst_capacity_folder/');
    str = sprintf('border_node_left%d.txt',iii);
    fid=fopen(str,'wt');
    fprintf(fid,'%d\n',border_node_left_index);
    fclose(fid);
    %����ڵ���Լ���ڵ���
    str = sprintf('border_node_right%d.txt',iii);
    fid=fopen(str,'wt');
    fprintf(fid,'%d\n',border_node_right_index);
    fclose(fid);
    
    %�����ڲ����ؽڵ�
    pres_node_index=[pres_node_index_1',pres_node_index_2',force_node_matrix_west,force_node_matrix_east,force_node_matrix_north,force_node_matrix_south,force_node_matrix_conrner]';
    internal_node_index_num=length(pres_node_index);
    %�����ѹ�ڵ���
    str = sprintf('pres_node%d.txt',iii);
    fid=fopen(str,'wt');
    fprintf(fid,'%9.0f\n',pres_node_index');
    fclose(fid);
    
    %�ҵ���ʴ���ĵ�
    long_index1 = intersect(find(total_node_matrix(:,2)>=(endlong_fine+startlong_fine)/2),find(total_node_matrix(:,2)<=(endlong_fine+startlong_fine)/2+element_size));
    cir_index1  = intersect(find(total_node_matrix(:,3)>=(endcircum_fine+startcircum_fine)/2),find(total_node_matrix(:,3)<=(endcircum_fine+startcircum_fine)/2+element_size));
    node_selected_index_mid = intersect(long_index1,cir_index1);
    mid_index=node_selected_index_mid(1);
    
    %ת��Բ������
    orientation_degree1=pi/2;
    total_node_matrix(:,2)=total_node_matrix1(:,4).*cos(total_node_matrix1(:,3)/D/pi*2*pi-orientation_degree1-cir_center);
    total_node_matrix(:,3)=total_node_matrix1(:,4).*sin(total_node_matrix1(:,3)/D/pi*2*pi-orientation_degree1-cir_center);
    total_node_matrix(:,4)=total_node_matrix1(:,2);
    
    %��Ƭ�ӽ�
    if circumferential_position>pi*D/4 && circumferential_position<=pi*D*3/4
        view_y=1;
    else
        view_y=-1;
    end
    
    if circumferential_position<=pi*D/2
        view_1=-1;
    else
        view_1=1;
    end
    
    
    %%%%%%%%%%%%%��������
    transition_0=total_node_matrix(:,1);%�ڵ����
    transition_z=total_node_matrix(:,4);%�ڵ�z����
    transition_x=total_node_matrix(:,2);
    transition_y=total_node_matrix(:,3);
    transition_x_1=total_node_matrix(:,2);
    transition_z_1=total_node_matrix(:,4);
    
    index_bend_z=intersect(find(transition_z_1>=bend_start-1),find(transition_z_1<=bend_end+1));%�������ֵĽڵ�����
    index_stright_z=find(transition_z_1>bend_end);%������ֱ�ܵĽڵ�����
    
    degree_matrix=(transition_z(index_bend_z)-bend_start)/(bend_r);%�����ǶȾ���
    max_degree=max(degree_matrix);%��������Ƕ�
    max_degree1=max(degree_matrix)/pi*180;%��������Ƕ�
    %�������ֱ任
    transition_x(index_bend_z)=(bend_r)-(bend_r-transition_x_1(index_bend_z)).*cos(degree_matrix);
    transition_z(index_bend_z)=bend_start+(bend_r-transition_x_1(index_bend_z)).*sin(degree_matrix);
    %������ֱ�ܲ��ֱ任
    transition_x(index_stright_z)=(bend_r)-(bend_r-transition_x_1(index_stright_z)).*cos(max_degree)+(transition_z_1(index_stright_z)-bend_end).*sin(max_degree);
    transition_z(index_stright_z)=bend_start+(bend_r-transition_x_1(index_stright_z)).*sin(max_degree)+(transition_z_1(index_stright_z)-bend_end).*cos(max_degree);
    %�������Ͻڵ����
    total_node_matrix=[transition_0,transition_x,transition_y,transition_z];
    
    mid=total_node_matrix(mid_index,:);
    %%�߽�Լ����
    boundary_left_x=0;
    boundary_left_y=0;
    boundary_left_z=bend_start-straight_length;
    
    boundary_right_x=bend_r*(1-cos(max_degree))+straight_length*sin(max_degree);
    boundary_right_y=0;
    boundary_right_z=bend_r*sin(max_degree)+straight_length*cos(max_degree);
    
    
    str = sprintf('node_element_information_cluster%d.txt',iii);
    fid=fopen(str,'wt');
    fprintf(fid,'/batch');
    fprintf(fid,'\n');
    fprintf(fid,'/wb,file,start');
    fprintf(fid,'\n');
    fprintf(fid,'/prep7');
    fprintf(fid,'\n');
    fprintf(fid,'SHPP,OFF,,NOWARN');
    fprintf(fid,'\n');
    fprintf(fid,'/nolist');
    fprintf(fid,'\n');
    fprintf(fid,'/com,*********** Nodes for the whole assembly ***********');
    fprintf(fid,'\n');
    fprintf(fid,'csys,0');
    fprintf(fid,'\n');
    fprintf(fid,'nblock,3');
    fprintf(fid,'\n');
    fprintf(fid,'(1i16,3e16.6e2)');
    fprintf(fid,'\n');
    fprintf(fid,'%16.0f%16E%16E%16E\n',total_node_matrix');
    fprintf(fid,'/wb,elem,start');
    fprintf(fid,'\n');
    fprintf(fid,'/com,*********** Elements for Body 1 "Solid" ***********');
    fprintf(fid,'\n');
    fprintf(fid,'et,1,185');
    fprintf(fid,'\n');
    fprintf(fid,'eblock,19,solid,,41503');
    fprintf(fid,'\n');
    fprintf(fid,'(19i16)');
    fprintf(fid,'\n');
    fprintf(fid,'%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f\n', total_element_matrix');
    fclose(fid);
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % APDL model generation file
    fid = fopen('cluster16.txt');
    APDL_data= textscan(fid,'%s','delimiter','\n');
    APDL_data{1,1}(1)={['/input,node_element_information_cluster',num2str(iii),',txt']};
    
    if isnumeric(Axial_Force_Pre) | ~isnan(Axial_Force_Pre)
        if Axial_Force_Pre~=0 & ~isnan(Axial_Force_Pre)
            APDL_data{1,1}(8)={['flag_force_pre=1']};
            APDL_data{1,1}(135)={['f,new_nodemax,fx,',num2str(Axial_Force_Pre)]};
        end
    end
    
    if isnumeric(Axial_Force) | ~isnan(Axial_Force)
        if Axial_Force~=0 & ~isnan(Axial_Force)
            APDL_data{1,1}(9)={['flag_force=1']};
            APDL_data{1,1}(145)={['f,new_nodemax,fx,',num2str(Axial_Force)]};
        end
    end
    
    
    for i=41:60
        APDL_data{1,1}(i)=cellstr(M{i-40});
    end
    
    
    APDL_data{1,1}(13)={['Youngs=',num2str(E_value)]};
    APDL_data{1,1}(14)={['border_left=',num2str(bend_start-straight_length)]};
    APDL_data{1,1}(15)={['border_node_left_num=',num2str(border_node_left_num)]};
    APDL_data{1,1}(16)={['border_node_right_num=',num2str(border_node_right_num)]};
    APDL_data{1,1}(17)={['internal_surface_node_num=',num2str(internal_node_index_num)]};
    APDL_data{1,1}(21)={['*vread,border_node_left(1),border_node_left',num2str(iii),',txt,,ijk,border_node_left_num,1']};
    APDL_data{1,1}(24)={['*vread,border_node_right(1),border_node_right',num2str(iii),',txt,,ijk,border_node_right_num,1']};
    APDL_data{1,1}(27)={['*vread,internal_surface_node(1),pres_node',num2str(iii),',txt,,ijk,internal_surface_node_num,1']};
    APDL_data{1,1}(75)={['/view,1,0,',num2str(view_y),',0']};
    APDL_data{1,1}(77)={['/FOC,1,',num2str(boundary_right_x/3),',',num2str(0),',',num2str(boundary_left_z/3)]};
    APDL_data{1,1}(83)={['/view,1,',num2str(mid(1,2)),',',num2str(mid(1,3)),',',num2str(mid(1,4))]};
    APDL_data{1,1}(85)={['/FOC,1,',num2str(mid(1,2)),',',num2str(mid(1,3)),',',num2str(mid(1,4))]};
    APDL_data{1,1}(86)={['/DIST,1,',num2str(dist_length*2)]};
    APDL_data{1,1}(102)={['n,boundary_right,',num2str(boundary_right_x),',',num2str(boundary_right_y)',',',num2str(boundary_right_z)]};
    
    APDL_data{1,1}(152)={['sf,all,pres,',num2str(pressure_applied)]};
    APDL_data{1,1}(156)={['nsubst,',num2str(Substep_Number)]};
    APDL_data{1,1}(168)={['wpoffs,',num2str(boundary_right_x),',',num2str(boundary_right_y)',',',num2str(boundary_right_z)]};
    APDL_data{1,1}(169)={['wprota,,,',num2str(max_degree1)]};
    
    APDL_data{1,1}(183)={['/input,post_process_clsuter',num2str(iii),',txt']};
    fclose(fid);
    
    str = sprintf('APDL_file_cluster%d.txt',iii);
    fid=fopen(str,'wt');
    [A,B]=size(APDL_data{1,1});
    for i=1:A
        every_row=char(APDL_data{1,1}(i));
        fprintf(fid,'%s\n',every_row);
    end
    fclose(fid);
    clear total_node_information;
    clear element_information;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % APDL post process file
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    str = sprintf('post_process_clsuter%d.txt',iii);
    fid=fopen(str,'wt');
    fprintf(fid,'*cfopen,stress_cluster%d,txt',iii);
    fprintf(fid,'\n');
    fprintf(fid,'*vwrite,nodemaxs(1,1),nodemaxs(1,2)');
    fprintf(fid,'\n');
    fprintf(fid,'(f20.5,f20.5)');
    fprintf(fid,'\n');
    fprintf(fid,'*cfclos');
    fclose(fid);
    UTS_value_table(iii,1)=UTS_value;
    YS_value_table(iii,1)=YS_value;
    t_value_table(iii,1)=t;
    D_value_table(iii,1)=D;
    
    
    
    
end
%%%%%%%%%%%%%%%%%%%%%





for cluster_number=start_m:end_m
    tic
    jobname=['pipe_burst_test_cluster_',num2str(cluster_number)];
    skriptFileName=['APDL_file_cluster',num2str(cluster_number),'.txt'];
    outputFilename=['cluster',num2str(cluster_number),'_output.txt'];
    sys_char=strcat('SET KMP_STACKSIZE=4096k &',32,ansys_path,32,...
        '-b -p ansys -i',32,skriptFileName,32,...
        '-j',32,jobname,32,...
        '-o',32,outputFilename),
    ans1=system(sys_char);
    toc
end




%%%%%%%%%%%%%%
for i = start_m:end_m
    YS_value=YS_value_table(i,1);                                     % must be positive (MPa)
    UTS_value=UTS_value_table(i,1);                                    % must be positive (MPa)
    strain_exponential=0.224*(UTS_value/YS_value-1)^0.604;
    true_ultimate=UTS_value*exp(strain_exponential)
    t=t_value_table(i,1);
    D=D_value_table(i,1);
    internal_stress_curve=importdata(strcat(['stress_cluster',num2str(i),'.txt']));
    internal_pressure=internal_stress_curve(:,1)*pressure_applied;
    Mises_stress=internal_stress_curve(:,2);
    true_UTS=true_ultimate;
    judge_vector=Mises_stress-true_UTS;
    new_vector=judge_vector(1:end-1).*(judge_vector(2:end));
    possible_points=min(find(new_vector<=0));
    if isempty(possible_points)
        burst_pressure{i,2}=-1;
    else
        burst_pressure{i,2}=(true_UTS-Mises_stress(possible_points))*(internal_pressure(possible_points+1)-internal_pressure(possible_points))/(Mises_stress(possible_points+1)-Mises_stress(possible_points))+internal_pressure(possible_points);
    end
    burst_pressure{i,1}=i;
    
end



% this is for the post process, to extract the stess/strain plot at the burst step
every_row=[];
for i = start_m:end_m
    cd(currentFolder);
    %  T = readtable(['00',num2str(i),'.csv']);
    
    t=F_input(7);
    D=F_input(6);
    cd('./burst_capacity_folder/');
    pressure_applied=pressure_applied;                                                  % pressure_applied
    if length(burst_pressure{i,2})>1
        continue;
    end
    time_step=burst_pressure{i,2}/pressure_applied;                              % time step
    internal_stress_curve=importdata(strcat(['stress_cluster',num2str(i),'.txt']));
    FEA_time_step=internal_stress_curve(:,1);
    sub_step_num = find(time_step-FEA_time_step<0,1)-1;                            % this is the sub step number during burst
    
    fid = fopen('post_process_strain_stress_plot.txt');
    post_process_strain_stress= textscan(fid,'%s','delimiter','\n');
    post_process_strain_stress{1,1}(1)={['RESUME,pipe_burst_test_cluster_',num2str(i),',db,,0,0']};
    post_process_strain_stress{1,1}(16)={['SET,,,,,,,',num2str(sub_step_num)]};
    post_process_strain_stress{1,1}(22)={['SET,,,,,,,',num2str(sub_step_num)]};
    fclose(fid);
    
    str = sprintf('post_process_strain_stress_plot%d.txt',i);
    fid=fopen(str,'wt');
    [A,B]=size(post_process_strain_stress{1,1});
    for j=1:A
        every_row=char(post_process_strain_stress{1,1}(j));
        fprintf(fid,'%s\n',every_row);
    end
    every_row=[];
    fclose(fid);
    
    jobname=['pipe_burst_test_cluster_',num2str(i)];
    skriptFileName=['post_process_strain_stress_plot',num2str(i),'.txt'];
    outputFilename=['plot',num2str(i),'_output.txt'];
    sys_char=strcat('SET KMP_STACKSIZE=4096k &',32,ansys_path,32,...
        '-b -p ansys -i',32,skriptFileName,32,...
        '-j',32,jobname,32,...
        '-o',32,outputFilename),
    ans1=system(sys_char);
    
    cd (currentFolder);
    work_folder='./burst_capacity_folder/';                  %ԭʼͼƬ·��
    savepath ='./Finite_element_picture/';                   %���洦�����ͼƬ·��
    file_list=dir(fullfile(work_folder,'*.jpg'));            %��ȡ����·��
    for i1=1:length(file_list)
        im =imread([work_folder,file_list(i1).name]);             %����·����ÿһ��ͼƬ
        imwrite(im,[savepath,file_list(i1).name],'jpg');      %���µ�ͼƬд�뵽ָ���ļ���
    end
    
end

result=burst_pressure;


% s = pwd; % ��ȡ��ǰ·��
% cd('..'); % ������һ��·����
