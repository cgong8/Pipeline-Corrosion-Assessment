function [aaburst,aaleak,cburst,cleak]=diaoqusim3(xin,initialcre,T_max,numcorrelation,numsimulation) 
                          
                  
 numcor=numcorrelation;
 ratio=1;  %correlation ratio
 t_parachange=Cal_distpara(xin);                   
global corr_matrix3;
global gcor
                               %  gcor=0.8;
                             tiqu_xin     = xin;
                              m           = size(tiqu_xin  ,1);
                    %        corr_matrix =gcor*repmat(eye(10,10),numcor,numcor)+(1-gcor)*eye(10*numcor,10*numcor);
        corr_matrix3 =gcor*repmat(eye(11,11),1,1)+(1-gcor)*eye(11,11);                    
                            
%                                                
%                            if numcor>1
%                             for p=8:10:(8+10*(numcor-1))
%                                 
%                               if p+10<=(8+10*(numcor-1))
%                                   q=p+10:10:(8+10*(numcor-1));
%                                corr_matrix(p,q)=0.5;
%                                  corr_matrix(q,p)=0.5;
%                               end
%                              end
%                            end
%                
%                             if numcor>1
%                             for p=5:10:(5+10*(numcor-1))
%                                 
%                               if p+10<=(5+10*(numcor-1))
%                                   q=p+10:10:(5+10*(numcor-1));
%                                corr_matrix(p,q)=0.5;
%                                  corr_matrix(q,p)=0.5;
%                               end
%                              end
%                            end
%                              
%                               %corr_matrixo =eye(m,m);
%                           if numcor>1
%                             for p=7:10:(7+10*(numcor-1))
%                                 
%                                if p+10<=(7+10*(numcor-1))
%                          
%                                   q=p+10:10:(7+10*(numcor-1));
%                                corr_matrix(p,q)=0.2;
%                                  corr_matrix(q,p)=0.2;
%                                 end
%                             end
%                            end
%                            
%                           if   numcor>1
%                             for p=4:10:(4+10*(numcor-1))
%                                 
%                                if p+10<=(4+10*(numcor-1))
%                          
%                                   q=p+10:10:(4+10*(numcor-1));
%                                corr_matrix(p,q)=0.2;
%                                 corr_matrix(q,p)=0.2;
%                                 end
%                             end
%                               end
%                            
%                           if numcor>1
%                                 for p=6:10:(6+10*(numcor-1))
%                                 
%                                if p+10<=(6+10*(numcor-1))
%                          
%                                   q=p+10:10:(6+10*(numcor-1));
%                                corr_matrix(p,q)=0.2;
%                                  corr_matrix(q,p)=0.2;
%                                end
%                                end
%                           end
                           

  %corr_matrix=2*sin(pi/6*corr_matrix);


%numsimulation=1e5;
                 mu=zeros(m,1);
               % u=mvnrnd(mu,corr_matrix,numsimulation);  %%generating random process
                               u=lhsnorm(mu,corr_matrix3,numsimulation);
               %R=corrcoef(u);               
 x= u_x_transform2(u, t_parachange);
       
                   for  denum=1:numcorrelation 
 [gburst(:,:,denum), gl(:,:,denum)]= LSFm(x,denum,T_max);   
             denum
                   end   
    
  
    bas= gburst(:,:,1);
   for  denum=1:numcorrelation 
        bas=min(bas,gburst(:,:,denum)); 
   end         
     las= gl(:,:,1);
   for  denum=1:numcorrelation 
        las=min(las,gl(:,:,denum)); 
   end      
   
   for tim=1:T_max+1
       nn=length(find(bas(:,tim)==0));
       if isempty(nn)
           nn=0;
       end
  cburst(tim)=nn/numsimulation;
   end
         
    for tim=initialcre+1:T_max+1
       nm=length(find(las(:,tim)==0));
       if isempty(nm)
           nm=0;
       end
      cleak(tim)=nm/numsimulation;
    end
   
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
       buin=bas(:,1);
    for  time=1:T_max+1 
        buin=buin.*bas(:,time);
    end
   
      lein=las(:,1);
    for  time=1:T_max+1 
       lein=lein.*las(:,time);
    end   
        secin=find(buin+lein<2);
    
        leakind=double(bsxfun(@eq, bas(secin,:).*las(secin,:), las(secin,:)));
     burstind=double(bsxfun(@eq, bas(secin,:).*las(secin,:), bas(secin,:)));
        inddl=leakind(:,1);
    for  time=1:T_max+1 
        inddl=inddl.*leakind(:,time);
    end
   
      indbu=burstind(:,1);
    for  time=1:T_max+1 
        indbu=indbu.*burstind(:,time);
    end       
        
      bnew=bas(secin(find(indbu==1)),:);
   lnew=las(secin(find(inddl==1)),:);   
        
  % lnew=las(secin(find(inddl==1 & indbu~=1)),:);     

   
   for tim=1:T_max+1
       nn2=length(find(bnew(:,tim)==0));
       if isempty(nn2)
           nn2=0;
       end
  aburst(tim)=nn2/numsimulation;
   end
         
    for tim=initialcre+1:T_max+1
       nm2=length(find(lnew(:,tim)==0));
       if isempty(nm2)
           nm2=0;
       end
      aleak(tim)=nm2/numsimulation;
    end
   anburst=(aburst(2:T_max+1)-aburst(1:T_max))';
   
   anleak=(aleak(2:T_max+1)-aleak(1:T_max))';
  
  % anburst(1)=cburst(1)+ anburst(1);
  % anleak(1)=cleak(1)+anleak(1);
    %%%%%%%%%%%% considering interaction %%
  for t=1:T_max+1
    if t==1
    aaburst(t)=cburst(1);
    aaleak(t)=cleak(1);
    else
    aaburst(t)=cburst(1)+sum(anburst(1:t-1));
    aaleak(t)=cleak(1)+sum(anleak(1:t-1));
    end
  end
     
            
             