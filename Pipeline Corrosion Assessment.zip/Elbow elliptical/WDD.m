function Pb_cps=WDD(Cluster5,pipethickness,AOD,long_resoultion,P_plain,n,sigmau)

 t=pipethickness;
 L_max=round(10*sqrt(AOD*(t-max(max(Cluster5)))));
 
 
 % Now, I need to extent the cluster 5 pit map
 
 
 [M,N]=size(Cluster5);
  extended_cluster=zeros(M,N+L_max*2);
  extended_cluster(:,L_max:L_max+N-1)=Cluster5;
  river_bottom=max(Cluster5);
  new_river_bottom=max(extended_cluster);
  
  z_coor=0:long_resoultion:long_resoultion*(N+L_max*2-1);
  
  for i=1:N
      
      
      
      
      z_evalu=z_coor(i+L_max-1);
      d_evaluation=new_river_bottom(i+L_max-1);
      
      e_uts=n;
      
      dmax=max(river_bottom);
      ri=AOD/2-pipethickness;
      sigma_critical=sigmau*exp(n);
      P_long=sigma_critical/ri/sqrt(0.75)*(pipethickness-d_evaluation)*exp(-sqrt(0.75)*e_uts);
      
      
      
      
      depth_difference=(d_evaluation-new_river_bottom)/t;
      normal_length=abs(z_coor-z_evalu)/sqrt(AOD*(t-max(max(Cluster5))));
      distance_vector=2./(exp(-normal_length)+exp(normal_length));
      sumWDD=sum(depth_difference.*distance_vector);
      
  
      depth_difference1=(d_evaluation)/t;
      max_WDD=sum(depth_difference1.*distance_vector);
      g=sumWDD/max_WDD;
      g=max(g,0);
      Pb_cps1(i)=(P_plain-P_long)*g+P_long;     
  end
     Pb_cps=min(Pb_cps1);
end