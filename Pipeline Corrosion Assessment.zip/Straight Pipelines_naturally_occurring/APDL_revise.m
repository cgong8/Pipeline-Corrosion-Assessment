function [result]=APDL_revise(ansys_path,corrosion_type,E_value,F_input,F_input_depth,start_m,Substep_number)






ans = dos('md burst_capacity_folder');                          
currentFolder = pwd;
end_m=start_m;
for iii=start_m:end_m
    cd(currentFolder);
    corrosion_type=F_input(1,4); 
    D=F_input(1,5);         
    t=F_input(1,6);
    E_value=F_input(1,8); 
    YS_value=F_input(1,9);                                     % must be positive (MPa)
    UTS_value=F_input(1,10);                                   % must be positive (MPa)
    
    
    Axial_Force_Pre=F_input(1,11);
    Axial_Force=F_input(1,12);
    reso_y=F_input(1,26);
    Substep_Number=F_input(1,27);
   %%%%%%%%�ж�������

 
 
    %%%%%�����С
    element_size= D * pi / 16;                                 % I assume at least 16 elements should be created along the circumference
    translation_element_layer=min(3,max(round(element_size/54),1));        % the layer amount of transitional element should be between 1 and 3, that is the element size for defect free part is between 2 and 54
    element_size_x=F_input_depth(2,4)-F_input_depth(2,3);
    element_size_y=F_input_depth(4,2)-F_input_depth(3,2);
    element_minsize=min(element_size_x,element_size_y);
    
    if isnan(reso_y<element_minsize)
        element_size_x=element_minsize;
        element_size_y=element_minsize;
        element_size=element_minsize;
    else
        element_size=reso_y;
        element_size_x=element_size;
        element_size_y=element_size;
    end

    
    element_size_x=F_input_depth(2,4)-F_input_depth(2,3);
    element_size_y=F_input_depth(4,2)-F_input_depth(3,2);
    circumsurround=element_size_y*3^translation_element_layer;
    longsurround=element_size_x*3^translation_element_layer;

    
    %%%Ĭ��Ϊ�ⸯʴ
    if isnan(corrosion_type)
        corrosion_type=1;
    end
    %%%���õ���ģ��Ĭ��ֵ
    if isnan(E_value)
        E_value=200000;
    end
    %%%���û������Ӳ���
    if isnan(Substep_Number)
        Substep_Number=400;
    end
    
    %�ж��Ƿ���ѹ����Ӧ������
    if isnan(Axial_Force_Pre)
        Axial_Force_Pre=0;
    else
        Axial_Force_Pre=Axial_Force_Pre;
    end
    %�ж��Ƿ�����������
    if isnan(Axial_Force)
        Axial_Force=0;
    else
        Axial_Force=Axial_Force;
    end
    
    
    
    
    %%%%%%��ʴ�ĳ���
   [a,b]=size(F_input_depth);
    defect_length=F_input_depth(2,b)- F_input_depth(2,3);
    defect_width=F_input_depth(a,2)- F_input_depth(3,2);
    
    dist_length=max(defect_length,defect_width);
    
    
      %%%%%������ʴ�صı߽�
    long_start =  0            -  defect_length/2;
    long_end   =  long_start   +  defect_length;
    cir_start  =  D*pi/2       -  defect_width/2;
    cir_end    =  cir_start    +  defect_width;

    %%%%%��ʴ�ر�Ե����ʴ���߽�ľ���
    border_length=6*element_size;
    %%%%%��ʴ��������չ��ı߽�
    startlong_fine  = long_start -  border_length;
    endlong_fine    = long_end   +  border_length;
    startcircum_fine= cir_start  -  border_length;
    endcircum_fine  = cir_end    +  border_length;
    

    corrosion_cluster_num_long =  round(defect_length/element_size)+1;
    corrosion_cluster_num_cir  =  round(defect_width /element_size)+1;
    
    Cluster_corrosion_profile=F_input_depth(3:end,3:end);

    if max(Cluster_corrosion_profile(:))>100
        disp ("Error! maximum corrosion depth should not be greater than 100%t")
        return;
    end        
    if UTS_value<=YS_value
        disp ("Error! UTS must be greater than yield strength")
        return;
    end
    pressure_applied=4*UTS_value*t/D;
    strain_exponential=0.224*(UTS_value/YS_value-1)^0.604;
    true_ultimate=UTS_value*exp(strain_exponential);
    K=true_ultimate/(strain_exponential^strain_exponential);
    plastic_stress_ansys=linspace(YS_value,true_ultimate+100,20);
    plastic_strain_ansys=(plastic_stress_ansys/K).^(1/strain_exponential);
    plastic_strain_ansys(1)=YS_value/E_value;
    
    outputdata=cat(2,'tbpt,','defi');
    B = repmat(outputdata,[20,1]);
    for ii=1:20
        M{ii}=[B(ii,:),',',num2str(plastic_strain_ansys(ii)),',',num2str(plastic_stress_ansys(ii))];
    end
    
    Cluster1=Cluster_corrosion_profile;
    Cluster=Cluster1/100*t;
    [M_new,N_new]=size(Cluster);
    
    
    % call ANSYS to generate the mesh on a plane
    fid = fopen('plane_remesh.txt');
    plane_mesh_data= textscan(fid,'%s','delimiter','\n');
    plane_mesh_data{1,1}(7)={['D=',num2str(D)]};
    plane_mesh_data{1,1}(8)={['startlong_fine=',num2str(startlong_fine)]};
    plane_mesh_data{1,1}(9)={['endlong_fine=',num2str(endlong_fine)]};
    plane_mesh_data{1,1}(10)={['startcircum_fine=',num2str(round(startcircum_fine))]};
    plane_mesh_data{1,1}(11)={['endcircum_fine=',num2str(round(endcircum_fine))]};
    plane_mesh_data{1,1}(12)={['circum_increment=',num2str(element_size)]};
    plane_mesh_data{1,1}(13)={['long_increment=',num2str(element_size)]};
    plane_mesh_data{1,1}(14)={['translation_element_layer=',num2str(translation_element_layer)]};
    fclose(fid);
    
    corrosion_cluster_width_limit = D * pi * 2 / 3;
        if (M_new-1)*element_size_y>corrosion_cluster_width_limit
        disp ("Corrosion feature is too wide, simulation teminates")
        continue;
    end
   
    
    str = sprintf('plane_element%d.txt',iii);
    fid=fopen(str,'wt');
    [A,B]=size(plane_mesh_data{1,1});
    for i=1:A
        every_row=char(plane_mesh_data{1,1}(i));
        fprintf(fid,'%s\n',every_row);
    end
    every_row=[];
 fclose(fid);
    
    DST_PATH_t = './burst_capacity_folder/';
    movefile(str,DST_PATH_t);
    copyfile('plane_remesh.txt',DST_PATH_t);
    copyfile('node_element_FEA_generation.txt',DST_PATH_t);
    copyfile('cluster16_1.txt',DST_PATH_t);
    copyfile('post_process_strain_stress_plot.txt',DST_PATH_t);
    copyfile('corner_element.txt',DST_PATH_t);
    copyfile('corner_nodes.txt',DST_PATH_t);
    copyfile('post_process_strain_stress_plot.txt',DST_PATH_t);
    cd (DST_PATH_t);
 
    % call ANSYS to generate the model
    jobname=['model_generation_cluster',num2str(iii)];
    skriptFileName=['plane_element',num2str(iii),'.txt'];
    outputFilename=['cluster_output.txt'];
    sys_char=strcat('SET KMP_STACKSIZE=4096k &',32,ansys_path,32,...
        '-b -p ansys -i',32,skriptFileName,32,'-j',32,jobname,32,'-o',32,outputFilename),
    ans1=system(sys_char);
    
    str = sprintf('node_file.txt');
    Extra_node_information=importdata(str);
    cd(currentFolder);
    num_node_one_layer=length(Extra_node_information);    
    internal_radius=D/2-t;
    outer_radius=internal_radius+t;
    radius_1st_layer=internal_radius+(outer_radius-internal_radius)/4*3;
    radius_2nd_layer=internal_radius+(outer_radius-internal_radius)/2;
    radius_3rd_layer=internal_radius+(outer_radius-internal_radius)/4;
    
    x_coor_node=Extra_node_information(:,1);
    y_coor_node=Extra_node_information(:,2);
    z_coor_node=outer_radius*ones(num_node_one_layer,1);
   

    % inside the corrosion cluster area
    
    x_index=intersect(find(x_coor_node>=startlong_fine),find(x_coor_node<=endlong_fine));
    y_index=intersect(find(y_coor_node>=startcircum_fine),find(y_coor_node<=endcircum_fine));
    corrosion_region_index=intersect(x_index,y_index);
    [length_num_Cluster_x,length_num_Cluster_y]=size(Cluster);
    x_coor_Cluster=linspace(startlong_fine,endlong_fine,length_num_Cluster_y);
    y_coor_Cluster=linspace(startcircum_fine,endcircum_fine,length_num_Cluster_x);
    [X_coor_Cluster,Y_coor_Cluster]=meshgrid(x_coor_Cluster,y_coor_Cluster);
    vq = griddata(X_coor_Cluster,Y_coor_Cluster,Cluster,x_coor_node(corrosion_region_index),y_coor_node(corrosion_region_index),'nearest');
    long_index = intersect(find(x_coor_node>startlong_fine-(translation_element_layer+1)*longsurround),find(x_coor_node<endlong_fine+(translation_element_layer+1)*longsurround));
    cir_index  = intersect(find(y_coor_node>startcircum_fine-(translation_element_layer+1)*longsurround),find(y_coor_node<endcircum_fine+(translation_element_layer+1)*longsurround));
    node_selected_index_inside = intersect(long_index,cir_index);
    % node_num=length(X_coor_Cluster(:));
    %%%%%%1��ʾ�ⸯʴ��0��ʾ�ڸ�ʴ
    if corrosion_type==1
        z_coor_node(corrosion_region_index)=outer_radius-vq;
        % now, generate all the node and elements
        x_coor_all_node_inside=repmat(x_coor_node(node_selected_index_inside),5,1);
        y_coor_all_node_inside=repmat(y_coor_node(node_selected_index_inside),5,1);
        z_coor_all_node_inside=[z_coor_node(node_selected_index_inside);3/4*z_coor_node(node_selected_index_inside)+1/4*internal_radius;2/4*z_coor_node(node_selected_index_inside)+2/4*internal_radius;1/4*z_coor_node(node_selected_index_inside)+3/4*internal_radius;0/4*z_coor_node(node_selected_index_inside)+4/4*internal_radius];
    else
        z_coor_node( node_selected_index_inside)=internal_radius;
        z_coor_node(corrosion_region_index)= internal_radius+vq;
        % now, generate all the node and elements
        x_coor_all_node_inside=repmat(x_coor_node(node_selected_index_inside),5,1);
        y_coor_all_node_inside=repmat(y_coor_node(node_selected_index_inside),5,1);
        z_coor_all_node_inside=[0*z_coor_node(node_selected_index_inside)+outer_radius;1/4*z_coor_node(node_selected_index_inside)+3/4*outer_radius;2/4*z_coor_node(node_selected_index_inside)+2/4*outer_radius;3/4*z_coor_node(node_selected_index_inside)+1/4*outer_radius; z_coor_node(node_selected_index_inside);];
    end
    node_coor_matrix_inside=[[node_selected_index_inside;node_selected_index_inside+num_node_one_layer;node_selected_index_inside+num_node_one_layer*2;node_selected_index_inside+num_node_one_layer*3;node_selected_index_inside+num_node_one_layer*4],x_coor_all_node_inside,y_coor_all_node_inside,z_coor_all_node_inside];
    pres_node_index_1=node_selected_index_inside+num_node_one_layer*4;

    
    cd('./burst_capacity_folder/');
    str = sprintf('element_file.txt');
    Extra_element_information=importdata(str);
    cd(currentFolder);
    Lia=ismember(Extra_element_information,node_selected_index_inside);
    element_inside=find(sum(Lia,2)==4);
    num_extra_element=length(element_inside(:,1));
    Extra_element_information=[Extra_element_information(element_inside,:),Extra_element_information(element_inside,:)+num_node_one_layer
                               Extra_element_information(element_inside,:)+num_node_one_layer,Extra_element_information(element_inside,:)+2*num_node_one_layer
                               Extra_element_information(element_inside,:)+2*num_node_one_layer,Extra_element_information(element_inside,:)+3*num_node_one_layer
                               Extra_element_information(element_inside,:)+3*num_node_one_layer,Extra_element_information(element_inside,:)+4*num_node_one_layer];
    Extra_element_first_10=repmat([1,1,1,1,0,0,0,0,8,0],num_extra_element*4,1);
    element_information_inside=[Extra_element_first_10,[1:num_extra_element*4]', Extra_element_information];    
    
    % now, it is the outside area
    long_index = union(find(x_coor_node<=startlong_fine-(translation_element_layer+1)*longsurround),find(x_coor_node>=endlong_fine+(translation_element_layer+1)*longsurround));
    cir_index  = union(find(y_coor_node<=startcircum_fine-(translation_element_layer+1)*circumsurround),find(y_coor_node>=endcircum_fine+(translation_element_layer+1)*circumsurround));
    node_selected_index_outside = union(long_index,cir_index);    
    x_coor_all_node_outside=repmat(x_coor_node(node_selected_index_outside),3,1);
    y_coor_all_node_outside=repmat(y_coor_node(node_selected_index_outside),3,1);
    z_coor_all_node_outside=[z_coor_node(node_selected_index_outside);2/4*z_coor_node(node_selected_index_outside)+2/4*internal_radius;0/4*z_coor_node(node_selected_index_outside)+4/4*internal_radius];
    node_coor_matrix_outside=[[node_selected_index_outside;node_selected_index_outside+num_node_one_layer;node_selected_index_outside+num_node_one_layer*2],x_coor_all_node_outside,y_coor_all_node_outside,z_coor_all_node_outside]; 
     pres_node_index_2=node_selected_index_outside+num_node_one_layer*2;
     
    cd('./burst_capacity_folder/');
    str = sprintf('element_file.txt');
    Extra_element_information=importdata(str);
    cd(currentFolder);
    Lia=ismember(Extra_element_information,node_selected_index_outside);
    element_outside=find(sum(Lia,2)==4);
 
    num_extra_element1=length(element_outside(:,1));
    Extra_element_information=[Extra_element_information(element_outside,:),Extra_element_information(element_outside,:)+num_node_one_layer
                               Extra_element_information(element_outside,:)+num_node_one_layer,Extra_element_information(element_outside,:)+2*num_node_one_layer];
    Extra_element_first_10=repmat([1,1,1,1,0,0,0,0,8,0],num_extra_element1*2,1);
    element_information_outside=[Extra_element_first_10,[(num_extra_element*4+1):(num_extra_element*4+num_extra_element1*2)]', Extra_element_information]; 
    
       
    % now, generate the transitional FEA model 
    
    outside_node_x_west=max(x_coor_node(x_coor_node<startlong_fine-(translation_element_layer+1)*longsurround));
    outside_node_x_east=min(x_coor_node(x_coor_node>endlong_fine+(translation_element_layer+1)*longsurround));
    outside_node_y_north=max(y_coor_node(y_coor_node<startcircum_fine-(translation_element_layer+1)*circumsurround));
    outside_node_y_south=min(y_coor_node(y_coor_node>endcircum_fine+(translation_element_layer+1)*circumsurround));
    
    total_node_matrix=[node_coor_matrix_inside;node_coor_matrix_outside];
    total_element_matrix=[element_information_inside;element_information_outside];
    
    [total_node_matrix,total_element_matrix,force_node_matrix_west]=edge_west(node_coor_matrix_inside,total_element_matrix,t,outside_node_x_west,total_node_matrix);
    [total_node_matrix,total_element_matrix,force_node_matrix_east]=edge_east(node_coor_matrix_inside,total_element_matrix,t,outside_node_x_east,total_node_matrix);
    [total_node_matrix,total_element_matrix,force_node_matrix_north]=edge_north(node_coor_matrix_inside,total_element_matrix,t,outside_node_y_north,total_node_matrix);
    [total_node_matrix,total_element_matrix,force_node_matrix_south]=edge_south(node_coor_matrix_inside,total_element_matrix,t,outside_node_y_south,total_node_matrix);
    [total_node_matrix,total_element_matrix,force_node_matrix_conrner]=conrner_elements(node_coor_matrix_inside,total_element_matrix,t,outside_node_x_east,outside_node_x_west,outside_node_y_north,outside_node_y_south,total_node_matrix);
    total_node_matrix1=total_node_matrix;

    
    %�ҵ���ʴ���ĵ㣬ȷ���۽�λ��
    long_index1 = intersect(find(total_node_matrix(:,2)>=(endlong_fine+startlong_fine)/2-element_size/2),find(total_node_matrix(:,2)<=(endlong_fine+startlong_fine)/2+element_size/2));
    cir_index1  = intersect(find(total_node_matrix(:,3)>=(endcircum_fine+startcircum_fine)/2-element_size/2),find(total_node_matrix(:,3)<=(endcircum_fine+startcircum_fine)/2+element_size/2));
    mid_index= intersect(long_index1,cir_index1);
    
    %�����ڲ����ؽڵ�
    pres_node_index=[pres_node_index_1',pres_node_index_2',force_node_matrix_west,force_node_matrix_east,force_node_matrix_north,force_node_matrix_south,force_node_matrix_conrner]';
    internal_node_index_num=length(pres_node_index);
    %�����ѹ�ڵ���
    cd('./burst_capacity_folder/');
    str = sprintf('pres_node%d.txt',iii);
    fid=fopen(str,'wt');
    fprintf(fid,'%9.0f\n',pres_node_index');
    fclose(fid);
    
    
    %%%%%%%%ת���������Ϊֱ��
     orientation_degree =pi/2;
    total_node_matrix(:,2)=total_node_matrix1(:,4).*cos(total_node_matrix1(:,3)/D/pi*2*pi-orientation_degree);
    total_node_matrix(:,3)=total_node_matrix1(:,4).*sin(total_node_matrix1(:,3)/D/pi*2*pi-orientation_degree);
    total_node_matrix(:,4)=total_node_matrix1(:,2);
    
     
    
    
 
    str = sprintf('node_element_information_cluster%d.txt',iii);
    fid=fopen(str,'wt');
    fprintf(fid,'/batch');
    fprintf(fid,'\n');
    fprintf(fid,'/wb,file,start');
    fprintf(fid,'\n');
    fprintf(fid,'/prep7');
    fprintf(fid,'\n');
    fprintf(fid,'SHPP,OFF,,NOWARN');
    fprintf(fid,'\n');
    fprintf(fid,'/nolist');
    fprintf(fid,'\n');
    fprintf(fid,'/com,*********** Nodes for the whole assembly ***********');
    fprintf(fid,'\n');
    fprintf(fid,'csys,0');
    fprintf(fid,'\n');
    fprintf(fid,'nblock,3');
    fprintf(fid,'\n');
    fprintf(fid,'(1i16,3e16.6e2)');
    fprintf(fid,'\n');
    fprintf(fid,'%16.0f%16E%16E%16E\n',total_node_matrix');
    fprintf(fid,'/wb,elem,start');
    fprintf(fid,'\n');
    fprintf(fid,'/com,*********** Elements for Body 1 "Solid" ***********');
    fprintf(fid,'\n');
    fprintf(fid,'et,1,185');
    fprintf(fid,'\n');
    fprintf(fid,'eblock,19,solid,,41503');
    fprintf(fid,'\n');
    fprintf(fid,'(19i16)');
    fprintf(fid,'\n');
    fprintf(fid,'%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f%16.0f\n', total_element_matrix');
    fclose(fid);
    
 mid=total_node_matrix(mid_index,:);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % APDL model generation file
    fid = fopen('cluster16_1.txt');
    APDL_data= textscan(fid,'%s','delimiter','\n');
    fclose(fid);
    APDL_data{1,1}(1)={['/input,node_element_information_cluster',num2str(iii),',txt']};

    
   
    if isnumeric(Axial_Force_Pre) | ~isnan(Axial_Force_Pre)
            if Axial_Force_Pre~=0 & ~isnan(Axial_Force_Pre)
                APDL_data{1,1}(9)={['flag_force_pre=1']};
                APDL_data{1,1}(134)={['f,new_nodemax,fz,',num2str(Axial_Force_Pre)]};
            end
        end
        
        if isnumeric(Axial_Force) | ~isnan(Axial_Force)
            if Axial_Force~=0 & ~isnan(Axial_Force)
                APDL_data{1,1}(10)={['flag_force=1']};
                APDL_data{1,1}(145)={['f,new_nodemax,fz,',num2str(Axial_Force)]};
            end
        end
        
        for i=37:56
            APDL_data{1,1}(i)=cellstr(M{i-36});
        end
      
    APDL_data{1,1}(14)={['pipediameter=',num2str(D)]};
    APDL_data{1,1}(15)={['wallthickness=',num2str(t)]};
    APDL_data{1,1}(16)={['Youngs=',num2str(E_value)]};
    APDL_data{1,1}(17)={['startlong_fine=',num2str(startlong_fine)]};
    APDL_data{1,1}(18)={['endlong_fine=',num2str(endlong_fine)]};
    APDL_data{1,1}(19)={['internal_surface_node_num=',num2str(internal_node_index_num)]};
    APDL_data{1,1}(23)={['*vread,internal_surface_node(1),pres_node',num2str(iii),',txt,,ijk,internal_surface_node_num,1']};
    APDL_data{1,1}(73)={['/FOC,1,',num2str(mid(1,2)),',',num2str(mid(1,3)),',',num2str(mid(1,4))]};
    APDL_data{1,1}(81)={['/FOC,1,',num2str(mid(1,2)),',',num2str(mid(1,3)),',',num2str(mid(1,4))]};
    APDL_data{1,1}(82)={['/DIST,1,',num2str(dist_length)]};
    APDL_data{1,1}(153)={['sf,all,pres,',num2str(pressure_applied)]};
    APDL_data{1,1}(156)={['nsubst,',num2str(Substep_number)]};
    APDL_data{1,1}(176)={[' /input,post_process_clsuter',num2str(iii),',txt']};
  
    
    str = sprintf('APDL_file_cluster%d.txt',iii);
    fid=fopen(str,'wt');
    [A,B]=size(APDL_data{1,1});
    for i=1:A
        every_row=char(APDL_data{1,1}(i));
        fprintf(fid,'%s\n',every_row);
    end
    

    fclose(fid);
    clear total_node_information;
    clear element_information;
    clear Cluster_corrosion_profile;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % APDL post process file
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    str = sprintf('post_process_clsuter%d.txt',iii);
    fid=fopen(str,'wt');
    fprintf(fid,'*cfopen,stress_cluster%d,txt',iii);
    fprintf(fid,'\n');
    fprintf(fid,'*vwrite,nodemaxs(1,1),nodemaxs(1,2)');
    fprintf(fid,'\n');
    fprintf(fid,'(f20.5,f20.5)');
    fprintf(fid,'\n');
    fprintf(fid,'*cfclos');
    fclose(fid);


 
cluster_number=start_m;
    tic
    jobname=['pipe_burst_test_cluster_',num2str(cluster_number)];
    skriptFileName=['APDL_file_cluster',num2str(cluster_number),'.txt'];
    outputFilename=['cluster',num2str(cluster_number),'_output.txt'];
    sys_char=strcat('SET KMP_STACKSIZE=4096k &',32,ansys_path,32,...
        '-b -p ansys -i',32,skriptFileName,32,...
        '-j',32,jobname,32,...
        '-o',32,outputFilename),
    ans1=system(sys_char);
    toc

    
    
    i = start_m;
    internal_stress_curve=importdata(strcat(['stress_cluster',num2str(i),'.txt']));
    internal_pressure=internal_stress_curve(:,1)*pressure_applied;
    Mises_stress=internal_stress_curve(:,2);
    true_UTS=true_ultimate;
    judge_vector=Mises_stress-true_UTS;
    new_vector=judge_vector(1:end-1).*(judge_vector(2:end));
    possible_points=min(find(new_vector<=0));
    if isempty(possible_points)
        burst_pressure{i,2}=-1;
    else
        burst_pressure{i,2}=(true_UTS-Mises_stress(possible_points))*(internal_pressure(possible_points+1)-internal_pressure(possible_points))/(Mises_stress(possible_points+1)-Mises_stress(possible_points))+internal_pressure(possible_points);
    end
    burst_pressure{i,1}=i;


% this is for the post process, to extract the stess/strain plot at the burst step 
every_row=[];

    i = start_m;
    
    time_step=burst_pressure{i,2}/pressure_applied;                              % time step
    internal_stress_curve=importdata(strcat(['stress_cluster',num2str(i),'.txt']));
    FEA_time_step=internal_stress_curve(:,1);
    sub_step_num = find(time_step-FEA_time_step<0,1)-1;                            % this is the sub step number during burst 
    
    fid = fopen('post_process_strain_stress_plot.txt');
    post_process_strain_stress= textscan(fid,'%s','delimiter','\n');
    post_process_strain_stress{1,1}(1)={['RESUME,pipe_burst_test_cluster_',num2str(i),',db,,0,0']};
    post_process_strain_stress{1,1}(16)={['SET,,,,,,,',num2str(sub_step_num)]};
    post_process_strain_stress{1,1}(22)={['SET,,,,,,,',num2str(sub_step_num)]};
      fclose(fid);
      
    str = sprintf('post_process_strain_stress_plot%d.txt',i);
    fid=fopen(str,'wt');
    [A,B]=size(post_process_strain_stress{1,1});
    for j=1:A
        every_row=char(post_process_strain_stress{1,1}(j));
        fprintf(fid,'%s\n',every_row);
    end
    every_row=[];
    fclose(fid);
    
    jobname=['pipe_burst_test_cluster_',num2str(i)];
    skriptFileName=['post_process_strain_stress_plot',num2str(i),'.txt'];
    outputFilename=['plot',num2str(i),'_output.txt'];
    sys_char=strcat('SET KMP_STACKSIZE=4096k &',32,ansys_path,32,...
        '-b -p ansys -i',32,skriptFileName,32,...
        '-j',32,jobname,32,...
        '-o',32,outputFilename),
    ans1=system(sys_char);
    
    cd (currentFolder);
    work_folder='./burst_capacity_folder/';                  %ԭʼͼƬ·��
    savepath ='./Finite_element_picture/';                   %���洦�����ͼƬ·��
    file_list=dir(fullfile(work_folder,'*.jpg'));            %��ȡ����·��
    for i1=1:length(file_list)
        im =imread([work_folder,file_list(i1).name]);             %����·����ÿһ��ͼƬ
        imwrite(im,[savepath,file_list(i1).name],'jpg');      %���µ�ͼƬд�뵽ָ���ļ���
    end

    
    
end

result=burst_pressure;



