function [t,alfa,beta,designpointx]=diaoqu(xin,T_max,numcor) 

global t_parachange  t_inter corr_matrix; 
global corr_matrix3;
 global indicator denum;
 global gcor;
 global gcor1;


Lsfnum=indicator;
              %     1   2   3   4   5   6   7  8   9
%              %sigmau, wt, D, d0, gd, l0, gl, e2, pb
%      xin(:,1)=[   2   2   2   2   5   2   5  6   6  4];
                             
                             tiqu_xin     = xin;
                              m           = size(tiqu_xin  ,1);
                            corr_matrix =gcor*repmat(eye(11,11),1,1)+(1-gcor)*eye(11,11);
                           
% %                             corr_matrix(5,7)=gcor;
% %                              corr_matrix(7,5)=gcor;
%                            if numcor>1
%                             for p=8:10:(8+10*(numcor-1))
%                                 
%                               if p+10<=(8+10*(numcor-1))
%                                   q=p+10:10:(8+10*(numcor-1));
%                                corr_matrix(p,q)=0.5;
%                                  corr_matrix(q,p)=0.5;
%                               end
%                              end
%                            end
%                
%                             if numcor>1
%                             for p=5:10:(5+10*(numcor-1))
%                                 
%                               if p+10<=(5+10*(numcor-1))
%                                   q=p+10:10:(5+10*(numcor-1));
%                                corr_matrix(p,q)=0.5;
%                                  corr_matrix(q,p)=0.5;
%                               end
%                              end
%                            end
%                              
%                               %corr_matrixo =eye(m,m);
%                           if numcor>1
%                             for p=7:10:(7+10*(numcor-1))
%                                 
%                                if p+10<=(7+10*(numcor-1))
%                          
%                                   q=p+10:10:(7+10*(numcor-1));
%                                corr_matrix(p,q)=0.2;
%                                  corr_matrix(q,p)=0.2;
%                                 end
%                             end
%                            end
%                            
%                           if   numcor>1
%                             for p=4:10:(4+10*(numcor-1))
%                                 
%                                if p+10<=(4+10*(numcor-1))
%                          
%                                   q=p+10:10:(4+10*(numcor-1));
%                                corr_matrix(p,q)=0.2;
%                                 corr_matrix(q,p)=0.2;
%                                 end
%                             end
%                               end
%                            
%                           if numcor>1
%                                 for p=6:10:(6+10*(numcor-1))
%                                 
%                                if p+10<=(6+10*(numcor-1))
%                          
%                                   q=p+10:10:(6+10*(numcor-1));
%                                corr_matrix(p,q)=0.2;
%                                  corr_matrix(q,p)=0.2;
%                                end
%                                end
%                           end
                           
                              
 
                          
                          % corr_matrix=2*sin(pi/6*corr_matrix);
                           
                          % idx=find( corr_matrix==0); % find all 1.5
                               % corr_matrix(idx)=0.3;
                           
                               covariance = chol(corr_matrix)';
                             
                             
                %%%%%%%%%%%%%
                %%%%%%%%%%%%%
                   
                        beta         = zeros(1,T_max+1);
                        p            = zeros(1,T_max+1);
                        alfa         = zeros(m,T_max+1);
                        designpointx = zeros(m,T_max+1);
                        designpointu = zeros(m,T_max+1);
                        p_bsr        = zeros(T_max+1,3);
                        beta_bsr     = zeros(T_max+1,3);
         %%%%%%%%%%%%%%%%%%%
         %For each scenario
         %%%%%%%%%%%%%%%%%%%
                           t_parachange       = Cal_distpara(tiqu_xin);
                           
              
                        for time =1:T_max+1
                            t_inter            = time-1;%0-T_max?

                            u0(1:11)            = 0;

%   [u,fval,info,output,exitflag,lambda,states] = snsolve(@ReliabilityIndexEval, u0, [],[],[],[],[],[],@LSFmd);  
 [formresults]=mini(u0,covariance,tiqu_xin,Lsfnum, denum,numcor,t_inter);
                               fval       =formresults.beta1;
% %                             alfa(:,time)         =formresults.alpha;
% %                            designpointx(:,time) =formresults.dsptx;
                               u =formresults.dsptu';


       numcor1=numcor;
       denum1=denum;
       u10=zeros(numcor1*11,1);
       u10(1+(denum1-1)*11:11+(denum1-1)*11,1)=inv(corr_matrix)*u;
%  %     corr_matrix3 =gcor*repmat(eye(10,10),numcor1,numcor1)+(1-gcor)*eye(10*numcor1,10*numcor1);
% 
%         cor =gcor*eye(10,10);
%           cor(4,6)=0.5;
%          cor(6,4)=0.5;
    corr_matrix0 =gcor*repmat(eye(11,11),1,1)+(1-gcor)*eye(11,11);
   corr_matrix3 =gcor1*repmat(corr_matrix0,numcor1,numcor1)+(1-gcor1)*eye(11*numcor1,11*numcor1);      
%         

% %                           if numcor>1
% %                                 for p=1:10:(1+10*(numcor-1))
% %                                 
% %                                if p+10<=(1+10*(numcor-1))
% %                          
% %                                   q=p+10:10:(1+10*(numcor-1));
% %                                corr_matrix3(p,q)=0.95;
% %                                  corr_matrix3(q,p)=0.95;
% %                                end
% %                                end
% %                           end
% %                            
% %                           if numcor>1
% %                                 for p=2:10:(2+10*(numcor-1))
% %                                 
% %                                if p+10<=(2+10*(numcor-1))
% %                          
% %                                   q=p+10:10:(2+10*(numcor-1));
% %                                corr_matrix3(p,q)=0.95;
% %                                  corr_matrix3(q,p)=0.95;
% %                                end
% %                                end
% %                           end
% %                            
% %                           
% %                              if numcor>1
% %                                  for j=1:numcor
% %                              corr_matrix3(5+(j-1)*10,7+(j-1)*10)=gcor;
% %                              corr_matrix3(7+(j-1)*10,5+(j-1)*10)=gcor;
% %                                  end
% %                              end
% % %                           if numcor>1
% % %                                 for p=3:10:(3+10*(numcor-1))
% % %                                 
% % %                                if p+10<=(3+10*(numcor-1))
% % %                          
% % %                                   q=p+10:10:(3+10*(numcor-1));
% % %                                corr_matrix3(p,q)=0.95;
% % %                                  corr_matrix3(q,p)=0.95;
% % %                                end
% % %                                end
% % %                           end
% %       
% %                            
% % %                           if numcor>1
% % %                                 for p=5:10:(6+10*(numcor-1))
% % %                                 
% % %                                if p+10<=(6+10*(numcor-1))
% % %                          
% % %                                   q=p+10:10:(6+10*(numcor-1));
% % %                                corr_matrix3(p,q)=0.5;
% % %                                  corr_matrix3(q,p)=0.5;
% % %                                end
% % %                                end
% % %                           end
% %                            
% %                       
% %                            
% % %                           if numcor>1
% % %                                 for p=7:10:(7+10*(numcor-1))
% % %                                 
% % %                                if p+10<=(7+10*(numcor-1))
% % %                          
% % %                                   q=p+10:10:(7+10*(numcor-1));
% % %                                corr_matrix3(p,q)=0.5;
% % %                                  corr_matrix3(q,p)=0.5;
% % %                                end
% % %                                end
% % %                           end
% %                           
% %                         if numcor>1
% %                                 for p=9:10:(9+10*(numcor-1))
% %                                 
% %                                      if p+10<=(9+10*(numcor-1))
% %                          
% %                                      q=p+10:10:(9+10*(numcor-1));
% %                                      corr_matrix3(p,q)=0.95;
% %                                      corr_matrix3(q,p)=0.95;
% %                                      end
% %                                  end
% %                         end  
% % 
% %                              if numcor>1
% %                                 for p=10:10:(10+10*(numcor-1))
% %                                 
% %                                      if p+10<=(10+10*(numcor-1))
% %                          
% %                                      q=p+10:10:(10+10*(numcor-1));
% %                                      corr_matrix3(p,q)=0.95;
% %                                      corr_matrix3(q,p)=0.95;
% %                                      end
% %                                 end
% %                            end  
                    
                        
                        
                          

         
       u10gg=(corr_matrix3)*u10;
%         [ma1, I1]=max(abs(u));
%        lamda=u(I1)/u10gg(I1);
%      yes=corr_matrix3*lamda*u10*0.5;
                                     covariance2 = chol(corr_matrix3)';
                                  u10ggu=inv(covariance2)*u10gg;
            alfa(:,time)         =  u10ggu/norm( u10ggu);         


%    x                    = u_x_transform(u,t_parachange);
%      u=inv((covariance))*u;
%      u=u';
                           beta(:,time)         = fval;
%                         alfa(:,time)         = u'/norm(u);
                           designpointx(:,time) = u10gg;
                           designpointu(:,time) = u10ggu;


%%%%%%%%%%%%%%%%%%%%%%%%%%%555
%      [formresults]=mini(u0,covariance,tiqu_xin,Lsfnum, denum,numcor,t_inter);
% 
%      
%      
%                             beta(:,time)         =formresults.beta1;
%                             alfa(:,time)         =formresults.alpha;
%                            designpointx(:,time) =formresults.dsptx;
%                            designpointu(:,time) =formresults.dsptu;
%                           %  save error
%    %  % [fval]=sorm(m,formresults.beta1,formresults.dsptu,corr_matrix,t_parachange,t_inter,Lsfnum,denum);
%      
%                               beta(:,time)         =formresults.beta1;
%                             
                        end

%                     [mi,I]=min(beta);
%                         
%                        if I<(T_max+1)
%                       
%                            for i=I:(T_max+1)
%                             beta(i)=-beta(i);
%                            end
%                             beta(I)=interp1([1:I-1 I+1:T_max+1],[beta(1:(I-1)) beta(I+1:T_max+1)],I,'spline');                                  
%                        warning('The trend of beta is starting to be inverse at "%d".',I);
%                        end
%                         
%                   
%                     
% 
% a=find( diff(beta)>=0);
%                         
%                         if ~isempty(a)
%                             for i=1:length(a)
%                             I=a(i)+1;
%                             beta(I)=interp1([1:I-1 I+1:T_max+1],[beta(1:(I-1)) beta(I+1:T_max+1)],I,'spline'); 
%       warning('The trend of beta is starting to be inverse in the year "%d".',I);
%                           %save error
%                             end
%                         end 
%              
%     
%%save eeeeeee
%   %/                
  t = 1:T_max+1;           
   

    %[P_r]=p1;      
%[P_r] = Cal_Cumulativepf(T_max,alfa1,betag1,alfa2,betag2);